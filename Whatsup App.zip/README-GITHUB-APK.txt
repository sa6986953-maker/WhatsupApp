WHATSUP - GITHUB APK BUILD

This is the complete Android project. The project-level GitHub Actions workflow is:
.github/workflows/android-apk.yml

If you upload/extract this project into a GitHub repository root, the workflow will build a debug APK on pushes to main or when manually started from Actions.

Important:
- This workflow builds the Android APK only.
- Firebase Cloud Functions must be deployed separately for Gmail OTP and server-side features.
- Firebase Gmail sender secrets must be configured in Firebase Functions; they are not included in this ZIP.
- The existing Firebase project configuration was retained, not independently verified.
- This archive has not been compiled in this environment. GitHub Actions will provide the actual build result and any compiler errors.
