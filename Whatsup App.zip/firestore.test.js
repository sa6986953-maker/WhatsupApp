const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const crypto = require("node:crypto");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";

function sha256Hex(str) {
  return crypto.createHash("sha256").update(str, "utf8").digest("hex");
}

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) await testEnv.cleanup();
});

beforeEach(async () => {
  if (testEnv) await testEnv.clearFirestore();
});

function sampleUser(uid, email, name, now, phoneE164 = "") {
  return {
    userId: uid,
    displayName: name,
    email,
    emailHash: sha256Hex(email),
    emailVerified: true,
    phoneE164,
    phoneHash: phoneE164 ? sha256Hex(phoneE164) : "",
    about: "Available on Whatsup",
    identityPublicKey: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE" + "A".repeat(48),
    twoStepEnabled: false,
    online: true,
    lastSeenAt: Date.now() - 1000,
    lastSeenPrivacy: "EVERYONE",
    onlinePrivacy: "EVERYONE",
    photoPrivacy: "EVERYONE",
    aboutPrivacy: "EVERYONE",
    hideBlueTicks: false,
    dataSaver: false,
    appLockEnabled: false,
    createdAt: now,
    updatedAt: now,
  };
}

test("Unauthenticated users are denied across all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("emailDirectory").doc(sha256Hex("alice@gmail.com")).get());
  await assertFails(unauthDb.collection("emailOtps").doc(sha256Hex("alice@gmail.com")).get());
  await assertFails(unauthDb.collection("phoneDirectory").doc(sha256Hex("+923001112233")).get());
  await assertFails(unauthDb.collection("conversations").get());
  await assertFails(unauthDb.collection("statuses").get());
  await assertFails(unauthDb.collection("calls").get());
});

test("Gmail profile, anti-enumeration list denial, locked emailOtps/2FA, and emailDirectory lookup", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);
  const aliceEmail = "alice@gmail.com";
  const aliceEmailHash = sha256Hex(aliceEmail);

  // Create own Gmail user profile without requiring a phone number (twoStepEnabled=false required)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(sampleUser(ALICE_UID, aliceEmail, "Alice", now))
  );

  // Client cannot forge twoStepEnabled=true directly
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      twoStepEnabled: true,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Client cannot read or write /emailOtps/{hash} or /users/{uid}/private/twoStep (Admin SDK only)
  await assertFails(
    aliceDb.collection("emailOtps").doc(aliceEmailHash).set({ otpHash: "forged" })
  );
  await assertFails(
    aliceDb.collection("emailOtps").doc(aliceEmailHash).get()
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("twoStep").set({ pinHash: "abc" })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("twoStep").get()
  );

  // Register in emailDirectory
  await assertSucceeds(
    aliceDb.collection("emailDirectory").doc(aliceEmailHash).set({
      uid: ALICE_UID,
      emailHash: aliceEmailHash,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob can point-lookup Alice by Gmail hash and get Alice's profile, but CANNOT list/scrape collections
  await assertSucceeds(bobDb.collection("emailDirectory").doc(aliceEmailHash).get());
  await assertSucceeds(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("emailDirectory").get());
  await assertFails(bobDb.collection("phoneDirectory").get());
  await assertFails(bobDb.collection("users").get());
});

test("Multi-user direct conversation, message E2EE delivery, ticks, edit/delete-for-everyone, and isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 3000);

  const convId = "direct_alice_123_bob_456";
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).set({
      type: "DIRECT",
      participantUids: [ALICE_UID, BOB_UID],
      adminUids: [ALICE_UID, BOB_UID],
      createdByUid: ALICE_UID,
      title: "Direct Chat",
      onlyAdminCanSend: false,
      bluetoothChat: false,
      disappearingMode: "OFF",
      lastMessagePreview: "Assalam-o-Alaikum",
      lastMessageSenderUid: ALICE_UID,
      lastMessageTimeLabel: "10:15 AM",
      lastMessageTick: "SENT",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 1 },
      sortOrder: 1000,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice and Bob can list conversations scoped with array-contains
  await assertSucceeds(
    bobDb.collection("conversations").where("participantUids", "array-contains", BOB_UID).orderBy("sortOrder", "desc").get()
  );

  // Charlie (non-participant) cannot read or query Alice & Bob's conversation
  await assertFails(charlieDb.collection("conversations").doc(convId).get());

  // Alice sends a message
  const msgRef = aliceDb.collection("conversations").doc(convId).collection("messages").doc("msg_1");
  await assertSucceeds(
    msgRef.set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      senderPhone: "+923001112233",
      text: "",
      ciphertext: "base64ciphertext==",
      iv: "base64iv==",
      messageType: "TEXT",
      tickStatus: "SENT",
      viaBluetooth: false,
      edited: false,
      deletedForEveryone: false,
      deliveredTo: { [ALICE_UID]: true },
      readBy: { [ALICE_UID]: true },
      timeLabel: "10:15 AM",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob marks delivered/read and reacts
  await assertSucceeds(
    bobDb.collection("conversations").doc(convId).collection("messages").doc("msg_1").update({
      tickStatus: "READ",
      deliveredTo: { [ALICE_UID]: true, [BOB_UID]: true },
      readBy: { [ALICE_UID]: true, [BOB_UID]: true },
      reactions: { [BOB_UID]: "👍" },
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Bob CANNOT edit Alice's message text or deleteForEveryone
  await assertFails(
    bobDb.collection("conversations").doc(convId).collection("messages").doc("msg_1").update({
      text: "Tampered",
      edited: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Alice CAN edit her own message
  await assertSucceeds(
    msgRef.update({
      ciphertext: "editedcipher==",
      iv: "editediv==",
      edited: true,
      editedAtMillis: Date.now() - 500,
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Group admin-only enforcement and invite link joining", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  const groupId = "grp_kpk_1";
  await assertSucceeds(
    aliceDb.collection("conversations").doc(groupId).set({
      type: "GROUP",
      participantUids: [ALICE_UID, BOB_UID],
      adminUids: [ALICE_UID],
      createdByUid: ALICE_UID,
      title: "Kahror Pakka Announcements",
      inviteCode: "JOIN99KPK",
      onlyAdminCanSend: true,
      bluetoothChat: false,
      disappearingMode: "OFF",
      lastMessagePreview: "Group created",
      lastMessageSenderUid: ALICE_UID,
      lastMessageTimeLabel: "11:00 AM",
      lastMessageTick: "SENT",
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
      sortOrder: 2000,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob is non-admin in an admin-only group -> send fails
  await assertFails(
    bobDb.collection("conversations").doc(groupId).collection("messages").doc("msg_bob").set({
      senderUid: BOB_UID,
      senderName: "Bob",
      text: "Testing non-admin",
      messageType: "TEXT",
      tickStatus: "SENT",
      viaBluetooth: false,
      edited: false,
      deletedForEveryone: false,
      timeLabel: "11:01 AM",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Admin Alice can send
  await assertSucceeds(
    aliceDb.collection("conversations").doc(groupId).collection("messages").doc("msg_alice").set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      text: "Welcome all",
      messageType: "TEXT",
      tickStatus: "SENT",
      viaBluetooth: false,
      edited: false,
      deletedForEveryone: false,
      timeLabel: "11:02 AM",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Charlie joins via invite code
  await assertSucceeds(
    charlieDb.collection("conversations").doc(groupId).update({
      participantUids: [ALICE_UID, BOB_UID, CHARLIE_UID],
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0, [CHARLIE_UID]: 0 },
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Status privacy (allowedUids) & WebRTC calls signaling", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 2000);
  const expires = new Date(Date.now() + 24 * 3600 * 1000);

  // Alice shares status ONLY with Bob
  await assertSucceeds(
    aliceDb.collection("statuses").doc("st_1").set({
      ownerUid: ALICE_UID,
      ownerPhoneE164: "+923001112233",
      authorName: "Alice",
      statusType: "TEXT",
      caption: "Private status for Bob only",
      bgColorHex: 0xFF075E54,
      privacyMode: "ONLY_SHARE_WITH",
      allowedUids: [ALICE_UID, BOB_UID],
      excludedUids: [CHARLIE_UID],
      viewedByCount: 0,
      expiresAt: expires,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    bobDb.collection("statuses").where("allowedUids", "array-contains", BOB_UID).orderBy("createdAt", "desc").get()
  );
  await assertFails(charlieDb.collection("statuses").doc("st_1").get());

  // Bob records viewer receipt
  await assertSucceeds(
    bobDb.collection("statuses").doc("st_1").collection("viewers").doc(BOB_UID).set({
      viewerUid: BOB_UID,
      viewerName: "Bob",
      viewedAt: new Date(Date.now() - 500),
    })
  );

  // WebRTC call signaling
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").set({
      callerUid: ALICE_UID,
      callerName: "Alice",
      calleeUid: BOB_UID,
      calleeName: "Bob",
      participantUids: [ALICE_UID, BOB_UID],
      callType: "VIDEO",
      status: "RINGING",
      offerSdp: "v=0...",
      durationSeconds: 0,
      recorded: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").update({
      status: "ACCEPTED",
      answerSdp: "v=0-answer...",
      updatedAt: new Date(Date.now() - 300),
    })
  );

  await assertFails(charlieDb.collection("calls").doc("call_1").get());
});
