const crypto = require("node:crypto");

const OTP_TTL_MS = 5 * 60 * 1000; // 5 minutes
const RESEND_COOLDOWN_MS = 60 * 1000; // 60 seconds
const REQUEST_WINDOW_MS = 30 * 60 * 1000; // 30 minutes
const MAX_REQUESTS_PER_WINDOW = 5;
const REQUEST_LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes
const MAX_VERIFY_ATTEMPTS = 5;

const GMAIL_REGEX = /^[a-z0-9._%+-]{1,64}@(gmail\.com|googlemail\.com)$/;

/**
 * Normalizes and validates a Gmail address.
 * Accepts @gmail.com and @googlemail.com domains.
 */
function normalizeGmailAddress(rawEmail) {
  if (typeof rawEmail !== "string") return null;
  const trimmed = rawEmail.trim().toLowerCase();
  if (trimmed.length === 0 || trimmed.length > 254) return null;
  if (!GMAIL_REGEX.test(trimmed)) return null;

  const [localPart] = trimmed.split("@");
  if (!localPart || localPart.startsWith(".") || localPart.endsWith(".") || localPart.includes("..")) {
    return null;
  }
  return trimmed;
}

function hashEmailSha256(normalizedEmail) {
  return crypto.createHash("sha256").update(normalizedEmail, "utf8").digest("hex");
}

/**
 * Generates a cryptographically secure random 6-digit OTP ("100000" .. "999999").
 */
function generateSecureOtp() {
  return String(crypto.randomInt(100000, 1000000));
}

function hashOtp(otpCode, saltHex) {
  return crypto
    .createHmac("sha256", Buffer.from(saltHex, "hex"))
    .update(String(otpCode), "utf8")
    .digest("hex");
}

function verifyOtpHash(otpCode, saltHex, expectedHex) {
  if (typeof otpCode !== "string" || typeof saltHex !== "string" || typeof expectedHex !== "string") {
    return false;
  }
  const actualHex = hashOtp(otpCode, saltHex);
  const bufA = Buffer.from(actualHex, "hex");
  const bufB = Buffer.from(expectedHex, "hex");
  if (bufA.length === 0 || bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

/**
 * Enforces 60-second resend cooldown and per-window request rate limit.
 */
function evaluateOtpRequestRateLimit(existingDoc, nowMs = Date.now()) {
  if (!existingDoc) {
    return {
      allowed: true,
      nextCount: 1,
      windowStartedAtMs: nowMs,
      lockoutUntilMs: 0,
    };
  }

  if (existingDoc.requestLockedUntilMs && nowMs < existingDoc.requestLockedUntilMs) {
    const retryAfterSeconds = Math.max(1, Math.ceil((existingDoc.requestLockedUntilMs - nowMs) / 1000));
    const mins = Math.ceil(retryAfterSeconds / 60);
    return {
      allowed: false,
      code: "resource-exhausted",
      retryAfterSeconds,
      lockoutUntilMs: existingDoc.requestLockedUntilMs,
      message: `Too many OTP requests. Please try again in ${mins} minute(s).`,
    };
  }

  if (existingDoc.resendAvailableAtMs && nowMs < existingDoc.resendAvailableAtMs) {
    const retryAfterSeconds = Math.max(1, Math.ceil((existingDoc.resendAvailableAtMs - nowMs) / 1000));
    return {
      allowed: false,
      code: "resource-exhausted",
      retryAfterSeconds,
      lockoutUntilMs: 0,
      message: `Please wait ${retryAfterSeconds}s before requesting another OTP.`,
    };
  }

  const inSameWindow =
    typeof existingDoc.windowStartedAtMs === "number" &&
    nowMs - existingDoc.windowStartedAtMs < REQUEST_WINDOW_MS;
  const windowStartedAtMs = inSameWindow ? existingDoc.windowStartedAtMs : nowMs;
  const nextCount = inSameWindow ? (existingDoc.requestCount || 0) + 1 : 1;

  if (nextCount > MAX_REQUESTS_PER_WINDOW) {
    const lockoutUntilMs = nowMs + REQUEST_LOCKOUT_MS;
    return {
      allowed: false,
      code: "resource-exhausted",
      retryAfterSeconds: Math.ceil(REQUEST_LOCKOUT_MS / 1000),
      lockoutUntilMs,
      nextCount,
      windowStartedAtMs,
      message: "Maximum OTP request limit reached. Please wait 15 minutes before trying again.",
    };
  }

  return {
    allowed: true,
    nextCount,
    windowStartedAtMs,
    lockoutUntilMs: 0,
  };
}

/**
 * Evaluates a 6-digit OTP verification attempt against expiry and max attempts.
 */
function evaluateOtpVerification(existingDoc, otpCode, nowMs = Date.now()) {
  if (typeof otpCode !== "string" || !/^\d{6}$/.test(otpCode.trim())) {
    return {
      ok: false,
      code: "invalid-argument",
      shouldIncrementAttempts: false,
      shouldDelete: false,
      message: "Verification code must be exactly 6 digits.",
    };
  }

  if (!existingDoc || !existingDoc.otpHash || !existingDoc.salt) {
    return {
      ok: false,
      code: "not-found",
      shouldIncrementAttempts: false,
      shouldDelete: false,
      message: "No active OTP request found. Please request a new code.",
    };
  }

  if (typeof existingDoc.expiresAtMs === "number" && nowMs > existingDoc.expiresAtMs) {
    return {
      ok: false,
      code: "deadline-exceeded",
      shouldIncrementAttempts: false,
      shouldDelete: true,
      message: "This OTP has expired (5-minute limit). Please request a new code.",
    };
  }

  const failedAttempts = existingDoc.failedAttempts || 0;
  if (failedAttempts >= MAX_VERIFY_ATTEMPTS) {
    return {
      ok: false,
      code: "resource-exhausted",
      shouldIncrementAttempts: false,
      shouldDelete: false,
      message: "Too many incorrect OTP attempts. Please request a new verification code.",
    };
  }

  const matched = verifyOtpHash(otpCode.trim(), existingDoc.salt, existingDoc.otpHash);
  if (!matched) {
    const nextAttempts = failedAttempts + 1;
    const remaining = Math.max(0, MAX_VERIFY_ATTEMPTS - nextAttempts);
    return {
      ok: false,
      code: remaining > 0 ? "permission-denied" : "resource-exhausted",
      shouldIncrementAttempts: true,
      shouldDelete: false,
      nextAttempts,
      remainingAttempts: remaining,
      message:
        remaining > 0
          ? `Incorrect OTP code. ${remaining} attempt(s) remaining.`
          : "Too many incorrect OTP attempts. Please request a new verification code.",
    };
  }

  return {
    ok: true,
    shouldDelete: true,
  };
}

function buildOtpEmailPayload({ recipientEmail, displayName, otp, mode = "LOGIN" }) {
  const safeName = typeof displayName === "string" && displayName.trim() ? displayName.trim() : "there";
  const actionLabel = mode === "REGISTER" ? "complete your Whatsup registration" : "sign in to your Whatsup account";
  const subject = `${otp} is your Whatsup verification code`;

  const text = [
    `Hi ${safeName},`,
    "",
    `Use this 6-digit verification code to ${actionLabel}:`,
    "",
    `    ${otp}`,
    "",
    "This code expires in 5 minutes.",
    "For your security, never share this verification code with anyone.",
    "",
    "— Whatsup Security Team",
  ].join("\n");

  const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 520px; margin: 0 auto; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 14px; overflow: hidden;">
      <div style="background: #075E54; padding: 20px 24px; color: #ffffff;">
        <h2 style="margin: 0; font-size: 20px;">Whatsup Verification</h2>
        <p style="margin: 4px 0 0; font-size: 13px; opacity: 0.9;">Secure Gmail One-Time Password</p>
      </div>
      <div style="padding: 24px; color: #111827;">
        <p style="margin-top: 0; font-size: 15px;">Hi <strong>${escapeHtml(safeName)}</strong>,</p>
        <p style="font-size: 15px; line-height: 1.5;">Use the following 6-digit code to ${escapeHtml(actionLabel)} for <strong>${escapeHtml(recipientEmail)}</strong>:</p>
        <div style="margin: 22px 0; padding: 16px; background: #f0fdf4; border: 1px solid #25D366; border-radius: 10px; text-align: center;">
          <span style="font-size: 32px; font-weight: 700; letter-spacing: 8px; color: #075E54;">${otp}</span>
        </div>
        <p style="font-size: 13px; color: #4b5563;">This code expires in <strong>5 minutes</strong> and can only be used once.</p>
        <p style="font-size: 12px; color: #6b7280; margin-bottom: 0;">If you did not request this code, you can safely ignore this email. Never share this code with anyone.</p>
      </div>
    </div>
  `.trim();

  return { subject, text, html };
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

module.exports = {
  OTP_TTL_MS,
  RESEND_COOLDOWN_MS,
  REQUEST_WINDOW_MS,
  MAX_REQUESTS_PER_WINDOW,
  REQUEST_LOCKOUT_MS,
  MAX_VERIFY_ATTEMPTS,
  normalizeGmailAddress,
  hashEmailSha256,
  generateSecureOtp,
  hashOtp,
  verifyOtpHash,
  evaluateOtpRequestRateLimit,
  evaluateOtpVerification,
  buildOtpEmailPayload,
};
