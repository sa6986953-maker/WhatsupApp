const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const { getFirestore, FieldValue, Timestamp } = require("firebase-admin/firestore");
const crypto = require("node:crypto");
const {
  OTP_TTL_MS,
  RESEND_COOLDOWN_MS,
  normalizeGmailAddress,
  hashEmailSha256,
  generateSecureOtp,
  hashOtp,
  evaluateOtpRequestRateLimit,
  evaluateOtpVerification,
  buildOtpEmailPayload,
} = require("./otpHelpers");

admin.initializeApp();

const DATABASE_ID = "ai-studio-android-whatsup-d57b1d05-3425-4498-ab4e-81ce5934b965";
const db = getFirestore(DATABASE_ID);

// Stored securely in Firebase Functions Secrets Manager (never in Android APK/source).
const GMAIL_USER = defineSecret("GMAIL_USER");
const GMAIL_APP_PASSWORD = defineSecret("GMAIL_APP_PASSWORD");

const MAX_PIN_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

function assertSignedIn(request) {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError("unauthenticated", "Authentication required.");
  }
  return request.auth.uid;
}

function validatePinFormat(pin) {
  if (typeof pin !== "string" || !/^\d{6}$/.test(pin)) {
    throw new HttpsError("invalid-argument", "Two-step PIN must be exactly 6 digits.");
  }
}

function hashPinScrypt(pin, saltHex) {
  const derived = crypto.scryptSync(pin, Buffer.from(saltHex, "hex"), 64, {
    N: 16384,
    r: 8,
    p: 1,
  });
  return derived.toString("hex");
}

function constantTimeMatch(hexA, hexB) {
  const bufA = Buffer.from(hexA, "hex");
  const bufB = Buffer.from(hexB, "hex");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function createEmailTransporter() {
  const gmailUser = (GMAIL_USER.value() || process.env.GMAIL_USER || "").trim();
  const gmailPass = (GMAIL_APP_PASSWORD.value() || process.env.GMAIL_APP_PASSWORD || "").trim();
  if (!gmailUser || !gmailPass) {
    throw new HttpsError(
      "failed-precondition",
      "Email OTP delivery secrets (GMAIL_USER / GMAIL_APP_PASSWORD) are not configured on Firebase Functions."
    );
  }
  const nodemailer = require("nodemailer");
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === "true" : true,
    auth: {
      user: gmailUser,
      pass: gmailPass,
    },
  });
  return { transporter, senderAddress: gmailUser };
}

async function lookupAuthUserByEmail(email) {
  try {
    return await admin.auth().getUserByEmail(email);
  } catch (err) {
    if (err && err.code === "auth/user-not-found") {
      return null;
    }
    throw err;
  }
}

/**
 * Generates a cryptographically random 6-digit OTP, stores a salted HMAC hash with a 5-minute TTL,
 * enforces 60s resend cooldown + request limits, and emails the code via Nodemailer SMTP.
 */
exports.requestEmailOtp = onCall(
  { secrets: [GMAIL_USER, GMAIL_APP_PASSWORD] },
  async (request) => {
    const { email: rawEmail, mode: rawMode, displayName: rawDisplayName } = request.data || {};
    const mode = rawMode === "REGISTER" ? "REGISTER" : "LOGIN";
    const normalizedEmail = normalizeGmailAddress(rawEmail);
    if (!normalizedEmail) {
      throw new HttpsError(
        "invalid-argument",
        "Please enter a valid Gmail address (example@gmail.com)."
      );
    }

    const cleanName = typeof rawDisplayName === "string" ? rawDisplayName.trim().slice(0, 80) : "";
    if (mode === "REGISTER" && cleanName.length < 1) {
      throw new HttpsError("invalid-argument", "Please enter your full name to register.");
    }

    const emailHash = hashEmailSha256(normalizedEmail);
    const existingAuthUser = await lookupAuthUserByEmail(normalizedEmail);
    const dirSnap = await db.collection("emailDirectory").doc(emailHash).get();
    let hasUserProfile = dirSnap.exists;
    if (!hasUserProfile && existingAuthUser) {
      const profileSnap = await db.collection("users").doc(existingAuthUser.uid).get();
      hasUserProfile = profileSnap.exists;
    }

    if (mode === "REGISTER" && hasUserProfile) {
      throw new HttpsError(
        "already-exists",
        "This Gmail address is already registered on Whatsup. Switch to Sign In to log in."
      );
    }
    if (mode === "LOGIN" && !existingAuthUser && !dirSnap.exists) {
      throw new HttpsError(
        "not-found",
        "No Whatsup account found for this Gmail. Switch to Register to create a new account."
      );
    }

    const otpRef = db.collection("emailOtps").doc(emailHash);
    const otpSnap = await otpRef.get();
    const nowMs = Date.now();
    const rate = evaluateOtpRequestRateLimit(otpSnap.exists ? otpSnap.data() : null, nowMs);

    if (!rate.allowed) {
      if (rate.lockoutUntilMs && otpSnap.exists) {
        await otpRef.set(
          {
            requestLockedUntilMs: rate.lockoutUntilMs,
            requestCount: rate.nextCount || otpSnap.data().requestCount || 0,
            windowStartedAtMs: rate.windowStartedAtMs || nowMs,
            updatedAt: FieldValue.serverTimestamp(),
          },
          { merge: true }
        );
      }
      throw new HttpsError(rate.code, rate.message);
    }

    const { transporter, senderAddress } = createEmailTransporter();
    const otpCode = generateSecureOtp();
    const saltHex = crypto.randomBytes(16).toString("hex");
    const otpHash = hashOtp(otpCode, saltHex);

    const effectiveName = cleanName || existingAuthUser?.displayName || "";
    const mail = buildOtpEmailPayload({
      recipientEmail: normalizedEmail,
      displayName: effectiveName,
      otp: otpCode,
      mode,
    });

    try {
      await transporter.sendMail({
        from: `"Whatsup Security" <${senderAddress}>`,
        to: normalizedEmail,
        subject: mail.subject,
        text: mail.text,
        html: mail.html,
      });
    } catch (smtpError) {
      console.error("Failed to send Gmail OTP email:", smtpError);
      throw new HttpsError(
        "internal",
        "Unable to send verification email right now. Please verify email delivery configuration and try again."
      );
    }

    await otpRef.set({
      email: normalizedEmail,
      emailHash,
      mode,
      displayName: effectiveName,
      otpHash,
      salt: saltHex,
      expiresAtMs: nowMs + OTP_TTL_MS,
      resendAvailableAtMs: nowMs + RESEND_COOLDOWN_MS,
      requestCount: rate.nextCount,
      windowStartedAtMs: rate.windowStartedAtMs,
      requestLockedUntilMs: 0,
      failedAttempts: 0,
      createdAt: otpSnap.exists && otpSnap.data().createdAt ? otpSnap.data().createdAt : FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });

    return {
      ok: true,
      email: normalizedEmail,
      expiresInSeconds: Math.floor(OTP_TTL_MS / 1000),
      resendCooldownSeconds: Math.floor(RESEND_COOLDOWN_MS / 1000),
    };
  }
);

/**
 * Verifies the user's 6-digit Gmail OTP server-side (checking 5-minute TTL and 5-attempt limit),
 * ensures a unique Firebase Auth user exists for the verified Gmail, and returns a Firebase Custom Token.
 */
exports.verifyEmailOtp = onCall(async (request) => {
  const { email: rawEmail, otpCode, mode: rawMode, displayName: rawDisplayName } = request.data || {};
  const mode = rawMode === "REGISTER" ? "REGISTER" : "LOGIN";
  const normalizedEmail = normalizeGmailAddress(rawEmail);
  if (!normalizedEmail) {
    throw new HttpsError("invalid-argument", "Please enter a valid Gmail address.");
  }

  const emailHash = hashEmailSha256(normalizedEmail);
  const otpRef = db.collection("emailOtps").doc(emailHash);
  const nowMs = Date.now();

  let storedDisplayName = typeof rawDisplayName === "string" ? rawDisplayName.trim().slice(0, 80) : "";

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(otpRef);
    const data = snap.exists ? snap.data() : null;
    if (data && data.displayName && !storedDisplayName) {
      storedDisplayName = data.displayName;
    }
    const check = evaluateOtpVerification(data, String(otpCode || ""), nowMs);

    if (!check.ok) {
      if (check.shouldDelete && snap.exists) {
        tx.delete(otpRef);
      } else if (check.shouldIncrementAttempts && snap.exists) {
        tx.update(otpRef, {
          failedAttempts: check.nextAttempts,
          updatedAt: FieldValue.serverTimestamp(),
        });
      }
      throw new HttpsError(check.code, check.message);
    }

    // Single-use OTP: consume on verification
    tx.delete(otpRef);
  });

  let userRecord = await lookupAuthUserByEmail(normalizedEmail);
  if (!userRecord) {
    const createPayload = {
      email: normalizedEmail,
      emailVerified: true,
    };
    if (storedDisplayName) {
      createPayload.displayName = storedDisplayName;
    }
    userRecord = await admin.auth().createUser(createPayload);
  } else if (!userRecord.emailVerified || (storedDisplayName && !userRecord.displayName)) {
    userRecord = await admin.auth().updateUser(userRecord.uid, {
      emailVerified: true,
      ...(storedDisplayName && !userRecord.displayName ? { displayName: storedDisplayName } : {}),
    });
  }

  const uid = userRecord.uid;
  const userSnap = await db.collection("users").doc(uid).get();
  const hasProfile = userSnap.exists;
  const twoStepEnabled = hasProfile && userSnap.data()?.twoStepEnabled === true;

  const customToken = await admin.auth().createCustomToken(uid, {
    email: normalizedEmail,
    emailVerified: true,
    authMethod: "gmail_otp",
    mode,
  });

  return {
    ok: true,
    customToken,
    uid,
    email: normalizedEmail,
    isNewUser: !hasProfile,
    twoStepEnabled,
  };
});

/**
 * Sets or updates the user's 6-digit Two-Step Verification PIN using salted scrypt.
 * Never stores plaintext PINs anywhere on Firestore.
 */
exports.setTwoStepPin = onCall(async (request) => {
  const uid = assertSignedIn(request);
  const { pin, currentPin, recoveryHint } = request.data || {};
  validatePinFormat(pin);

  const privateRef = db.collection("users").doc(uid).collection("private").doc("twoStep");
  const userRef = db.collection("users").doc(uid);

  const existing = await privateRef.get();
  if (existing.exists && existing.data().pinHash) {
    const data = existing.data();
    if (data.lockedUntilMillis && Date.now() < data.lockedUntilMillis) {
      throw new HttpsError("resource-exhausted", "Too many failed attempts. Try again later.");
    }
    validatePinFormat(currentPin);
    const attemptHash = hashPinScrypt(currentPin, data.pinSalt);
    if (!constantTimeMatch(attemptHash, data.pinHash)) {
      const nextAttempts = (data.failedAttempts || 0) + 1;
      await privateRef.update({
        failedAttempts: nextAttempts,
        lockedUntilMillis: nextAttempts >= MAX_PIN_ATTEMPTS ? Date.now() + LOCKOUT_MS : 0,
        updatedAt: FieldValue.serverTimestamp(),
      });
      throw new HttpsError("permission-denied", "Current Two-Step PIN is incorrect.");
    }
  }

  const saltHex = crypto.randomBytes(16).toString("hex");
  const pinHash = hashPinScrypt(pin, saltHex);

  const batch = db.batch();
  batch.set(privateRef, {
    pinHash,
    pinSalt: saltHex,
    algorithm: "scrypt-N16384-r8-p1",
    failedAttempts: 0,
    lockedUntilMillis: 0,
    recoveryHint: typeof recoveryHint === "string" ? recoveryHint.trim().slice(0, 120) : "",
    updatedAt: FieldValue.serverTimestamp(),
  });
  batch.update(userRef, {
    twoStepEnabled: true,
    updatedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();

  return { ok: true, twoStepEnabled: true };
});

/**
 * Verifies the 6-digit Two-Step Verification PIN on a new device or session.
 * Enforces 5-attempt exponential lockout on server.
 */
exports.verifyTwoStepPin = onCall(async (request) => {
  const uid = assertSignedIn(request);
  const { pin } = request.data || {};
  validatePinFormat(pin);

  const privateRef = db.collection("users").doc(uid).collection("private").doc("twoStep");
  const snap = await privateRef.get();
  if (!snap.exists || !snap.data().pinHash) {
    return { verified: true, twoStepEnabled: false };
  }

  const data = snap.data();
  const nowMs = Date.now();
  if (data.lockedUntilMillis && nowMs < data.lockedUntilMillis) {
    const minsLeft = Math.ceil((data.lockedUntilMillis - nowMs) / 60000);
    throw new HttpsError(
      "resource-exhausted",
      `Two-step PIN locked after repeated failures. Try again in ${minsLeft} min.`
    );
  }

  const candidateHash = hashPinScrypt(pin, data.pinSalt);
  if (!constantTimeMatch(candidateHash, data.pinHash)) {
    const nextAttempts = (data.failedAttempts || 0) + 1;
    const lockedUntil = nextAttempts >= MAX_PIN_ATTEMPTS ? nowMs + LOCKOUT_MS : 0;
    await privateRef.update({
      failedAttempts: nextAttempts,
      lockedUntilMillis: lockedUntil,
      updatedAt: FieldValue.serverTimestamp(),
    });
    const remaining = Math.max(0, MAX_PIN_ATTEMPTS - nextAttempts);
    throw new HttpsError(
      "permission-denied",
      remaining > 0
        ? `Incorrect PIN. ${remaining} attempt(s) remaining.`
        : "Too many incorrect attempts. Locked for 15 minutes."
    );
  }

  await privateRef.update({
    failedAttempts: 0,
    lockedUntilMillis: 0,
    lastVerifiedAt: FieldValue.serverTimestamp(),
  });

  return { verified: true, twoStepEnabled: true };
});

/**
 * Disables Two-Step Verification after validating the current PIN.
 */
exports.disableTwoStepPin = onCall(async (request) => {
  const uid = assertSignedIn(request);
  const { currentPin } = request.data || {};
  validatePinFormat(currentPin);

  const privateRef = db.collection("users").doc(uid).collection("private").doc("twoStep");
  const userRef = db.collection("users").doc(uid);
  const snap = await privateRef.get();
  if (!snap.exists || !snap.data().pinHash) {
    await userRef.update({ twoStepEnabled: false, updatedAt: FieldValue.serverTimestamp() });
    return { ok: true, twoStepEnabled: false };
  }

  const data = snap.data();
  const candidateHash = hashPinScrypt(currentPin, data.pinSalt);
  if (!constantTimeMatch(candidateHash, data.pinHash)) {
    throw new HttpsError("permission-denied", "Incorrect Two-Step PIN.");
  }

  const batch = db.batch();
  batch.delete(privateRef);
  batch.update(userRef, {
    twoStepEnabled: false,
    updatedAt: FieldValue.serverTimestamp(),
  });
  await batch.commit();

  return { ok: true, twoStepEnabled: false };
});

/**
 * Resets Two-Step Verification after a recovery hint match.
 */
exports.recoverTwoStepPin = onCall(async (request) => {
  const uid = assertSignedIn(request);
  const { recoveryHint, newPin } = request.data || {};
  validatePinFormat(newPin);

  const privateRef = db.collection("users").doc(uid).collection("private").doc("twoStep");
  const snap = await privateRef.get();
  if (!snap.exists) {
    throw new HttpsError("not-found", "Two-Step Verification is not active on this account.");
  }
  const savedHint = (snap.data().recoveryHint || "").trim().toLowerCase();
  if (savedHint && typeof recoveryHint === "string" && recoveryHint.trim().toLowerCase() !== savedHint) {
    throw new HttpsError("permission-denied", "Recovery answer does not match.");
  }

  const saltHex = crypto.randomBytes(16).toString("hex");
  const pinHash = hashPinScrypt(newPin, saltHex);
  await privateRef.set({
    pinHash,
    pinSalt: saltHex,
    algorithm: "scrypt-N16384-r8-p1",
    failedAttempts: 0,
    lockedUntilMillis: 0,
    recoveryHint: savedHint,
    updatedAt: FieldValue.serverTimestamp(),
  });

  return { ok: true };
});

/**
 * Sends FCM push notification when a new message is created in a conversation.
 */
exports.onConversationMessageCreated = onDocumentCreated(
  {
    document: "conversations/{conversationId}/messages/{messageId}",
    database: DATABASE_ID,
  },
  async (event) => {
    const msg = event.data?.data();
    if (!msg) return;
    const conversationId = event.params.conversationId;
    const convSnap = await db.collection("conversations").doc(conversationId).get();
    if (!convSnap.exists) return;

    const conv = convSnap.data();
    const recipients = (conv.participantUids || []).filter((u) => u !== msg.senderUid);
    if (recipients.length === 0) return;

    const tokens = [];
    for (const uid of recipients) {
      const muted = conv.mutedBy && conv.mutedBy[uid] === true;
      if (muted) continue;
      const blockedSnap = await db.collection("users").doc(uid).collection("blocked").doc(msg.senderUid).get();
      if (blockedSnap.exists) continue;
      const userSnap = await db.collection("users").doc(uid).get();
      const token = userSnap.data()?.fcmToken;
      if (token) tokens.push(token);
    }
    if (tokens.length === 0) return;

    const bodyText = msg.ciphertext
      ? "New end-to-end encrypted message"
      : (msg.text || "New message").slice(0, 120);

    await admin.messaging().sendEachForMulticast({
      tokens,
      notification: {
        title: conv.type === "DIRECT" ? msg.senderName : `${conv.title} • ${msg.senderName}`,
        body: bodyText,
      },
      data: {
        type: conv.type === "DIRECT" ? "MESSAGE" : "MENTION",
        conversationId,
        messageId: event.params.messageId,
      },
      android: { priority: "high" },
    });
  }
);

/**
 * Sends high-priority FCM push notification when an incoming WebRTC call starts.
 */
exports.onIncomingCallCreated = onDocumentCreated(
  {
    document: "calls/{callId}",
    database: DATABASE_ID,
  },
  async (event) => {
    const call = event.data?.data();
    if (!call || call.status !== "RINGING") return;

    const targetUid = call.calleeUid;
    if (!targetUid || targetUid === call.callerUid) return;

    const blockedSnap = await db.collection("users").doc(targetUid).collection("blocked").doc(call.callerUid).get();
    if (blockedSnap.exists) return;

    const userSnap = await db.collection("users").doc(targetUid).get();
    const token = userSnap.data()?.fcmToken;
    if (!token) return;

    await admin.messaging().send({
      token,
      notification: {
        title: `Incoming ${call.callType === "VIDEO" ? "Video" : "Voice"} Call`,
        body: `${call.callerName} is calling on Whatsup`,
      },
      data: {
        type: "CALL",
        callId: event.params.callId,
        callerName: call.callerName || "",
        callType: call.callType || "VOICE",
      },
      android: { priority: "high" },
    });
  }
);

/**
 * Scheduled hourly cleanup for expired 24-hour Status updates.
 */
exports.cleanupExpiredStatuses = onSchedule("every 60 minutes", async () => {
  const now = Timestamp.now();
  const expired = await db.collection("statuses").where("expiresAt", "<=", now).limit(200).get();
  if (expired.empty) return;
  const batch = db.batch();
  expired.docs.forEach((doc) => batch.delete(doc.ref));
  await batch.commit();
});
