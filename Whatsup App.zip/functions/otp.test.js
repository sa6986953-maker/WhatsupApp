const { test } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const {
  OTP_TTL_MS,
  RESEND_COOLDOWN_MS,
  MAX_REQUESTS_PER_WINDOW,
  MAX_VERIFY_ATTEMPTS,
  normalizeGmailAddress,
  hashEmailSha256,
  generateSecureOtp,
  hashOtp,
  verifyOtpHash,
  evaluateOtpRequestRateLimit,
  evaluateOtpVerification,
  buildOtpEmailPayload,
} = require("./otpHelpers");

test("normalizeGmailAddress validates canonical Gmail addresses only", () => {
  assert.equal(normalizeGmailAddress("  Alice.Khan@GMAIL.COM "), "alice.khan@gmail.com");
  assert.equal(normalizeGmailAddress("user+whatsup@googlemail.com"), "user+whatsup@googlemail.com");
  assert.equal(normalizeGmailAddress("alice@yahoo.com"), null);
  assert.equal(normalizeGmailAddress("..bad@gmail.com"), null);
  assert.equal(normalizeGmailAddress("bad..dot@gmail.com"), null);
  assert.equal(normalizeGmailAddress("not-an-email"), null);
  assert.equal(normalizeGmailAddress(""), null);
});

test("generateSecureOtp produces random 6-digit codes and verifies via salted HMAC", () => {
  const codes = new Set();
  for (let i = 0; i < 25; i++) {
    const otp = generateSecureOtp();
    assert.match(otp, /^\d{6}$/);
    codes.add(otp);
  }
  assert.ok(codes.size > 1, "OTP generator must produce non-constant random values");

  const salt = crypto.randomBytes(16).toString("hex");
  const otp = "492817";
  const digest = hashOtp(otp, salt);
  assert.equal(verifyOtpHash(otp, salt, digest), true);
  assert.equal(verifyOtpHash("492818", salt, digest), false);
});

test("evaluateOtpRequestRateLimit enforces 60s resend cooldown and max 5 requests per window", () => {
  const t0 = 1_700_000_000_000;
  const first = evaluateOtpRequestRateLimit(null, t0);
  assert.equal(first.allowed, true);
  assert.equal(first.nextCount, 1);

  const tooSoon = evaluateOtpRequestRateLimit(
    {
      resendAvailableAtMs: t0 + RESEND_COOLDOWN_MS,
      requestCount: 1,
      windowStartedAtMs: t0,
    },
    t0 + 15_000
  );
  assert.equal(tooSoon.allowed, false);
  assert.equal(tooSoon.code, "resource-exhausted");
  assert.equal(tooSoon.retryAfterSeconds, 45);

  const afterCooldown = evaluateOtpRequestRateLimit(
    {
      resendAvailableAtMs: t0 + RESEND_COOLDOWN_MS,
      requestCount: 1,
      windowStartedAtMs: t0,
    },
    t0 + RESEND_COOLDOWN_MS + 100
  );
  assert.equal(afterCooldown.allowed, true);
  assert.equal(afterCooldown.nextCount, 2);

  const exceeded = evaluateOtpRequestRateLimit(
    {
      resendAvailableAtMs: t0 + RESEND_COOLDOWN_MS,
      requestCount: MAX_REQUESTS_PER_WINDOW,
      windowStartedAtMs: t0,
    },
    t0 + RESEND_COOLDOWN_MS + 1000
  );
  assert.equal(exceeded.allowed, false);
  assert.ok(exceeded.lockoutUntilMs > t0);
});

test("evaluateOtpVerification enforces 5-minute TTL, max 5 wrong attempts, and single-use match", () => {
  const t0 = 1_700_000_000_000;
  const salt = crypto.randomBytes(16).toString("hex");
  const otp = "731904";
  const doc = {
    salt,
    otpHash: hashOtp(otp, salt),
    expiresAtMs: t0 + OTP_TTL_MS,
    failedAttempts: 0,
  };

  // Wrong code increments failedAttempts
  const wrong = evaluateOtpVerification(doc, "000000", t0 + 10_000);
  assert.equal(wrong.ok, false);
  assert.equal(wrong.shouldIncrementAttempts, true);
  assert.equal(wrong.nextAttempts, 1);
  assert.equal(wrong.remainingAttempts, MAX_VERIFY_ATTEMPTS - 1);

  // Max attempts reached blocks even correct code
  const locked = evaluateOtpVerification(
    { ...doc, failedAttempts: MAX_VERIFY_ATTEMPTS },
    otp,
    t0 + 10_000
  );
  assert.equal(locked.ok, false);
  assert.equal(locked.code, "resource-exhausted");

  // Expired after 5 minutes
  const expired = evaluateOtpVerification(doc, otp, t0 + OTP_TTL_MS + 1);
  assert.equal(expired.ok, false);
  assert.equal(expired.code, "deadline-exceeded");
  assert.equal(expired.shouldDelete, true);

  // Valid within window
  const valid = evaluateOtpVerification(doc, otp, t0 + 30_000);
  assert.equal(valid.ok, true);
  assert.equal(valid.shouldDelete, true);
});

test("buildOtpEmailPayload includes recipient, code, and 5-minute expiry notice", () => {
  const email = buildOtpEmailPayload({
    recipientEmail: "test.user@gmail.com",
    displayName: "Zainab",
    otp: "654321",
    mode: "REGISTER",
  });
  assert.ok(email.subject.includes("654321"));
  assert.ok(email.text.includes("654321"));
  assert.ok(email.text.includes("5 minutes"));
  assert.ok(email.html.includes("test.user@gmail.com"));
  assert.equal(hashEmailSha256("test.user@gmail.com").length, 64);
});
