# Whatsup — Firebase, Gmail OTP, WebRTC & Build Setup Guide

## 1. Prerequisites
- Android Gradle Plugin & Kotlin project (`com.aistudio.whatsup.kpkzmr`, namespace `com.example`)
- Firebase project (`gen-lang-client-0880643831`) configured via `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml`
- Named Firestore database ID: `ai-studio-android-whatsup-d57b1d05-3425-4498-ab4e-81ce5934b965`
- Firebase CLI (`npm install -g firebase-tools`) logged into your project (`firebase login`)

---

## 2. Configure Gmail OTP Email Delivery & Secrets (Server-Side Only)
Whatsup uses Firebase Cloud Functions (`requestEmailOtp` and `verifyEmailOtp`) to generate cryptographically random 6-digit OTPs (`crypto.randomInt`), hash them with HMAC-SHA256 in Firestore (`/emailOtps/{emailHash}` with `allow read, write: if false`), send the email via Nodemailer + Gmail SMTP, and issue a Firebase Custom Auth token (`admin.auth().createCustomToken(uid)`).

**Never put Gmail passwords, SMTP credentials, or OTP codes inside the Android source code.**

1. **Create a Google App Password** for your sender Gmail account:
   - Enable **2-Step Verification** on the Google Account you want to send emails from.
   - Go to **Google Account → Security → App passwords** and generate a 16-character App Password (e.g., `abcd efgh ijkl mnop`).

2. **Store credentials in Firebase Functions Secrets Manager**:
   ```bash
   firebase functions:secrets:set GMAIL_USER
   # Enter your sender Gmail address (e.g., yourapp.noreply@gmail.com)

   firebase functions:secrets:set GMAIL_APP_PASSWORD
   # Enter the 16-character Google App Password (no spaces)
   ```

3. **Grant Token Creator IAM Role for Custom Token Minting**:
   Cloud Functions v2 (`verifyEmailOtp`) calls `admin.auth().createCustomToken(uid)`. Ensure the Cloud Functions runtime service account (`<PROJECT_NUMBER>-compute@developer.gserviceaccount.com`) has the **Service Account Token Creator** (`roles/iam.serviceAccountTokenCreator`) role in IAM:
   ```bash
   gcloud projects add-iam-policy-binding gen-lang-client-0880643831 \
     --member="serviceAccount:<PROJECT_NUMBER>-compute@developer.gserviceaccount.com" \
     --role="roles/iam.serviceAccountTokenCreator"
   ```
   *(You can also assign **Service Account Token Creator** via Google Cloud Console → IAM & Admin → IAM).*

4. **Authentication Providers (Optional Google Linking)**:
   - Custom Tokens (`signInWithCustomToken`) work out of the box once the Admin SDK + Token Creator role is enabled.
   - *(Optional)* Keep **Google** enabled in **Firebase Console → Authentication → Sign-in method** if users will link a Google account in **Settings → Backup & Account**.
   - Register your debug and release signing certificate **SHA-1** and **SHA-256** fingerprints under **Firebase Console → Project Settings → Your apps → Android (`com.aistudio.whatsup.kpkzmr`)**:
     ```bash
     keytool -list -v -keystore debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```

---

## 3. Deploy Firestore Rules, Composite Indexes & Storage Rules
The workspace includes `/firebase.json`, `/firestore.rules`, `/firestore.indexes.json`, and `/storage.rules`. Deploy them together:
```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
```

### Key Collections & Indexes
- `/emailOtps/{emailHash}` — Client read/write completely blocked (`allow read, write: if false`). Managed exclusively by `requestEmailOtp` and `verifyEmailOtp`.
- `/emailDirectory/{emailHash}` — Point lookup (`allow get` for signed-in users; `allow list: if false`) for finding verified Whatsup contacts by Gmail address.
- `conversations`: `participantUids` (CONTAINS) + `sortOrder` (DESCENDING)
- `statuses`: `allowedUids` (CONTAINS) + `createdAt` (DESCENDING)
- `calls`: `participantUids` (CONTAINS) + `createdAt` (DESCENDING)

---

## 4. Deploy Cloud Functions (`/functions`)
`/functions/index.js` implements:
- `requestEmailOtp` — Normalizes `@gmail.com`/`@googlemail.com`, enforces 60s resend cooldown and 5 requests per 30-min window (15-min lockout), generates a secure random 6-digit OTP (`crypto.randomInt`), stores salted HMAC-SHA256 hash with 5-minute TTL, and sends email via `nodemailer` using `GMAIL_USER` & `GMAIL_APP_PASSWORD` secrets.
- `verifyEmailOtp` — Transactionally verifies the 6-digit OTP (max 5 wrong attempts, 5-minute expiry), looks up or creates the Firebase Auth user by verified email, and returns a Firebase Custom Token for `signInWithCustomToken`.
- `setTwoStepPin`, `verifyTwoStepPin`, `disableTwoStepPin`, `recoverTwoStepPin` — Salted `scrypt` 6-digit PIN hashing, 5-attempt lockout for 15 minutes, zero plaintext storage.
- `onMessageCreatedNotify` & `onCallCreatedNotify` — High-priority FCM alerts.
- `cleanupExpiredStatuses` — Scheduled hourly purge of expired 24-hour status documents & viewer subcollections.

Install dependencies and deploy (requires Firebase Blaze plan for Cloud Functions v2 & Secrets Manager):
```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

---

## 5. Configure WebRTC TURN Server (NAT Traversal for Calls)
By default, `WebRtcCallManager` uses `stun:stun.l.google.com:19302` and `stun:stun1.l.google.com:19302`.
For calls across carrier-grade NAT / symmetric firewalls:
1. Provision a coturn / metered.ca / Twilio TURN server.
2. Open **Whatsup → Settings → WebRTC TURN Server** in the app and enter your `turn:host:3478` URI, username, and credential.

---

## 6. Build & Test Locally
```bash
# Run Cloud Functions Gmail OTP unit tests
node --test functions/otp.test.js

# Run Android JVM & Robolectric unit tests (EmailUtils, Rate Limits, Crypto, LocalStore)
gradle :app:testDebugUnitTest

# Verify Firestore security rules against emulator
firebase emulators:exec --only firestore "node --test firestore.test.js"

# Build debug APK
gradle :app:assembleDebug
```

---

## 7. GitHub Actions APK Build (`/.github/workflows/android-apk.yml`)
Every push or pull request to `main`/`master` runs:
1. `node --test functions/otp.test.js`
2. `gradle :app:testDebugUnitTest`
3. `gradle :app:assembleDebug` and uploads `whatsup-debug-apk` (`app-debug.apk`).

Optional repository secrets for CI:
- `GOOGLE_SERVICES_JSON_BASE64` (if overriding `app/google-services.json`)
- `DEBUG_KEYSTORE_BASE64`
- `RELEASE_KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_PASSWORD` (to also build and upload signed `app-release.apk`).
