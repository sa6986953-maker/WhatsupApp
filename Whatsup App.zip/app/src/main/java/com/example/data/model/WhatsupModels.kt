package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class PrivacyAudience(val value: String, val label: String) {
    EVERYONE("EVERYONE", "Everyone"),
    CONTACTS("CONTACTS", "My Contacts"),
    NOBODY("NOBODY", "Nobody");

    companion object {
        fun from(raw: String?): PrivacyAudience =
            entries.firstOrNull { it.value == raw } ?: EVERYONE
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val emailHash: String = "",
    val emailVerified: Boolean = false,
    val phoneE164: String = "",
    val phoneHash: String = "",
    val about: String = "Hey there! I am using Whatsup.",
    val photoUrl: String = "",
    val identityPublicKey: String = "",
    val fcmToken: String = "",
    val twoStepEnabled: Boolean = false,
    val online: Boolean = false,
    val lastSeenAt: Long = 0L,
    val lastSeenPrivacy: String = PrivacyAudience.EVERYONE.value,
    val onlinePrivacy: String = PrivacyAudience.EVERYONE.value,
    val photoPrivacy: String = PrivacyAudience.EVERYONE.value,
    val aboutPrivacy: String = PrivacyAudience.EVERYONE.value,
    val hideBlueTicks: Boolean = false,
    val dataSaver: Boolean = false,
    val appLockEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val phoneNumber: String get() = phoneE164
    val hideOnline: Boolean get() = onlinePrivacy == PrivacyAudience.NOBODY.value
    val hideLastSeen: Boolean get() = lastSeenPrivacy == PrivacyAudience.NOBODY.value
}

@Keep
@IgnoreExtraProperties
data class VerifiedContact(
    @DocumentId val id: String = "",
    val contactUid: String = "",
    val savedName: String = "",
    val email: String = "",
    val emailHash: String = "",
    val phoneE164: String = "",
    val phoneHash: String = "",
    val photoUrl: String = "",
    val about: String = "",
    val identityPublicKey: String = "",
    val online: Boolean = false,
    val lastSeenAt: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BlockedUser(
    @DocumentId val id: String = "",
    val blockedUid: String = "",
    val email: String = "",
    val phoneE164: String = "",
    val displayName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class ChatThread(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val phone: String = "",
    val peerUid: String = "",
    val peerIdentityPublicKey: String = "",
    val participantUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val createdByUid: String = "",
    val groupDescription: String = "",
    val groupPhotoUrl: String = "",
    val inviteCode: String? = null,
    val avatarColorHex: Long = 0xFF128C7EL,
    val chatType: String = "DIRECT", // DIRECT, GROUP, COMMUNITY, BLUETOOTH_GROUP
    val lastMessage: String = "",
    val lastMessageTimeLabel: String = "",
    val lastMessageTick: String = "SENT", // PENDING_SYNC, SENT, DELIVERED, READ, BLUETOOTH
    val unreadCount: Long = 0L,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val muted: Boolean = false,
    val locked: Boolean = false,
    val online: Boolean = false,
    val typing: Boolean = false,
    val lastSeenText: String = "",
    val disappearingMode: String = "OFF", // OFF, 24H, 7D, 90D
    val wallpaperStyle: String = "DEFAULT",
    val memberCount: Long = 2L,
    val communityName: String? = null,
    val onlyAdminCanSend: Boolean = false,
    val bluetoothChat: Boolean = false,
    val encryptionCode: String = "",
    val wrappedGroupKeys: Map<String, String> = emptyMap(),
    val sortOrder: Long = 0L,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class ChatMessage(
    val id: String = "",
    val userId: String = "",
    val chatId: String = "",
    val senderName: String = "",
    val senderPhone: String = "",
    val fromMe: Boolean = true,
    val text: String = "",
    val ciphertext: String? = null,
    val iv: String? = null,
    val messageType: String = "TEXT", // TEXT, VOICE, IMAGE_HD, VIDEO, DOCUMENT, LOCATION, CONTACT, POLL, EVENT, VIEW_ONCE, STICKER, GIF
    val tickStatus: String = "SENT", // PENDING_SYNC, SENT, DELIVERED, READ
    val viaBluetooth: Boolean = false,
    val edited: Boolean = false,
    val editedAtMillis: Long? = null,
    val starred: Boolean = false,
    val deletedForEveryone: Boolean = false,
    val deletedForMe: Boolean = false,
    val viewOnceOpened: Boolean = false,
    val replyToText: String? = null,
    val replyToSender: String? = null,
    val mediaStoragePath: String? = null,
    val mediaKeyBase64: String? = null,
    val mediaMeta: String? = null,
    val expiresAtMillis: Long? = null,
    val scheduledForMillis: Long? = null,
    val reactions: Map<String, Long> = emptyMap(),
    val uidReactions: Map<String, String> = emptyMap(),
    val myReaction: String = "",
    val timeLabel: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

object MessageReactionHelper {
    val quickEmojis: List<String> = listOf("❤️", "👍", "😂", "😮", "😢", "🙏")

    fun computeToggledReactions(
        currentReactions: Map<String, Long>,
        currentMyReaction: String,
        emoji: String
    ): Pair<Map<String, Long>, String> {
        val nextCounts = currentReactions.toMutableMap()
        if (currentMyReaction == emoji) {
            val decremented = (nextCounts[emoji] ?: 1L) - 1L
            if (decremented > 0L) {
                nextCounts[emoji] = decremented
            } else {
                nextCounts.remove(emoji)
            }
            return nextCounts to ""
        }

        if (currentMyReaction.isNotBlank()) {
            val prevDecremented = (nextCounts[currentMyReaction] ?: 1L) - 1L
            if (prevDecremented > 0L) {
                nextCounts[currentMyReaction] = prevDecremented
            } else {
                nextCounts.remove(currentMyReaction)
            }
        }
        nextCounts[emoji] = (nextCounts[emoji] ?: 0L) + 1L
        return nextCounts to emoji
    }

    fun toggleUidReaction(
        currentUidReactions: Map<String, String>,
        uid: String,
        emoji: String
    ): Map<String, String> {
        val updated = currentUidReactions.toMutableMap()
        if (updated[uid] == emoji) {
            updated.remove(uid)
        } else {
            updated[uid] = emoji
        }
        return updated
    }

    fun summarizeByEmoji(
        uidReactions: Map<String, String>,
        myUid: String
    ): Pair<Map<String, Long>, String> {
        val counts = mutableMapOf<String, Long>()
        uidReactions.values.forEach { emoji ->
            if (emoji.isNotBlank()) {
                counts[emoji] = (counts[emoji] ?: 0L) + 1L
            }
        }
        return counts to (uidReactions[myUid] ?: "")
    }
}

data class StatusUpdate(
    val id: String = "",
    val userId: String = "",
    val ownerPhoneE164: String = "",
    val authorName: String = "",
    val caption: String = "",
    val mediaUrl: String = "",
    val statusType: String = "TEXT", // TEXT, PHOTO, VIDEO
    val bgColorHex: Long = 0xFF075E54,
    val privacyMode: String = "ALL_CONTACTS", // ALL_CONTACTS, EXCEPT, ONLY_SHARE_WITH
    val allowedUids: List<String> = emptyList(),
    val excludedUids: List<String> = emptyList(),
    val viewedByCount: Long = 0L,
    val viewersSummary: String = "",
    val timeLabel: String = "",
    val viewed: Boolean = false,
    val expiresAtMillis: Long = 0L,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class StatusViewer(
    val viewerUid: String = "",
    val viewerName: String = "",
    val viewedAtMillis: Long = 0L
)

data class CallRecord(
    val id: String = "",
    val userId: String = "",
    val callerUid: String = "",
    val callerName: String = "",
    val calleeUid: String = "",
    val calleeName: String = "",
    val peerUid: String = "",
    val peerName: String = "",
    val callType: String = "VOICE", // VOICE, VIDEO, GROUP_VOICE, GROUP_VIDEO
    val direction: String = "OUTGOING", // INCOMING, OUTGOING, MISSED
    val status: String = "ENDED", // RINGING, ACCEPTED, REJECTED, ENDED, MISSED
    val offerSdp: String? = null,
    val answerSdp: String? = null,
    val durationSeconds: Long = 0L,
    val durationLabel: String = "0:00",
    val participantUids: List<String> = emptyList(),
    val participantCount: Long = 2L,
    val callLinkCode: String? = null,
    val recorded: Boolean = false,
    val timeLabel: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class NearbyBluetoothPeer(
    val peerId: String,
    val name: String,
    val phoneHint: String,
    val distanceMeters: Int,
    val transport: String,
    val signalBars: Int,
    val connected: Boolean = false
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
