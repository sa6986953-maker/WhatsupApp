package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import com.google.firebase.functions.functions
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private const val TAG = "AuthRepository"

enum class GmailAuthMode {
    REGISTER,
    LOGIN
}

data class EmailOtpRequestResult(
    val email: String,
    val expiresInSeconds: Int,
    val resendCooldownSeconds: Int
)

data class EmailOtpVerifyResult(
    val user: FirebaseUser,
    val email: String,
    val isNewUser: Boolean,
    val twoStepEnabled: Boolean
)

class AuthRepository(
    private val auth: FirebaseAuth = Firebase.auth,
    private val functions: FirebaseFunctions = Firebase.functions
) {
    fun observeAuthUser(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun currentUser(): FirebaseUser? = auth.currentUser

    /**
     * Calls the Firebase Cloud Function `requestEmailOtp` to generate a secure random 6-digit OTP
     * on the server and deliver it to the user's Gmail inbox via Nodemailer SMTP.
     */
    suspend fun requestEmailOtp(
        email: String,
        mode: GmailAuthMode,
        displayName: String = ""
    ): Result<EmailOtpRequestResult> {
        return try {
            val payload = hashMapOf<String, Any>(
                "email" to email,
                "mode" to mode.name,
                "displayName" to displayName.trim()
            )
            val response = functions.getHttpsCallable("requestEmailOtp").call(payload).await()
            @Suppress("UNCHECKED_CAST")
            val data = response.getData() as? Map<String, Any> ?: emptyMap()
            val normalizedEmail = (data["email"] as? String) ?: email
            val expiresInSeconds = (data["expiresInSeconds"] as? Number)?.toInt() ?: 300
            val resendCooldownSeconds = (data["resendCooldownSeconds"] as? Number)?.toInt() ?: 60
            Result.success(
                EmailOtpRequestResult(
                    email = normalizedEmail,
                    expiresInSeconds = expiresInSeconds,
                    resendCooldownSeconds = resendCooldownSeconds
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "requestEmailOtp failed: ${e.message}", e)
            Result.failure(IllegalStateException(mapOtpFunctionsError(e)))
        }
    }

    /**
     * Verifies the 6-digit OTP on the server (`verifyEmailOtp`), receives a minted Firebase Custom Token
     * for the verified Gmail user, and establishes an authenticated Firebase Auth session.
     */
    suspend fun verifyEmailOtp(
        email: String,
        otpCode: String,
        mode: GmailAuthMode,
        displayName: String = ""
    ): Result<EmailOtpVerifyResult> {
        return try {
            val payload = hashMapOf<String, Any>(
                "email" to email,
                "otpCode" to otpCode.trim(),
                "mode" to mode.name,
                "displayName" to displayName.trim()
            )
            val response = functions.getHttpsCallable("verifyEmailOtp").call(payload).await()
            @Suppress("UNCHECKED_CAST")
            val data = response.getData() as? Map<String, Any>
                ?: return Result.failure(IllegalStateException("Unexpected verification response from server."))

            val customToken = data["customToken"] as? String
            if (customToken.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Verification succeeded without a session token."))
            }

            val authResult = auth.signInWithCustomToken(customToken).await()
            val user = authResult.user
                ?: return Result.failure(IllegalStateException("Firebase sign-in returned no authenticated user."))

            val verifiedEmail = (data["email"] as? String) ?: email
            val isNewUser = data["isNewUser"] as? Boolean ?: true
            val twoStepEnabled = data["twoStepEnabled"] as? Boolean ?: false

            Result.success(
                EmailOtpVerifyResult(
                    user = user,
                    email = verifiedEmail,
                    isNewUser = isNewUser,
                    twoStepEnabled = twoStepEnabled
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "verifyEmailOtp failed: ${e.message}", e)
            Result.failure(IllegalStateException(mapOtpFunctionsError(e)))
        }
    }

    data class AuthProfileMeta(
        val hasProfile: Boolean,
        val twoStepEnabled: Boolean,
        val displayName: String = "",
        val about: String = ""
    )

    suspend fun fetchProfileMeta(
        db: FirebaseFirestore,
        uid: String
    ): AuthProfileMeta {
        return try {
            val snap = db.collection("users").document(uid).get().await()
            if (!snap.exists()) {
                AuthProfileMeta(hasProfile = false, twoStepEnabled = false)
            } else {
                AuthProfileMeta(
                    hasProfile = true,
                    twoStepEnabled = snap.getBoolean("twoStepEnabled") == true,
                    displayName = snap.getString("displayName").orEmpty(),
                    about = snap.getString("about").orEmpty()
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed checking user profile / 2FA status: ${e.message}")
            AuthProfileMeta(hasProfile = false, twoStepEnabled = false)
        }
    }

    suspend fun checkHasProfileAndTwoStep(
        db: FirebaseFirestore,
        uid: String
    ): Pair<Boolean, Boolean> {
        val meta = fetchProfileMeta(db, uid)
        return meta.hasProfile to meta.twoStepEnabled
    }

    suspend fun setTwoStepPinServerSide(
        pin: String,
        currentPin: String? = null,
        recoveryHint: String = ""
    ): Result<Unit> {
        return try {
            val payload = hashMapOf<String, Any>(
                "pin" to pin,
                "recoveryHint" to recoveryHint.trim()
            ).apply {
                if (!currentPin.isNullOrBlank()) put("currentPin", currentPin)
            }
            functions.getHttpsCallable("setTwoStepPin").call(payload).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapTwoStepFunctionsError(e)))
        }
    }

    suspend fun verifyTwoStepPinServerSide(pin: String): Result<Boolean> {
        return try {
            val res = functions.getHttpsCallable("verifyTwoStepPin")
                .call(mapOf("pin" to pin))
                .await()
            @Suppress("UNCHECKED_CAST")
            val data = res.getData() as? Map<String, Any>
            val verified = data?.get("verified") as? Boolean ?: true
            Result.success(verified)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapTwoStepFunctionsError(e)))
        }
    }

    suspend fun disableTwoStepPinServerSide(currentPin: String): Result<Unit> {
        return try {
            functions.getHttpsCallable("disableTwoStepPin")
                .call(mapOf("currentPin" to currentPin))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapTwoStepFunctionsError(e)))
        }
    }

    suspend fun recoverTwoStepPinServerSide(recoveryHint: String, newPin: String): Result<Unit> {
        return try {
            functions.getHttpsCallable("recoverTwoStepPin")
                .call(mapOf("recoveryHint" to recoveryHint, "newPin" to newPin))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapTwoStepFunctionsError(e)))
        }
    }

    /**
     * Optional Google Sign-In linking (or backup sign-in) via Credential Manager.
     */
    suspend fun linkOrSignInWithGoogleOptional(activity: Activity): Result<FirebaseUser> {
        val clientId = try {
            activity.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            return Result.failure(IllegalStateException("Google OAuth web client ID is not configured."))
        }
        val credentialManager = CredentialManager.create(activity)
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()
        return try {
            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                val googleCred = GoogleAuthProvider.getCredential(token, null)
                val existingUser = auth.currentUser
                val authResult = if (existingUser != null) {
                    existingUser.linkWithCredential(googleCred).await()
                } else {
                    auth.signInWithCredential(googleCred).await()
                }
                val user = authResult.user
                    ?: return Result.failure(IllegalStateException("Google Sign-In returned no user."))
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("Unsupported credential returned."))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Optional Google link cancelled: ${e.message}")
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.localizedMessage ?: "Google linking failed."))
        }
    }

    suspend fun signOut(context: Context) {
        withContext(NonCancellable) {
            runCatching {
                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
            }
            auth.signOut()
        }
    }

    private fun mapOtpFunctionsError(e: Exception): String {
        if (e is FirebaseNetworkException) {
            return "Network connection unavailable. Check your internet and try again."
        }
        if (e is FirebaseFunctionsException) {
            val serverMessage = e.message?.takeIf { it.isNotBlank() && it != e.code.name }
            return when (e.code) {
                FirebaseFunctionsException.Code.UNAVAILABLE ->
                    "Gmail OTP Cloud Function is unavailable. Deploy /functions via Firebase CLI (see FIREBASE_SETUP.md)."
                FirebaseFunctionsException.Code.FAILED_PRECONDITION ->
                    serverMessage ?: "Gmail SMTP secrets are not configured on Firebase Functions yet."
                FirebaseFunctionsException.Code.INVALID_ARGUMENT,
                FirebaseFunctionsException.Code.ALREADY_EXISTS,
                FirebaseFunctionsException.Code.NOT_FOUND,
                FirebaseFunctionsException.Code.DEADLINE_EXCEEDED,
                FirebaseFunctionsException.Code.RESOURCE_EXHAUSTED,
                FirebaseFunctionsException.Code.PERMISSION_DENIED ->
                    serverMessage ?: "Verification error (${e.code.name})."
                FirebaseFunctionsException.Code.INTERNAL ->
                    serverMessage ?: "Server email delivery failed. Check Cloud Functions logs."
                else -> serverMessage ?: "Authentication error (${e.code.name})."
            }
        }
        return e.localizedMessage ?: "Gmail verification failed."
    }

    private fun mapTwoStepFunctionsError(e: Exception): String {
        if (e is FirebaseFunctionsException) {
            return when (e.code) {
                FirebaseFunctionsException.Code.NOT_FOUND,
                FirebaseFunctionsException.Code.UNAVAILABLE ->
                    "Two-Step Verification Cloud Function is not deployed yet. Deploy /functions via Firebase CLI (see FIREBASE_SETUP.md)."
                else -> e.message ?: "Two-Step Verification server error."
            }
        }
        return e.localizedMessage ?: "Two-Step Verification request failed."
    }
}
