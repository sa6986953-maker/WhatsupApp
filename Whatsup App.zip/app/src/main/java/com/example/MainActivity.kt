package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.BiometricAuthHelper
import com.example.core.LocalAppPreferences
import com.example.core.OfflineMeshEngine
import com.example.core.PreferencesManager
import com.example.core.StorageMediaManager
import com.example.core.VoiceAudioManager
import com.example.core.WhatsupMessagingService
import com.example.core.configureAppCheck
import com.example.core.crypto.WhatsupCryptoManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.CallSignalingRepository
import com.example.data.repository.LocalWhatsupStore
import com.example.data.repository.WhatsupAiRepository
import com.example.data.repository.WhatsupRepository
import com.example.ui.components.WhatsupBrandLogo
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.home.WhatsupMainApp
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.theme.WhatsupTheme
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.AuthStage
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.WhatsupViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private var deepLinkChatIdState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory Firebase App Check wiring before Compose UI or ViewModels
        configureAppCheck(this, intent)
        WhatsupMessagingService.ensureChannels(this)
        deepLinkChatIdState.value = intent?.getStringExtra("conversationId")

        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefsManager = remember { PreferencesManager(context.applicationContext) }
            val localPrefs by prefsManager.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = LocalAppPreferences()
            )
            val deepLinkChatId by deepLinkChatIdState

            WhatsupTheme(themeMode = localPrefs.themeMode) {
                WhatsupRootApp(
                    preferencesManager = prefsManager,
                    localPrefs = localPrefs,
                    initialChatId = deepLinkChatId
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        deepLinkChatIdState.value = intent.getStringExtra("conversationId")
    }
}

@Composable
private fun WhatsupRootApp(
    preferencesManager: PreferencesManager,
    localPrefs: LocalAppPreferences,
    initialChatId: String?
) {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val appCtx = context.applicationContext
    val scope = rememberCoroutineScope()

    val databaseId = remember(appCtx) { appCtx.getString(R.string.firestore_database_id) }
    val db = remember(databaseId) { FirebaseFirestore.getInstance(databaseId) }
    val localStore = remember(appCtx) { LocalWhatsupStore(appCtx) }
    val cryptoManager = remember(appCtx) { WhatsupCryptoManager(appCtx) }
    val storageMediaManager = remember(appCtx) { StorageMediaManager(appCtx) }
    val authRepository = remember { AuthRepository() }

    val whatsupRepository = remember(db, cryptoManager, storageMediaManager, localStore) {
        WhatsupRepository(
            db = db,
            cryptoManager = cryptoManager,
            storageMediaManager = storageMediaManager,
            localOutbox = localStore
        )
    }

    var splashComplete by rememberSaveable { mutableStateOf(false) }
    var unlockedSession by rememberSaveable { mutableStateOf(false) }

    val authViewModel: AuthViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                AuthViewModel(
                    authRepository = authRepository,
                    preferencesManager = preferencesManager,
                    db = db,
                    storageMediaManager = storageMediaManager
                )
            }
        }
    )

    val currentUser by authViewModel.currentUser.collectAsStateWithLifecycle()
    val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(currentUser?.uid, localPrefs.twoStepVerifiedUid) {
        val u = currentUser
        if (u != null) {
            authViewModel.evaluateAuthenticatedSession(u, localPrefs.twoStepVerifiedUid)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(authUiState.stage) {
        if (authUiState.stage == AuthStage.READY && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    if (!splashComplete) {
        SplashScreen(onSplashFinished = { splashComplete = true })
        return
    }

    val signedInUser = currentUser
    if (signedInUser == null || authUiState.stage != AuthStage.READY) {
        AuthScreen(
            authViewModel = authViewModel,
            onRegisterProfile = { name, about, localPhotoPath ->
                val verifiedEmail = signedInUser?.email?.takeIf { it.isNotBlank() }
                    ?: authUiState.normalizedGmail
                val regResult = whatsupRepository.registerOrUpdateUserProfile(
                    displayName = name,
                    email = verifiedEmail,
                    about = about
                )
                if (regResult.isSuccess && localPhotoPath.isNotBlank()) {
                    scope.launch {
                        runCatching {
                            whatsupRepository.uploadUserAvatar(android.net.Uri.fromFile(java.io.File(localPhotoPath)))
                        }
                    }
                }
                regResult
            }
        )
        return
    }

    if (localPrefs.appLockEnabled && !unlockedSession) {
        AppLockGateScreen(
            expectedPin = localPrefs.appLockPin,
            onUnlocked = { unlockedSession = true }
        )
        return
    }

    val uid = signedInUser.uid
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, uid) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> scope.launch {
                    whatsupRepository.syncFcmAndPresence(online = true)
                }
                Lifecycle.Event.ON_STOP -> scope.launch {
                    whatsupRepository.syncFcmAndPresence(online = false)
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val isGoogleLinked = signedInUser.providerData.any { it.providerId == "google.com" }
    val linkedEmail = signedInUser.providerData.firstOrNull { it.providerId == "google.com" }?.email
        ?: signedInUser.email

    key(uid) {
        val whatsupViewModel: WhatsupViewModel = viewModel(
            key = uid,
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY])
                    WhatsupViewModel(
                        appContext = app.applicationContext,
                        repository = whatsupRepository,
                        callRepository = CallSignalingRepository(db = db),
                        authRepository = authRepository,
                        preferencesManager = preferencesManager,
                        offlineMeshEngine = OfflineMeshEngine(app.applicationContext),
                        storageMediaManager = storageMediaManager,
                        voiceAudioManager = VoiceAudioManager(app.applicationContext),
                        currentUserId = uid
                    )
                }
            }
        )
        val aiViewModel: AiAssistantViewModel = viewModel(
            key = "ai_$uid",
            factory = viewModelFactory {
                initializer { AiAssistantViewModel(WhatsupAiRepository()) }
            }
        )

        WhatsupMainApp(
            viewModel = whatsupViewModel,
            aiViewModel = aiViewModel,
            initialChatId = initialChatId,
            isGoogleLinked = isGoogleLinked,
            linkedEmail = linkedEmail,
            isAuthLoading = authUiState.isLoading,
            authErrorMessage = authUiState.errorMessage,
            onConnectGoogleAccount = {
                if (activity != null) {
                    authViewModel.linkGoogleAccountOptional(activity)
                }
            },
            onSignOut = {
                authViewModel.signOut(context)
            }
        )
    }
}

@Composable
private fun AppLockGateScreen(
    expectedPin: String,
    onUnlocked: () -> Unit
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val triggerBiometric = remember(context, onUnlocked) {
        {
            BiometricAuthHelper.authenticate(
                context = context,
                title = "Unlock Whatsup",
                subtitle = "Verify with Fingerprint or Face Lock",
                onSuccess = onUnlocked,
                onError = { msg -> error = msg },
                onUnavailableFallback = {
                    error = "Biometrics unavailable on this device. Enter your App Lock PIN below."
                }
            )
        }
    }

    LaunchedEffect(Unit) {
        if (BiometricAuthHelper.canUseBiometricOrDeviceCredential(context)) {
            triggerBiometric()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        WhatsupBrandLogo(size = 76.dp)
        Spacer(modifier = Modifier.height(16.dp))
        Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Whatsup Locked", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Verify with Fingerprint / Face or enter your App Lock PIN",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = pinInput,
            onValueChange = {
                pinInput = it.filter { c -> c.isDigit() }.take(6)
                error = null
            },
            label = { Text("Enter PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.testTag("app_lock_pin_input")
        )
        if (error != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(modifier = Modifier.height(14.dp))
        Button(
            onClick = {
                if (expectedPin.isNotBlank() && pinInput == expectedPin) {
                    onUnlocked()
                } else {
                    error = "Incorrect PIN"
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
            modifier = Modifier.testTag("app_lock_unlock_button")
        ) {
            Text("Unlock Whatsup", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(
            onClick = { triggerBiometric() },
            modifier = Modifier.testTag("app_lock_biometric_button")
        ) {
            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = WhatsupGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Use Fingerprint / Face")
        }
    }
}
