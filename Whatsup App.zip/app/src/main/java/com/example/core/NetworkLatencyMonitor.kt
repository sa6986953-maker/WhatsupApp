package com.example.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.net.InetSocketAddress
import java.net.Socket

enum class CallSignalQuality(val label: String) {
    GOOD("Good"),
    FAIR("Fair"),
    POOR("Poor")
}

data class LatencyReading(
    val latencyMs: Int?,
    val quality: CallSignalQuality,
    val transportLabel: String
)

object NetworkLatencyMonitor {

    private val probeHosts = listOf(
        "1.1.1.1" to 443,
        "8.8.8.8" to 443
    )

    fun observeLatency(
        context: Context,
        intervalMs: Long = 2500L
    ): Flow<LatencyReading> = flow {
        val appContext = context.applicationContext
        while (currentCoroutineContext().isActive) {
            emit(measureOnce(appContext))
            delay(intervalMs)
        }
    }.flowOn(Dispatchers.IO)

    fun measureOnce(context: Context): LatencyReading {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val network = cm?.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null

        if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            return LatencyReading(
                latencyMs = null,
                quality = CallSignalQuality.POOR,
                transportLabel = "No Network"
            )
        }

        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Network"
        }

        val rttMs = probeTcpLatencyMs()
        val quality = classifyLatency(rttMs)
        return LatencyReading(
            latencyMs = rttMs,
            quality = quality,
            transportLabel = transport
        )
    }

    internal fun classifyLatency(rttMs: Int?): CallSignalQuality {
        return when {
            rttMs == null -> CallSignalQuality.POOR
            rttMs <= 120 -> CallSignalQuality.GOOD
            rttMs <= 300 -> CallSignalQuality.FAIR
            else -> CallSignalQuality.POOR
        }
    }

    private fun probeTcpLatencyMs(): Int? {
        for ((host, port) in probeHosts) {
            val socket = Socket()
            try {
                val startNs = System.nanoTime()
                socket.connect(InetSocketAddress(host, port), 2000)
                val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).toInt()
                return elapsedMs.coerceAtLeast(1)
            } catch (_: Exception) {
                // Try next probe host
            } finally {
                try {
                    socket.close()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }
}
