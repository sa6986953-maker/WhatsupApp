package com.example.core

import android.content.Context
import android.media.AudioManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

private const val TAG = "WebRtcCallManager"

data class WebRtcStatsState(
    val initialized: Boolean = false,
    val iceState: String = "NEW",
    val muted: Boolean = false,
    val speakerOn: Boolean = false,
    val localVideoEnabled: Boolean = false,
    val remoteVideoAvailable: Boolean = false,
    val usingCustomTurn: Boolean = false,
    val error: String? = null
)

/**
 * Real WebRTC peer-to-peer Audio/Video call engine backed by `io.getstream:stream-webrtc-android`.
 * Coordinates local camera/microphone capture, STUN + configurable TURN servers, SDP Offer/Answer,
 * and trickle ICE candidates relayed via Firestore `/calls/{callId}`.
 */
class WebRtcCallManager(
    private val context: Context,
    private val onLocalIceCandidate: (sdpMid: String, sdpMLineIndex: Int, sdp: String) -> Unit,
    private val onRemoteDisconnected: () -> Unit
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _state = MutableStateFlow(WebRtcStatsState())
    val state: StateFlow<WebRtcStatsState> = _state.asStateFlow()

    private var eglBase: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var localAudioTrack: AudioTrack? = null
    private var localVideoTrack: VideoTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var remoteVideoTrack: VideoTrack? = null

    fun ensureInitialized(
        isVideo: Boolean,
        turnUrl: String = "",
        turnUsername: String = "",
        turnCredential: String = ""
    ) {
        if (peerConnection != null) return
        try {
            eglBase = EglBase.create()
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            val eglCtx = eglBase!!.eglBaseContext
            factory = PeerConnectionFactory.builder()
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglCtx))
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglCtx, true, true))
                .createPeerConnectionFactory()

            val iceServers = buildList {
                add(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
                add(PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer())
                if (turnUrl.isNotBlank()) {
                    add(
                        PeerConnection.IceServer.builder(turnUrl.trim())
                            .setUsername(turnUsername.trim())
                            .setPassword(turnCredential)
                            .createIceServer()
                    )
                }
            }

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            }

            peerConnection = factory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
                override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                    val label = newState?.name ?: "UNKNOWN"
                    _state.value = _state.value.copy(iceState = label)
                    if (newState == PeerConnection.IceConnectionState.FAILED ||
                        newState == PeerConnection.IceConnectionState.CLOSED
                    ) {
                        onRemoteDisconnected()
                    }
                }
                override fun onIceConnectionReceivingChange(receiving: Boolean) {}
                override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let {
                        onLocalIceCandidate(it.sdpMid ?: "", it.sdpMLineIndex, it.sdp)
                    }
                }
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
                override fun onAddStream(stream: MediaStream?) {}
                override fun onRemoveStream(stream: MediaStream?) {}
                override fun onDataChannel(dc: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
                override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
                    val track = receiver?.track()
                    if (track is VideoTrack) {
                        remoteVideoTrack = track
                        remoteRenderer?.let { renderer ->
                            runCatching { track.addSink(renderer) }
                        }
                        _state.value = _state.value.copy(remoteVideoAvailable = true)
                    }
                }
            })

            startAudioTrack()
            if (isVideo) {
                startVideoTrack()
            }
            setSpeakerphone(isVideo)
            _state.value = _state.value.copy(
                initialized = true,
                localVideoEnabled = isVideo,
                usingCustomTurn = turnUrl.isNotBlank(),
                error = null
            )
        } catch (e: Exception) {
            Log.e(TAG, "WebRTC initialization failed", e)
            _state.value = _state.value.copy(error = e.localizedMessage ?: "WebRTC unavailable")
        }
    }

    private fun startAudioTrack() {
        val f = factory ?: return
        val audioSource = f.createAudioSource(MediaConstraints())
        val track = f.createAudioTrack("ARDAMSa0", audioSource)
        track.setEnabled(true)
        localAudioTrack = track
        peerConnection?.addTrack(track, listOf("ARDAMS"))
    }

    private fun startVideoTrack() {
        val f = factory ?: return
        val eglCtx = eglBase?.eglBaseContext ?: return
        val enumerator = Camera2Enumerator(context)
        val frontCamera = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
            ?: enumerator.deviceNames.firstOrNull()
            ?: return
        val capturer = enumerator.createCapturer(frontCamera, null) ?: return
        val helper = SurfaceTextureHelper.create("WhatsupCaptureThread", eglCtx)
        val videoSource = f.createVideoSource(capturer.isScreencast)
        capturer.initialize(helper, context, videoSource.capturerObserver)
        capturer.startCapture(640, 480, 24)
        val track = f.createVideoTrack("ARDAMSv0", videoSource)
        track.setEnabled(true)
        videoCapturer = capturer
        surfaceTextureHelper = helper
        localVideoTrack = track
        localRenderer?.let { runCatching { track.addSink(it) } }
        peerConnection?.addTrack(track, listOf("ARDAMS"))
    }

    fun attachRenderers(local: SurfaceViewRenderer?, remote: SurfaceViewRenderer?) {
        val eglCtx = eglBase?.eglBaseContext ?: return
        localRenderer = local?.apply {
            runCatching {
                init(eglCtx, null)
                setMirror(true)
            }
            localVideoTrack?.let { runCatching { it.addSink(this) } }
        }
        remoteRenderer = remote?.apply {
            runCatching {
                init(eglCtx, null)
                setMirror(false)
            }
            remoteVideoTrack?.let { runCatching { it.addSink(this) } }
        }
    }

    fun createOffer(onOfferSdp: (String) -> Unit) {
        val pc = peerConnection ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", _state.value.localVideoEnabled.toString()))
        }
        pc.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc ?: return
                pc.setLocalDescription(NoOpSdpObserver, desc)
                onOfferSdp(desc.description)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String?) {
                _state.value = _state.value.copy(error = error)
            }
            override fun onSetFailure(error: String?) {}
        }, constraints)
    }

    fun acceptRemoteOfferAndCreateAnswer(offerSdp: String, onAnswerSdp: (String) -> Unit) {
        val pc = peerConnection ?: return
        val remoteOffer = SessionDescription(SessionDescription.Type.OFFER, offerSdp)
        pc.setRemoteDescription(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription?) {}
            override fun onSetSuccess() {
                val constraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", _state.value.localVideoEnabled.toString()))
                }
                pc.createAnswer(object : SdpObserver {
                    override fun onCreateSuccess(answerDesc: SessionDescription?) {
                        answerDesc ?: return
                        pc.setLocalDescription(NoOpSdpObserver, answerDesc)
                        onAnswerSdp(answerDesc.description)
                    }
                    override fun onSetSuccess() {}
                    override fun onCreateFailure(error: String?) {
                        _state.value = _state.value.copy(error = error)
                    }
                    override fun onSetFailure(error: String?) {}
                }, constraints)
            }
            override fun onCreateFailure(error: String?) {}
            override fun onSetFailure(error: String?) {
                _state.value = _state.value.copy(error = error)
            }
        }, remoteOffer)
    }

    fun setRemoteAnswer(answerSdp: String) {
        val pc = peerConnection ?: return
        if (pc.remoteDescription != null) return
        val answer = SessionDescription(SessionDescription.Type.ANSWER, answerSdp)
        pc.setRemoteDescription(NoOpSdpObserver, answer)
    }

    fun addRemoteIceCandidate(sdpMid: String, sdpMLineIndex: Int, sdp: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
    }

    fun toggleMute(): Boolean {
        val next = !_state.value.muted
        localAudioTrack?.setEnabled(!next)
        _state.value = _state.value.copy(muted = next)
        return next
    }

    fun setSpeakerphone(enabled: Boolean) {
        runCatching {
            audioManager?.mode = AudioManager.MODE_IN_COMMUNICATION
            @Suppress("DEPRECATION")
            audioManager?.isSpeakerphoneOn = enabled
        }
        _state.value = _state.value.copy(speakerOn = enabled)
    }

    fun toggleSpeakerphone(): Boolean {
        val next = !_state.value.speakerOn
        setSpeakerphone(next)
        return next
    }

    fun switchCamera() {
        videoCapturer?.switchCamera(null)
    }

    fun release() {
        runCatching { videoCapturer?.stopCapture() }
        runCatching { videoCapturer?.dispose() }
        videoCapturer = null
        runCatching { surfaceTextureHelper?.dispose() }
        surfaceTextureHelper = null
        runCatching { localRenderer?.release() }
        runCatching { remoteRenderer?.release() }
        localRenderer = null
        remoteRenderer = null
        runCatching { peerConnection?.close() }
        runCatching { peerConnection?.dispose() }
        peerConnection = null
        runCatching { factory?.dispose() }
        factory = null
        runCatching { eglBase?.release() }
        eglBase = null
        runCatching { audioManager?.mode = AudioManager.MODE_NORMAL }
        _state.value = WebRtcStatsState()
    }

    private object NoOpSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }
}
