package com.example.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.whatsupDataStore: DataStore<Preferences> by preferencesDataStore(name = "whatsup_prefs")

enum class NotificationSoundCategory(
    val title: String,
    val defaultName: String
) {
    STANDARD("Standard Messages", "Default (Whatsup Chime)"),
    URGENT("Urgent Messages", "Default (High Priority Alert)"),
    GROUP_MENTION("Group Mentions", "Default (Group Mention Tone)")
}

data class LocalAppPreferences(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val verifiedEmail: String = "",
    val verifiedPhoneNumber: String = "",
    val localProfilePhotoPath: String = "",
    val appLockPin: String = "",
    val appLockEnabled: Boolean = false,
    val bluetoothPreferred: Boolean = false,
    val twoStepVerifiedUid: String = "",
    val turnServerUrl: String = "",
    val turnUsername: String = "",
    val turnCredential: String = "",
    val standardSoundName: String = NotificationSoundCategory.STANDARD.defaultName,
    val standardSoundUri: String = "",
    val urgentSoundName: String = NotificationSoundCategory.URGENT.defaultName,
    val urgentSoundUri: String = "",
    val mentionSoundName: String = NotificationSoundCategory.GROUP_MENTION.defaultName,
    val mentionSoundUri: String = ""
)

class PreferencesManager(private val context: Context) {
    private object Keys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val VERIFIED_EMAIL = stringPreferencesKey("verified_email")
        val VERIFIED_PHONE = stringPreferencesKey("verified_phone")
        val LOCAL_PROFILE_PHOTO_PATH = stringPreferencesKey("local_profile_photo_path")
        val APP_LOCK_PIN = stringPreferencesKey("app_lock_pin")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
        val BLUETOOTH_PREFERRED = booleanPreferencesKey("bluetooth_preferred")
        val TWO_STEP_VERIFIED_UID = stringPreferencesKey("two_step_verified_uid")
        val TURN_SERVER_URL = stringPreferencesKey("turn_server_url")
        val TURN_USERNAME = stringPreferencesKey("turn_username")
        val TURN_CREDENTIAL = stringPreferencesKey("turn_credential")
        val STANDARD_SOUND_NAME = stringPreferencesKey("standard_sound_name")
        val STANDARD_SOUND_URI = stringPreferencesKey("standard_sound_uri")
        val URGENT_SOUND_NAME = stringPreferencesKey("urgent_sound_name")
        val URGENT_SOUND_URI = stringPreferencesKey("urgent_sound_uri")
        val MENTION_SOUND_NAME = stringPreferencesKey("mention_sound_name")
        val MENTION_SOUND_URI = stringPreferencesKey("mention_sound_uri")
    }

    val preferencesFlow: Flow<LocalAppPreferences> = context.whatsupDataStore.data.map { prefs ->
        val resolvedThemeMode = when {
            prefs[Keys.THEME_MODE] != null -> AppThemeMode.fromStorageKey(prefs[Keys.THEME_MODE])
            prefs[Keys.DARK_MODE] == true -> AppThemeMode.DARK
            else -> AppThemeMode.SYSTEM
        }
        LocalAppPreferences(
            themeMode = resolvedThemeMode,
            verifiedEmail = prefs[Keys.VERIFIED_EMAIL] ?: "",
            verifiedPhoneNumber = prefs[Keys.VERIFIED_PHONE] ?: "",
            localProfilePhotoPath = prefs[Keys.LOCAL_PROFILE_PHOTO_PATH] ?: "",
            appLockPin = prefs[Keys.APP_LOCK_PIN] ?: "",
            appLockEnabled = prefs[Keys.APP_LOCK_ENABLED] ?: false,
            bluetoothPreferred = prefs[Keys.BLUETOOTH_PREFERRED] ?: false,
            twoStepVerifiedUid = prefs[Keys.TWO_STEP_VERIFIED_UID] ?: "",
            turnServerUrl = prefs[Keys.TURN_SERVER_URL] ?: "",
            turnUsername = prefs[Keys.TURN_USERNAME] ?: "",
            turnCredential = prefs[Keys.TURN_CREDENTIAL] ?: "",
            standardSoundName = prefs[Keys.STANDARD_SOUND_NAME]
                ?: NotificationSoundCategory.STANDARD.defaultName,
            standardSoundUri = prefs[Keys.STANDARD_SOUND_URI] ?: "",
            urgentSoundName = prefs[Keys.URGENT_SOUND_NAME]
                ?: NotificationSoundCategory.URGENT.defaultName,
            urgentSoundUri = prefs[Keys.URGENT_SOUND_URI] ?: "",
            mentionSoundName = prefs[Keys.MENTION_SOUND_NAME]
                ?: NotificationSoundCategory.GROUP_MENTION.defaultName,
            mentionSoundUri = prefs[Keys.MENTION_SOUND_URI] ?: ""
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.whatsupDataStore.edit {
            it[Keys.THEME_MODE] = mode.storageKey
            it[Keys.DARK_MODE] = mode == AppThemeMode.DARK
        }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        setThemeMode(if (enabled) AppThemeMode.DARK else AppThemeMode.LIGHT)
    }

    suspend fun setVerifiedEmail(email: String) {
        context.whatsupDataStore.edit { it[Keys.VERIFIED_EMAIL] = email }
    }

    suspend fun setVerifiedPhoneNumber(phone: String) {
        context.whatsupDataStore.edit { it[Keys.VERIFIED_PHONE] = phone }
    }

    suspend fun setLocalProfilePhotoPath(path: String) {
        context.whatsupDataStore.edit { it[Keys.LOCAL_PROFILE_PHOTO_PATH] = path }
    }

    suspend fun setTwoStepVerifiedUid(uid: String) {
        context.whatsupDataStore.edit { it[Keys.TWO_STEP_VERIFIED_UID] = uid }
    }

    suspend fun setTurnConfig(url: String, username: String, credential: String) {
        context.whatsupDataStore.edit {
            it[Keys.TURN_SERVER_URL] = url.trim()
            it[Keys.TURN_USERNAME] = username.trim()
            it[Keys.TURN_CREDENTIAL] = credential
        }
    }

    suspend fun setAppLock(enabled: Boolean, pin: String = "") {
        context.whatsupDataStore.edit {
            it[Keys.APP_LOCK_ENABLED] = enabled
            if (pin.isNotBlank()) it[Keys.APP_LOCK_PIN] = pin
        }
    }

    suspend fun setBluetoothPreferred(enabled: Boolean) {
        context.whatsupDataStore.edit { it[Keys.BLUETOOTH_PREFERRED] = enabled }
    }

    suspend fun setNotificationSound(
        category: NotificationSoundCategory,
        uri: String,
        displayName: String
    ) {
        context.whatsupDataStore.edit { prefs ->
            when (category) {
                NotificationSoundCategory.STANDARD -> {
                    prefs[Keys.STANDARD_SOUND_URI] = uri
                    prefs[Keys.STANDARD_SOUND_NAME] = displayName
                }
                NotificationSoundCategory.URGENT -> {
                    prefs[Keys.URGENT_SOUND_URI] = uri
                    prefs[Keys.URGENT_SOUND_NAME] = displayName
                }
                NotificationSoundCategory.GROUP_MENTION -> {
                    prefs[Keys.MENTION_SOUND_URI] = uri
                    prefs[Keys.MENTION_SOUND_NAME] = displayName
                }
            }
        }
    }

    suspend fun clearSessionPrefs() {
        context.whatsupDataStore.edit {
            it.remove(Keys.VERIFIED_EMAIL)
            it.remove(Keys.VERIFIED_PHONE)
            it.remove(Keys.LOCAL_PROFILE_PHOTO_PATH)
            it.remove(Keys.TWO_STEP_VERIFIED_UID)
        }
    }
}
