package com.example.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private const val TAG = "WhatsupMessagingSvc"

class WhatsupMessagingService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_MESSAGES = "whatsup_messages"
        const val CHANNEL_CALLS = "whatsup_calls"

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val msgChannel = NotificationChannel(
                CHANNEL_MESSAGES,
                "Whatsup Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Encrypted chat messages and group alerts"
            }
            val callChannel = NotificationChannel(
                CHANNEL_CALLS,
                "Whatsup Voice & Video Calls",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming real-time WebRTC calls"
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .build()
                )
            }
            nm.createNotificationChannel(msgChannel)
            nm.createNotificationChannel(callChannel)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureChannels(this)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dbId = getString(R.string.firestore_database_id)
                FirebaseFirestore.getInstance(dbId)
                    .collection("users")
                    .document(uid)
                    .update(
                        mapOf(
                            "fcmToken" to token,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
            } catch (e: Exception) {
                Log.w(TAG, "Failed to update FCM token", e)
            }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        ensureChannels(this)

        val data = message.data
        val type = data["type"] ?: "MESSAGE"
        val title = message.notification?.title ?: data["title"] ?: "Whatsup"
        val body = message.notification?.body ?: data["body"] ?: "New encrypted activity"
        val conversationId = data["conversationId"]
        val callId = data["callId"]

        CoroutineScope(Dispatchers.IO).launch {
            val prefs = runCatching { PreferencesManager(applicationContext).preferencesFlow.first() }.getOrNull()
            val soundUriStr = when (type) {
                "URGENT" -> prefs?.urgentSoundUri.orEmpty()
                "MENTION" -> prefs?.mentionSoundUri.orEmpty()
                else -> prefs?.standardSoundUri.orEmpty()
            }
            val soundUri = if (soundUriStr.isNotBlank()) {
                Uri.parse(soundUriStr)
            } else if (type == "CALL") {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }

            val launchIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (!conversationId.isNullOrBlank()) putExtra("conversationId", conversationId)
                if (!callId.isNullOrBlank()) putExtra("callId", callId)
            }
            val pi = PendingIntent.getActivity(
                applicationContext,
                (conversationId ?: callId ?: "whatsup").hashCode(),
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val channelId = if (type == "CALL") CHANNEL_CALLS else CHANNEL_MESSAGES
            val builder = NotificationCompat.Builder(applicationContext, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .setSound(soundUri)

            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
        }
    }
}
