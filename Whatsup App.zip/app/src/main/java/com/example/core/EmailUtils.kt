package com.example.core

import java.security.MessageDigest
import java.util.Locale

/**
 * Gmail address normalization, validation, SHA-256 directory hashing, and 6-digit OTP checks.
 */
object EmailUtils {
    private val GMAIL_REGEX = Regex("^[a-z0-9._%+\\-]{1,64}@(gmail\\.com|googlemail\\.com)$")

    /**
     * Trims, lowercases, and validates that an input is a valid Gmail address
     * (@gmail.com or @googlemail.com). Returns null if invalid.
     */
    fun normalizeGmail(rawInput: String): String? {
        val trimmed = rawInput.trim().lowercase(Locale.US)
        if (trimmed.isEmpty() || trimmed.length > 254) return null
        if (!GMAIL_REGEX.matches(trimmed)) return null

        val localPart = trimmed.substringBefore('@')
        if (localPart.isEmpty() ||
            localPart.startsWith('.') ||
            localPart.endsWith('.') ||
            localPart.contains("..")
        ) {
            return null
        }
        return trimmed
    }

    fun isValidGmail(rawInput: String): Boolean = normalizeGmail(rawInput) != null

    fun hashEmail(normalizedEmail: String): String {
        val canonical = normalizedEmail.trim().lowercase(Locale.US)
        val digest = MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun maskEmail(email: String): String {
        val clean = email.trim()
        val atIdx = clean.indexOf('@')
        if (atIdx <= 1) return clean
        val local = clean.substring(0, atIdx)
        val domain = clean.substring(atIdx)
        val visible = local.take(2)
        return "$visible***$domain"
    }

    fun isValidOtpCode(otpCode: String): Boolean {
        val trimmed = otpCode.trim()
        return trimmed.length == 6 && trimmed.all { it.isDigit() }
    }

    fun formatCountdown(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        val mins = safe / 60
        val secs = safe % 60
        return "%d:%02d".format(Locale.US, mins, secs)
    }
}
