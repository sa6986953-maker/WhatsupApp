package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ChatHistoryExporter
import com.example.core.CountryDialCode
import com.example.core.ExportFormat
import com.example.core.ExportedChatFile
import com.example.core.LocalAppPreferences
import com.example.core.MeshStatus
import com.example.core.NotificationSoundCategory
import com.example.core.OfflineMeshEngine
import com.example.core.PhoneNumberUtils
import com.example.core.PreferencesManager
import com.example.core.StorageMediaManager
import com.example.core.VoiceAudioManager
import com.example.core.VoicePlaybackState
import com.example.core.VoiceRecordingState
import com.example.core.WebRtcCallManager
import com.example.core.WebRtcStatsState
import com.example.data.model.BlockedUser
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.StatusUpdate
import com.example.data.model.StatusViewer
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedContact
import com.example.data.repository.AuthRepository
import com.example.data.repository.CallSignalingRepository
import com.example.data.repository.WhatsupRepository
import com.example.ui.theme.AppThemeMode
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

private const val TAG = "WhatsupViewModel"

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data object Exporting : ExportUiState
    data class Success(val file: ExportedChatFile) : ExportUiState
    data class Error(val message: String) : ExportUiState
}

sealed interface ContactLookupUiState {
    data object Idle : ContactLookupUiState
    data object Searching : ContactLookupUiState
    data class Found(val contact: VerifiedContact) : ContactLookupUiState
    data class NotFound(val message: String) : ContactLookupUiState
}

class WhatsupViewModel(
    private val appContext: Context,
    private val repository: WhatsupRepository,
    private val callRepository: CallSignalingRepository,
    private val authRepository: AuthRepository,
    private val preferencesManager: PreferencesManager,
    private val offlineMeshEngine: OfflineMeshEngine,
    private val storageMediaManager: StorageMediaManager,
    val voiceAudioManager: VoiceAudioManager,
    val currentUserId: String
) : ViewModel() {

    val localPrefs: StateFlow<LocalAppPreferences> = preferencesManager.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), LocalAppPreferences())

    val meshStatus: StateFlow<MeshStatus> = combine(
        offlineMeshEngine.status,
        repository.observePendingOutboxCount(currentUserId)
    ) { mesh, pending ->
        mesh.copy(pendingSyncCount = pending)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), MeshStatus())

    val recordingState: StateFlow<VoiceRecordingState> = voiceAudioManager.recordingState
    val voicePlaybackState: StateFlow<VoicePlaybackState> = voiceAudioManager.playbackState

    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId: StateFlow<String?> = _selectedChatId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _lookupState = MutableStateFlow<ContactLookupUiState>(ContactLookupUiState.Idle)
    val lookupState: StateFlow<ContactLookupUiState> = _lookupState.asStateFlow()

    private val _exportState = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val exportState: StateFlow<ExportUiState> = _exportState.asStateFlow()

    private val _exportedFiles = MutableStateFlow<List<ExportedChatFile>>(emptyList())
    val exportedFiles: StateFlow<List<ExportedChatFile>> = _exportedFiles.asStateFlow()

    private val _mediaCacheBytes = MutableStateFlow(0L)
    val mediaCacheBytes: StateFlow<Long> = _mediaCacheBytes.asStateFlow()

    val userProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load profile")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val verifiedContactsState: StateFlow<List<VerifiedContact>> = repository.observeVerifiedContacts(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val blockedUsersState: StateFlow<List<BlockedUser>> = repository.observeBlockedUsers(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val chatsState: StateFlow<UiState<List<ChatThread>>> = repository.observeChats(currentUserId)
        .map<List<ChatThread>, UiState<List<ChatThread>>> { chats ->
            val sorted = chats.sortedWith(
                compareByDescending<ChatThread> { it.pinned }.thenByDescending { it.sortOrder }
            )
            UiState.Success(sorted)
        }
        .catch { error -> emit(mapFirestoreError(error, "Failed to observe conversations")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeMessagesState: StateFlow<UiState<List<ChatMessage>>> = combine(
        _selectedChatId,
        chatsState
    ) { chatId, chats ->
        val list = (chats as? UiState.Success)?.data.orEmpty()
        list.firstOrNull { it.id == chatId }
    }.flatMapLatest { thread ->
        if (thread == null) {
            flowOf(UiState.Success(emptyList()))
        } else {
            repository.observeMessages(currentUserId, thread)
                .map<List<ChatMessage>, UiState<List<ChatMessage>>> { msgs ->
                    val hideTicks = (userProfile.value as? UiState.Success)?.data?.hideBlueTicks == true
                    viewModelScope.launch {
                        repository.markMessagesDeliveredAndRead(thread, msgs, isViewingThread = true, hideBlueTicks = hideTicks)
                    }
                    UiState.Success(msgs)
                }
                .catch { error -> emit(mapFirestoreError(error, "Failed to load messages")) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val statusesState: StateFlow<UiState<List<StatusUpdate>>> = repository.observeStatuses(currentUserId)
        .map<List<StatusUpdate>, UiState<List<StatusUpdate>>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load statuses")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val callsState: StateFlow<UiState<List<CallRecord>>> = callRepository.observeCallHistory(currentUserId)
        .map<List<CallRecord>, UiState<List<CallRecord>>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load calls")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val incomingRingingCalls: StateFlow<List<CallRecord>> = callRepository.observeIncomingRingingCalls(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // --- Active WebRTC Call State ---
    private val _activeCallId = MutableStateFlow<String?>(null)
    val activeCallId: StateFlow<String?> = _activeCallId.asStateFlow()

    private val _activeCallSeconds = MutableStateFlow(0L)
    val activeCallSeconds: StateFlow<Long> = _activeCallSeconds.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeCallRecord: StateFlow<CallRecord?> = _activeCallId.flatMapLatest { cid ->
        if (cid.isNullOrBlank()) flowOf(null)
        else callRepository.observeCallSession(cid, currentUserId).catch { emit(null) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val webrtcManager: WebRtcCallManager = WebRtcCallManager(
        context = appContext,
        onLocalIceCandidate = { mid, index, sdp ->
            val cid = _activeCallId.value ?: return@WebRtcCallManager
            val call = activeCallRecord.value
            val isCaller = call?.callerUid == currentUserId
            viewModelScope.launch {
                callRepository.addIceCandidate(cid, isCaller, mid, index, sdp)
            }
        },
        onRemoteDisconnected = {
            viewModelScope.launch { endActiveCall() }
        }
    )

    val webrtcState: StateFlow<WebRtcStatsState> = webrtcManager.state

    private var callTimerJob: Job? = null
    private var iceObserverJob: Job? = null
    private var callSessionWatchJob: Job? = null
    private var typingClearJob: Job? = null

    init {
        refreshMediaCacheSize()
        viewModelScope.launch {
            repository.syncFcmAndPresence(online = true)
        }
        // Automatically sync queued Bluetooth offline outbox whenever connectivity returns
        viewModelScope.launch {
            meshStatus.collect { mesh ->
                if (mesh.networkOnline && !mesh.offlineModeActive && mesh.pendingSyncCount > 0) {
                    val profile = (userProfile.value as? UiState.Success)?.data
                    val threads = (chatsState.value as? UiState.Success)?.data.orEmpty()
                    if (threads.isNotEmpty()) {
                        repository.syncPendingBluetoothOutbox(
                            threads = threads,
                            senderName = profile?.displayName ?: "Whatsup User",
                            senderPhone = profile?.phoneE164.orEmpty()
                        ).onSuccess { count ->
                            if (count > 0) {
                                _actionMessage.value = "Auto-synced $count offline Bluetooth message(s) to Cloud!"
                            }
                        }
                    }
                }
            }
        }
    }

    private fun <T> mapFirestoreError(error: Throwable, fallback: String): UiState<T> {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val root = firestoreError ?: error
        Log.w(TAG, fallback, root)
        return UiState.Error(root.message ?: fallback)
    }

    fun selectChat(chatId: String?) {
        _selectedChatId.value = chatId
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    fun resetContactLookup() {
        _lookupState.value = ContactLookupUiState.Idle
    }

    fun lookupContact(
        rawInput: String,
        country: CountryDialCode = PhoneNumberUtils.defaultCountry
    ) {
        _lookupState.value = ContactLookupUiState.Searching
        viewModelScope.launch {
            repository.lookupRegisteredUser(rawInput, country.isoCode, country.dialCode).fold(
                onSuccess = { contact ->
                    _lookupState.value = ContactLookupUiState.Found(contact)
                },
                onFailure = { error ->
                    _lookupState.value = ContactLookupUiState.NotFound(
                        error.localizedMessage ?: "User is not registered on Whatsup."
                    )
                }
            )
        }
    }

    fun openDirectChatWithContact(contact: VerifiedContact) {
        val myName = (userProfile.value as? UiState.Success)?.data?.displayName ?: "Whatsup User"
        viewModelScope.launch {
            repository.openOrCreateDirectConversation(contact, myName)
                .onSuccess { convId ->
                    _selectedChatId.value = convId
                    _lookupState.value = ContactLookupUiState.Idle
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Unable to start chat."
                }
        }
    }

    fun notifyTyping(conversationId: String, isCurrentlyNonEmpty: Boolean) {
        typingClearJob?.cancel()
        viewModelScope.launch {
            repository.setTypingStatus(conversationId, isCurrentlyNonEmpty)
        }
        if (isCurrentlyNonEmpty) {
            typingClearJob = viewModelScope.launch {
                delay(3500L)
                repository.setTypingStatus(conversationId, false)
            }
        }
    }

    fun sendMessage(
        thread: ChatThread,
        text: String,
        messageType: String = "TEXT",
        replyToText: String? = null,
        replyToSender: String? = null,
        mediaMeta: String? = null,
        scheduledMinutesDelay: Int? = null
    ) {
        val profile = (userProfile.value as? UiState.Success)?.data
        val viaBt = meshStatus.value.offlineModeActive
        val scheduledFor = scheduledMinutesDelay?.let { System.currentTimeMillis() + it * 60_000L }
        viewModelScope.launch {
            repository.setTypingStatus(thread.id, false)
            repository.sendMessage(
                thread = thread,
                senderName = profile?.displayName ?: "Whatsup User",
                senderPhone = profile?.phoneE164.orEmpty(),
                text = text,
                messageType = messageType,
                viaBluetooth = viaBt,
                replyToText = replyToText,
                replyToSender = replyToSender,
                mediaMeta = mediaMeta,
                scheduledForMillis = scheduledFor
            ).onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to send message"
            }.onSuccess {
                if (viaBt) _actionMessage.value = "Queued via 100m Bluetooth Mesh (will sync online)"
            }
        }
    }

    fun sendUriAttachment(
        thread: ChatThread,
        uri: Uri,
        messageType: String,
        caption: String = "",
        viewOnce: Boolean = false
    ) {
        val profile = (userProfile.value as? UiState.Success)?.data
        viewModelScope.launch {
            _actionMessage.value = "Encrypting & uploading media..."
            repository.uploadEncryptedUriAttachment(
                thread = thread,
                senderName = profile?.displayName ?: "Whatsup User",
                senderPhone = profile?.phoneE164.orEmpty(),
                uri = uri,
                messageType = messageType,
                caption = caption,
                viewOnce = viewOnce
            ).onSuccess {
                _actionMessage.value = "Encrypted media sent"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Media upload failed"
            }
        }
    }

    fun stopAndSendVoiceRecording(thread: ChatThread, discard: Boolean = false) {
        val (file, durationSec) = voiceAudioManager.stopRecording(discard)
        if (discard || file == null) return
        val profile = (userProfile.value as? UiState.Success)?.data
        viewModelScope.launch {
            repository.uploadEncryptedVoiceAttachment(
                thread = thread,
                senderName = profile?.displayName ?: "Whatsup User",
                senderPhone = profile?.phoneE164.orEmpty(),
                audioFile = file,
                durationSeconds = durationSec
            ).onSuccess {
                _actionMessage.value = "Voice note sent"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Voice upload failed"
            }
        }
    }

    fun playVoiceMessage(message: ChatMessage) {
        if (message.mediaStoragePath.isNullOrBlank()) {
            _actionMessage.value = "No voice audio file attached to this message."
            return
        }
        viewModelScope.launch {
            repository.downloadDecryptedMedia(message).onSuccess { localFile ->
                voiceAudioManager.playOrToggle(message.id, localFile) { err ->
                    _actionMessage.value = err
                }
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Unable to decrypt voice note"
            }
        }
    }

    suspend fun downloadMediaFile(message: ChatMessage): Result<File> =
        repository.downloadDecryptedMedia(message)

    fun syncPendingBluetooth(thread: ChatThread) {
        val profile = (userProfile.value as? UiState.Success)?.data
        viewModelScope.launch {
            repository.syncPendingBluetoothOutbox(
                threads = listOf(thread),
                senderName = profile?.displayName ?: "Whatsup User",
                senderPhone = profile?.phoneE164.orEmpty()
            ).onSuccess { count ->
                _actionMessage.value = if (count > 0) "Synced $count offline message(s)!" else "Nothing pending for sync."
            }
        }
    }

    fun editMessage(thread: ChatThread, message: ChatMessage, newText: String) {
        viewModelScope.launch {
            repository.editMessage(thread, message, newText)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to edit message" }
        }
    }

    fun togglePinChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updatePerUserConversationPref(chat.id, "pinnedBy", !chat.pinned)
        }
    }

    fun toggleArchiveChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updatePerUserConversationPref(chat.id, "archivedBy", !chat.archived)
            _actionMessage.value = if (!chat.archived) "Chat archived" else "Chat unarchived"
        }
    }

    fun toggleMuteChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updatePerUserConversationPref(chat.id, "mutedBy", !chat.muted)
        }
    }

    fun toggleLockChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updatePerUserConversationPref(chat.id, "lockedBy", !chat.locked)
            _actionMessage.value = if (!chat.locked) "Chat locked behind Biometric Auth" else "Chat unlocked"
        }
    }

    fun toggleAdminOnlySend(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateGroupManagement(chat.id, onlyAdminCanSend = !chat.onlyAdminCanSend)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Admin permission required" }
        }
    }

    fun setDisappearingMode(chatId: String, mode: String) {
        viewModelScope.launch {
            repository.setDisappearingMode(chatId, mode)
            _actionMessage.value = "Disappearing messages set to $mode"
        }
    }

    fun setWallpaperStyle(chatId: String, style: String) {
        viewModelScope.launch {
            repository.updatePerUserConversationPref(chatId, "wallpaperBy", style)
            _actionMessage.value = "Chat wallpaper updated"
        }
    }

    fun toggleStarMessage(chatId: String, message: ChatMessage) {
        viewModelScope.launch {
            repository.updateMessageFlag(chatId, message.id, "starredBy", !message.starred)
        }
    }

    fun toggleMessageReaction(chatId: String, message: ChatMessage, emoji: String) {
        viewModelScope.launch {
            repository.toggleMessageReaction(chatId, message, emoji)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to react" }
        }
    }

    fun deleteMessageForMe(chatId: String, messageId: String) {
        viewModelScope.launch {
            repository.updateMessageFlag(chatId, messageId, "deletedFor", true)
        }
    }

    fun deleteMessageForEveryone(chatId: String, messageId: String) {
        viewModelScope.launch {
            repository.deleteMessageForEveryone(chatId, messageId)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Delete failed" }
        }
    }

    fun openViewOnceMessage(chatId: String, messageId: String) {
        viewModelScope.launch {
            delay(250)
            repository.updateMessageFlag(chatId, messageId, "viewOnceOpenedBy", true)
        }
    }

    fun createGroup(
        title: String,
        description: String,
        chatType: String,
        members: List<VerifiedContact>,
        onlyAdminCanSend: Boolean,
        bluetoothChat: Boolean,
        communityName: String? = null
    ) {
        viewModelScope.launch {
            repository.createGroupConversation(
                title = title,
                description = description,
                chatType = chatType,
                members = members,
                onlyAdminCanSend = onlyAdminCanSend,
                bluetoothChat = bluetoothChat,
                communityName = communityName
            ).onSuccess { newId ->
                _selectedChatId.value = newId
                _actionMessage.value = "Created $title"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to create group"
            }
        }
    }

    fun joinGroupViaInvite(code: String) {
        viewModelScope.launch {
            repository.joinGroupByInviteCode(code)
                .onSuccess { convId ->
                    _selectedChatId.value = convId
                    _actionMessage.value = "Joined group via invite link!"
                }
                .onFailure { err ->
                    _actionMessage.value = err.localizedMessage ?: "Unable to join group"
                }
        }
    }

    fun updateGroupDetails(groupId: String, title: String, description: String) {
        viewModelScope.launch {
            repository.updateGroupManagement(groupId, title = title, description = description)
                .onSuccess { _actionMessage.value = "Group info updated" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Only admins can update group info" }
        }
    }

    fun toggleGroupAdmin(group: ChatThread, targetUid: String) {
        val nextAdmins = if (targetUid in group.adminUids) {
            (group.adminUids - targetUid).ifEmpty { group.adminUids }
        } else {
            group.adminUids + targetUid
        }
        viewModelScope.launch {
            repository.updateGroupManagement(group.id, adminUids = nextAdmins)
        }
    }

    fun addMemberToGroup(group: ChatThread, contact: VerifiedContact) {
        val nextMembers = (group.participantUids + contact.contactUid).distinct()
        viewModelScope.launch {
            repository.updateGroupManagement(group.id, participantUids = nextMembers)
                .onSuccess { _actionMessage.value = "Added ${contact.savedName}" }
        }
    }

    fun removeMemberFromGroup(group: ChatThread, targetUid: String) {
        val nextMembers = group.participantUids - targetUid
        val nextAdmins = group.adminUids - targetUid
        viewModelScope.launch {
            repository.updateGroupManagement(group.id, participantUids = nextMembers, adminUids = nextAdmins)
        }
    }

    suspend fun fetchGroupParticipants(uids: List<String>): Map<String, UserProfile> =
        repository.fetchPeerProfiles(uids)

    fun postStatus(
        caption: String,
        statusType: String,
        bgColorHex: Long,
        mediaUri: Uri?,
        privacyMode: String,
        selectedTargetUids: List<String>
    ) {
        val profile = (userProfile.value as? UiState.Success)?.data
        val allContactUids = verifiedContactsState.value.map { it.contactUid }
        viewModelScope.launch {
            repository.postStatus(
                authorName = profile?.displayName ?: "Whatsup User",
                ownerPhoneE164 = profile?.phoneE164.orEmpty(),
                caption = caption,
                statusType = statusType,
                bgColorHex = bgColorHex,
                mediaUri = mediaUri,
                privacyMode = privacyMode,
                selectedTargetUids = selectedTargetUids,
                allContactUids = allContactUids
            ).onSuccess {
                _actionMessage.value = "Status shared for 24 hours!"
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to post status"
            }
        }
    }

    fun markStatusViewed(status: StatusUpdate) {
        if (status.userId == currentUserId) return
        val viewerName = (userProfile.value as? UiState.Success)?.data?.displayName ?: "Whatsup User"
        viewModelScope.launch {
            repository.markStatusViewed(status.id, viewerName, status.viewedByCount)
        }
    }

    fun observeStatusViewers(statusId: String) = repository.observeStatusViewers(statusId)

    fun deleteStatus(statusId: String) {
        viewModelScope.launch {
            repository.deleteStatus(statusId)
                .onSuccess { _actionMessage.value = "Status deleted" }
        }
    }

    fun replyToStatus(status: StatusUpdate, replyText: String) {
        val clean = replyText.trim()
        if (clean.isEmpty()) return
        val contact = verifiedContactsState.value.firstOrNull { it.contactUid == status.userId }
            ?: VerifiedContact(
                contactUid = status.userId,
                savedName = status.authorName,
                phoneE164 = status.ownerPhoneE164
            )
        val profile = (userProfile.value as? UiState.Success)?.data
        viewModelScope.launch {
            repository.openOrCreateDirectConversation(contact, profile?.displayName ?: "Whatsup User")
                .onSuccess { convId ->
                    val threads = (chatsState.value as? UiState.Success)?.data.orEmpty()
                    val thread = threads.firstOrNull { it.id == convId } ?: ChatThread(
                        id = convId,
                        chatType = "DIRECT",
                        peerUid = contact.contactUid,
                        peerIdentityPublicKey = contact.identityPublicKey,
                        participantUids = listOf(currentUserId, contact.contactUid).sorted()
                    )
                    repository.sendMessage(
                        thread = thread,
                        senderName = profile?.displayName ?: "Whatsup User",
                        senderPhone = profile?.phoneE164.orEmpty(),
                        text = clean,
                        replyToSender = status.authorName,
                        replyToText = "Status: ${status.caption.take(80)}"
                    )
                    _actionMessage.value = "Replied to ${status.authorName}'s status"
                }
        }
    }

    // --- Real WebRTC Voice & Video Calls ---
    fun startCallWithContact(contact: VerifiedContact, isVideo: Boolean, recorded: Boolean = false) {
        val profile = (userProfile.value as? UiState.Success)?.data
        val prefs = localPrefs.value
        val callType = if (isVideo) "VIDEO" else "VOICE"

        webrtcManager.ensureInitialized(
            isVideo = isVideo,
            turnUrl = prefs.turnServerUrl,
            turnUsername = prefs.turnUsername,
            turnCredential = prefs.turnCredential
        )
        viewModelScope.launch {
            val callId = callRepository.createOutgoingCall(
                callerName = profile?.displayName ?: "Whatsup User",
                calleeUid = contact.contactUid,
                calleeName = contact.savedName,
                callType = callType,
                recorded = recorded
            ).getOrElse { err ->
                webrtcManager.release()
                _actionMessage.value = err.localizedMessage ?: "Unable to start call"
                return@launch
            }
            _activeCallId.value = callId
            webrtcManager.createOffer { offerSdp ->
                viewModelScope.launch {
                    callRepository.updateOfferSdp(callId, offerSdp)
                }
            }
            watchCallSignaling(callId, isCaller = true)
        }
    }

    fun acceptIncomingCall(call: CallRecord) {
        val prefs = localPrefs.value
        val isVideo = call.callType.contains("VIDEO")
        _activeCallId.value = call.id
        webrtcManager.ensureInitialized(
            isVideo = isVideo,
            turnUrl = prefs.turnServerUrl,
            turnUsername = prefs.turnUsername,
            turnCredential = prefs.turnCredential
        )
        val offer = call.offerSdp
        if (!offer.isNullOrBlank()) {
            webrtcManager.acceptRemoteOfferAndCreateAnswer(offer) { answerSdp ->
                viewModelScope.launch {
                    callRepository.acceptCallWithAnswer(call.id, answerSdp)
                }
            }
        }
        startCallDurationTimer()
        watchCallSignaling(call.id, isCaller = false)
    }

    fun rejectIncomingCall(call: CallRecord) {
        viewModelScope.launch {
            callRepository.updateCallStatus(call.id, "REJECTED", 0L, false)
        }
    }

    fun createJoinableCallLink(callType: String) {
        val profile = (userProfile.value as? UiState.Success)?.data
        val code = "whatsup.call/${UUID.randomUUID().toString().take(8).uppercase()}"
        viewModelScope.launch {
            callRepository.createOutgoingCall(
                callerName = profile?.displayName ?: "Whatsup User",
                calleeUid = currentUserId,
                calleeName = "Call Link",
                callType = callType,
                participantUids = listOf(currentUserId),
                callLinkCode = code
            ).onSuccess {
                _actionMessage.value = "Call Link created: $code"
            }
        }
    }

    private fun watchCallSignaling(callId: String, isCaller: Boolean) {
        iceObserverJob?.cancel()
        iceObserverJob = viewModelScope.launch {
            callRepository.observeRemoteIceCandidates(callId, listenForCallerCandidates = !isCaller)
                .collect { cand ->
                    webrtcManager.addRemoteIceCandidate(cand.sdpMid, cand.sdpMLineIndex, cand.sdp)
                }
        }
        callSessionWatchJob?.cancel()
        callSessionWatchJob = viewModelScope.launch {
            callRepository.observeCallSession(callId, currentUserId).collect { call ->
                if (call == null) return@collect
                if (isCaller && call.status == "ACCEPTED" && !call.answerSdp.isNullOrBlank()) {
                    webrtcManager.setRemoteAnswer(call.answerSdp)
                    if (callTimerJob == null) startCallDurationTimer()
                }
                if (call.status == "REJECTED" || call.status == "ENDED" || call.status == "MISSED") {
                    cleanupLocalCallResources()
                }
            }
        }
    }

    private fun startCallDurationTimer() {
        callTimerJob?.cancel()
        _activeCallSeconds.value = 0L
        callTimerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                _activeCallSeconds.value += 1L
            }
        }
    }

    fun endActiveCall() {
        val cid = _activeCallId.value
        val dur = _activeCallSeconds.value
        val wasAccepted = activeCallRecord.value?.status == "ACCEPTED"
        cleanupLocalCallResources()
        if (!cid.isNullOrBlank()) {
            viewModelScope.launch {
                val finalStatus = if (wasAccepted) "ENDED" else "MISSED"
                callRepository.updateCallStatus(cid, finalStatus, dur, false)
            }
        }
    }

    private fun cleanupLocalCallResources() {
        callTimerJob?.cancel()
        callTimerJob = null
        iceObserverJob?.cancel()
        iceObserverJob = null
        callSessionWatchJob?.cancel()
        callSessionWatchJob = null
        _activeCallId.value = null
        _activeCallSeconds.value = 0L
        webrtcManager.release()
    }

    // --- Settings, Privacy, Block, Two-Step, TURN, Cache, Export ---
    fun blockUser(targetUid: String, phoneE164: String, displayName: String) {
        viewModelScope.launch {
            repository.blockUser(targetUid, phoneE164, displayName)
                .onSuccess { _actionMessage.value = "Blocked $displayName" }
        }
    }

    fun unblockUser(targetUid: String) {
        viewModelScope.launch {
            repository.unblockUser(targetUid)
                .onSuccess { _actionMessage.value = "Unblocked user" }
        }
    }

    fun uploadMyAvatar(uri: Uri) {
        viewModelScope.launch {
            val localResult = storageMediaManager.saveProfilePhotoLocally(currentUserId, uri)
            localResult.onSuccess { localPath ->
                preferencesManager.setLocalProfilePhotoPath(localPath)
                _actionMessage.value = "Profile photo saved locally"
                // Best-effort cloud avatar sync when Firebase Storage is reachable
                repository.uploadUserAvatar(android.net.Uri.fromFile(java.io.File(localPath)))
            }.onFailure { err ->
                _actionMessage.value = err.localizedMessage ?: "Failed to save profile photo"
            }
        }
    }

    fun updatePrivacyAndSettings(updates: Map<String, Any>) {
        viewModelScope.launch {
            repository.updateUserProfileSettings(updates)
                .onSuccess { _actionMessage.value = "Saved to Whatsup Cloud" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to save" }
        }
    }

    fun updateOptionalPhoneNumber(newPhoneE164: String) {
        val currentPhone = (userProfile.value as? UiState.Success)?.data?.phoneE164.orEmpty()
        viewModelScope.launch {
            repository.updateOptionalPhoneNumber(currentPhone, newPhoneE164)
                .onSuccess {
                    preferencesManager.setVerifiedPhoneNumber(newPhoneE164)
                    _actionMessage.value = if (newPhoneE164.isBlank()) {
                        "Optional phone number removed"
                    } else {
                        "Optional phone number saved"
                    }
                }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to update phone number" }
        }
    }

    fun setTwoStepPin(pin: String, currentPin: String?, recoveryHint: String) {
        viewModelScope.launch {
            authRepository.setTwoStepPinServerSide(pin, currentPin, recoveryHint)
                .onSuccess { _actionMessage.value = "Two-Step Verification PIN saved securely on server!" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to update PIN" }
        }
    }

    fun disableTwoStepPin(currentPin: String) {
        viewModelScope.launch {
            authRepository.disableTwoStepPinServerSide(currentPin)
                .onSuccess { _actionMessage.value = "Two-Step Verification disabled" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Incorrect PIN" }
        }
    }

    fun setAppLock(enabled: Boolean, pin: String) {
        viewModelScope.launch {
            preferencesManager.setAppLock(enabled, pin)
            repository.updateUserProfileSettings(mapOf("appLockEnabled" to enabled))
            _actionMessage.value = if (enabled) "App Lock enabled" else "App Lock disabled"
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { preferencesManager.setThemeMode(mode) }
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setDarkMode(enabled) }
    }

    fun toggleOfflineBluetoothMode(enabled: Boolean) {
        offlineMeshEngine.setManualOfflineMode(enabled)
        viewModelScope.launch { preferencesManager.setBluetoothPreferred(enabled) }
        _actionMessage.value = if (enabled) {
            "Offline Bluetooth Mesh Mode ON — Messages queue locally & broadcast to nearby peers"
        } else {
            "Cloud Mode ON — Auto-syncing queued offline messages"
        }
    }

    fun startNearbyBluetoothScan() = offlineMeshEngine.startNearbyScan()
    fun stopNearbyBluetoothScan() = offlineMeshEngine.stopScan()
    fun togglePeerConnect(peerId: String) = offlineMeshEngine.togglePeerConnection(peerId)

    fun saveTurnServerConfig(url: String, username: String, credential: String) {
        viewModelScope.launch {
            preferencesManager.setTurnConfig(url, username, credential)
            _actionMessage.value = "TURN server settings saved"
        }
    }

    fun refreshMediaCacheSize() {
        viewModelScope.launch(Dispatchers.IO) {
            _mediaCacheBytes.value = storageMediaManager.calculateLocalMediaCacheBytes()
        }
    }

    fun clearLocalMediaCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val freed = storageMediaManager.clearLocalMediaCache()
            _mediaCacheBytes.value = 0L
            _actionMessage.value = "Cleared ${freed / 1024L} KB of decrypted media cache"
        }
    }

    fun setNotificationSound(category: NotificationSoundCategory, uri: String, displayName: String) {
        viewModelScope.launch {
            preferencesManager.setNotificationSound(category, uri, displayName)
            _actionMessage.value = "${category.title} sound updated"
        }
    }

    fun refreshExportedFiles(context: Context) {
        val ctx = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            _exportedFiles.value = ChatHistoryExporter.listExportedFiles(ctx)
        }
    }

    fun exportChatHistory(context: Context, chatId: String?, format: ExportFormat) {
        val ctx = context.applicationContext
        val availableChats = (chatsState.value as? UiState.Success)?.data ?: emptyList()
        val targetChats = if (chatId == null) availableChats else availableChats.filter { it.id == chatId }
        if (targetChats.isEmpty()) {
            _exportState.value = ExportUiState.Error("No chats available to export yet.")
            return
        }
        val profile = (userProfile.value as? UiState.Success)?.data
        val activeAccount = profile?.email?.ifBlank { profile.phoneE164 }
            ?: localPrefs.value.verifiedEmail.ifBlank { localPrefs.value.verifiedPhoneNumber }
        val scopeLabel = if (chatId == null) "All Chats" else targetChats.first().title

        viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting
            try {
                val entries = targetChats.map { thread ->
                    val fetched = repository.getMessagesSnapshot(thread).getOrNull() ?: emptyList()
                    thread to fetched
                }
                val exported = withContext(Dispatchers.IO) {
                    ChatHistoryExporter.exportToLocalDocuments(
                        context = ctx,
                        accountPhone = activeAccount,
                        scopeLabel = scopeLabel,
                        chatEntries = entries,
                        format = format
                    )
                }
                _exportedFiles.value = withContext(Dispatchers.IO) { ChatHistoryExporter.listExportedFiles(ctx) }
                _exportState.value = ExportUiState.Success(exported)
                _actionMessage.value = "Exported ${exported.name}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _exportState.value = ExportUiState.Error(e.localizedMessage ?: "Export failed")
            }
        }
    }

    fun deleteExportedFile(context: Context, file: ExportedChatFile) {
        val ctx = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            ChatHistoryExporter.deleteExportedFile(file.absolutePath)
            _exportedFiles.value = ChatHistoryExporter.listExportedFiles(ctx)
            _actionMessage.value = "Deleted ${file.name}"
        }
    }

    fun resetExportState() {
        _exportState.value = ExportUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        cleanupLocalCallResources()
        voiceAudioManager.release()
        offlineMeshEngine.release()
    }
}
