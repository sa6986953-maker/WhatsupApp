package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.EmailUtils
import com.example.data.repository.GmailAuthMode
import com.example.ui.components.ThemeModeSelector
import com.example.ui.components.WhatsupBrandLogo
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AuthRateLimitPolicy
import com.example.ui.viewmodel.AuthStage
import com.example.ui.viewmodel.AuthUiState
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(
    authViewModel: AuthViewModel,
    onRegisterProfile: suspend (displayName: String, about: String, localPhotoPath: String) -> Result<Unit>
) {
    val uiState by authViewModel.uiState.collectAsStateWithLifecycle()
    val themeMode by authViewModel.themeMode.collectAsStateWithLifecycle()
    val isDark = LocalIsDarkTheme.current
    val context = LocalContext.current
    var showRecoveryDialog by remember { mutableStateOf(false) }

    val headerGradientStart = if (isDark) DarkTopBar else WhatsupDarkGreen
    val headerGradientMid = if (isDark) DarkTopBar.copy(alpha = 0.92f) else WhatsupDarkGreen.copy(alpha = 0.90f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        headerGradientStart,
                        headerGradientMid,
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Global Theme Manager Toggle right in the Authentication Flow
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ThemeModeSelector(
                    selectedMode = themeMode,
                    onSelectMode = authViewModel::setThemeMode,
                    onDarkHeader = true,
                    testTagPrefix = "auth_theme"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            WhatsupBrandLogo(size = 76.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (uiState.stage == AuthStage.PROFILE_SETUP) "Complete Your Profile" else "Welcome to Whatsup",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = when (uiState.stage) {
                    AuthStage.GMAIL_ENTRY ->
                        if (uiState.authMode == GmailAuthMode.REGISTER) {
                            "Create your encrypted Whatsup account with Gmail OTP verification."
                        } else {
                            "Sign in to your existing Whatsup account with a one-time Gmail code."
                        }
                    AuthStage.OTP_ENTRY ->
                        "Enter the 6-digit verification code sent to ${uiState.normalizedGmail}."
                    AuthStage.TWO_STEP_CHALLENGE ->
                        "Two-Step Verification is active on this account."
                    AuthStage.PROFILE_SETUP ->
                        "Set your display name, local profile photo, and status to get started."
                    AuthStage.READY ->
                        "Verified & ready!"
                },
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.88f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (uiState.stage) {
                        AuthStage.GMAIL_ENTRY -> GmailEntrySection(
                            uiState = uiState,
                            onSelectMode = authViewModel::selectAuthMode,
                            onNameChange = authViewModel::updateProfileNameInput,
                            onGmailChange = authViewModel::updateGmailInput,
                            onSendOtp = { authViewModel.requestOtp(isResend = false) }
                        )
                        AuthStage.OTP_ENTRY -> OtpVerificationSection(
                            uiState = uiState,
                            onOtpChange = authViewModel::updateOtpCode,
                            onVerify = authViewModel::verifyEnteredOtp,
                            onResend = { authViewModel.requestOtp(isResend = true) },
                            onChangeEmail = authViewModel::editGmailAgain
                        )
                        AuthStage.TWO_STEP_CHALLENGE -> TwoStepChallengeSection(
                            uiState = uiState,
                            onPinChange = authViewModel::updateTwoStepPinInput,
                            onVerify = authViewModel::verifyTwoStepChallenge,
                            onForgotPin = { showRecoveryDialog = true },
                            onSignOut = { authViewModel.signOut(context) }
                        )
                        AuthStage.PROFILE_SETUP -> CompleteProfileScreenContent(
                            uiState = uiState,
                            onNameChange = authViewModel::updateProfileNameInput,
                            onStatusChange = authViewModel::updateProfileAboutInput,
                            onPickPhotoUri = authViewModel::pickLocalProfilePhoto,
                            onRemovePhoto = authViewModel::removeLocalProfilePhoto,
                            onToggleTwoStep = authViewModel::toggleOnboardingTwoStep,
                            onTwoStepPinChange = authViewModel::updateTwoStepPinInput,
                            onTwoStepConfirmChange = authViewModel::updateTwoStepConfirmInput,
                            onTwoStepHintChange = authViewModel::updateTwoStepHintInput,
                            onFinish = { authViewModel.completeOnboardingProfile(onRegisterProfile) }
                        )
                        AuthStage.READY -> Unit
                    }

                    if (!uiState.infoBanner.isNullOrBlank()) {
                        val infoTint = if (isDark) WhatsupGreen else WhatsupDarkGreen
                        Surface(
                            color = WhatsupGreen.copy(alpha = if (isDark) 0.18f else 0.14f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = infoTint,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = uiState.infoBanner!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = infoTint,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    if (!uiState.errorMessage.isNullOrBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_error_banner")
                        ) {
                            Text(
                                text = uiState.errorMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (uiState.isLoading) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = WhatsupGreen,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Communicating securely with Whatsup Cloud...",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Filled.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Server-Verified Gmail OTP • E2EE Messaging • 100m Bluetooth Mesh",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showRecoveryDialog) {
        var recoveryAnswer by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRecoveryDialog = false },
            title = { Text("Recover Two-Step PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Enter your recovery hint/answer (if set) and choose a new 6-digit PIN.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = recoveryAnswer,
                        onValueChange = { recoveryAnswer = it.take(120) },
                        label = { Text("Recovery Answer") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("New 6-digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { confirmPin = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("Confirm New PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        authViewModel.recoverTwoStepPin(recoveryAnswer, newPin, confirmPin)
                        showRecoveryDialog = false
                    }
                ) { Text("Reset PIN") }
            },
            dismissButton = {
                TextButton(onClick = { showRecoveryDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun GmailEntrySection(
    uiState: AuthUiState,
    onSelectMode: (GmailAuthMode) -> Unit,
    onNameChange: (String) -> Unit,
    onGmailChange: (String) -> Unit,
    onSendOtp: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ModeTabButton(
            label = "Register",
            selected = uiState.authMode == GmailAuthMode.REGISTER,
            modifier = Modifier
                .weight(1f)
                .testTag("auth_mode_register"),
            onClick = { onSelectMode(GmailAuthMode.REGISTER) }
        )
        ModeTabButton(
            label = "Sign In",
            selected = uiState.authMode == GmailAuthMode.LOGIN,
            modifier = Modifier
                .weight(1f)
                .testTag("auth_mode_login"),
            onClick = { onSelectMode(GmailAuthMode.LOGIN) }
        )
    }

    Text(
        text = if (uiState.authMode == GmailAuthMode.REGISTER) {
            "Register a new Whatsup account"
        } else {
            "Sign in with your verified Gmail"
        },
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
    )

    if (uiState.authMode == GmailAuthMode.REGISTER) {
        OutlinedTextField(
            value = uiState.profileNameInput,
            onValueChange = onNameChange,
            label = { Text("Full Name") },
            placeholder = { Text("e.g. Ayesha Khan") },
            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
            singleLine = true,
            enabled = !uiState.isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_register_name_input")
        )
    }

    OutlinedTextField(
        value = uiState.gmailInput,
        onValueChange = onGmailChange,
        label = { Text("Gmail Address") },
        placeholder = { Text("yourname@gmail.com") },
        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        singleLine = true,
        enabled = !uiState.isLoading,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_gmail_input")
    )

    Text(
        text = "We will send a secure 6-digit OTP to your Gmail inbox (expires in 5 minutes).",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Button(
        onClick = onSendOtp,
        enabled = !uiState.isLoading,
        colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("auth_send_otp_button")
    ) {
        Icon(Icons.Filled.MarkEmailRead, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = if (uiState.authMode == GmailAuthMode.REGISTER) "Register & Send OTP" else "Send Login OTP",
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ModeTabButton(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) WhatsupGreen else Color.Transparent,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun OtpVerificationSection(
    uiState: AuthUiState,
    onOtpChange: (String) -> Unit,
    onVerify: () -> Unit,
    onResend: () -> Unit,
    onChangeEmail: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.AlternateEmail, contentDescription = null, tint = WhatsupGreen, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Verify Gmail OTP", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                text = uiState.normalizedGmail,
                style = MaterialTheme.typography.bodySmall,
                color = WhatsupGreen,
                fontWeight = FontWeight.SemiBold
            )
        }
    }

    Surface(
        color = if (uiState.otpExpiresInSeconds > 30) {
            BluetoothBlue.copy(alpha = 0.12f)
        } else {
            MaterialTheme.colorScheme.errorContainer
        },
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Timer,
                contentDescription = null,
                tint = if (uiState.otpExpiresInSeconds > 30) BluetoothBlue else MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (uiState.otpExpiresInSeconds > 0) {
                    "Code expires in ${EmailUtils.formatCountdown(uiState.otpExpiresInSeconds)}"
                } else {
                    "Code expired — tap Resend OTP below"
                },
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (uiState.otpExpiresInSeconds > 30) BluetoothBlue else MaterialTheme.colorScheme.error
            )
        }
    }

    OutlinedTextField(
        value = uiState.otpCodeInput,
        onValueChange = onOtpChange,
        label = { Text("6-Digit Verification Code") },
        placeholder = { Text("• • • • • •") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        singleLine = true,
        enabled = !uiState.isLoading,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_otp_input")
    )

    val attemptsLeft = (AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS - uiState.verifyAttemptsUsed).coerceAtLeast(0)
    Text(
        text = "Check your Gmail Inbox or Spam folder • $attemptsLeft verification attempt(s) remaining",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Button(
        onClick = onVerify,
        enabled = !uiState.isLoading && uiState.otpCodeInput.length == 6 && uiState.otpExpiresInSeconds > 0,
        colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("auth_verify_otp_button")
    ) {
        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("Verify & Continue", color = Color.White, fontWeight = FontWeight.Bold)
    }

    val remainingResends = (AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION - uiState.resendsUsed).coerceAtLeast(0)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(
            onClick = onResend,
            enabled = !uiState.isLoading && uiState.resendCooldownSeconds == 0 && remainingResends > 0,
            modifier = Modifier.testTag("auth_resend_otp_button")
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                if (uiState.resendCooldownSeconds > 0) {
                    "Resend in ${uiState.resendCooldownSeconds}s"
                } else {
                    "Resend OTP ($remainingResends left)"
                }
            )
        }
        TextButton(
            onClick = onChangeEmail,
            enabled = !uiState.isLoading,
            modifier = Modifier.testTag("auth_change_gmail_button")
        ) {
            Text("Change Gmail")
        }
    }
}

@Composable
private fun TwoStepChallengeSection(
    uiState: AuthUiState,
    onPinChange: (String) -> Unit,
    onVerify: () -> Unit,
    onForgotPin: () -> Unit,
    onSignOut: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Two-Step Verification PIN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
    Text(
        text = "Enter your private 6-digit Two-Step PIN to unlock Whatsup for ${uiState.normalizedGmail}.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = uiState.twoStepPinInput,
        onValueChange = onPinChange,
        label = { Text("6-Digit Two-Step PIN") },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_two_step_pin_input")
    )
    Button(
        onClick = onVerify,
        enabled = !uiState.isLoading && uiState.twoStepPinInput.length == 6,
        colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("auth_two_step_verify_button")
    ) {
        Text("Unlock Account", color = Color.White, fontWeight = FontWeight.Bold)
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        TextButton(onClick = onForgotPin) { Text("Forgot PIN?") }
        TextButton(onClick = onSignOut) { Text("Use another Gmail") }
    }
}
