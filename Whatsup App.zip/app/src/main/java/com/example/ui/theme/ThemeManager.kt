package com.example.ui.theme

enum class AppThemeMode(
    val storageKey: String,
    val label: String
) {
    SYSTEM("system", "System"),
    LIGHT("light", "Light"),
    DARK("dark", "Dark");

    companion object {
        fun fromStorageKey(key: String?): AppThemeMode {
            return entries.firstOrNull { it.storageKey.equals(key?.trim(), ignoreCase = true) }
                ?: SYSTEM
        }
    }
}

object ThemeManager {
    fun resolveDarkTheme(mode: AppThemeMode, isSystemDark: Boolean): Boolean {
        return when (mode) {
            AppThemeMode.SYSTEM -> isSystemDark
            AppThemeMode.LIGHT -> false
            AppThemeMode.DARK -> true
        }
    }
}
