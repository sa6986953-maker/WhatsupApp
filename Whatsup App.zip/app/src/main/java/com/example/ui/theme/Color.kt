package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary WhatsApp / Whatsup Brand Colors
val WhatsupGreen = Color(0xFF25D366)
val WhatsupDarkGreen = Color(0xFF075E54)
val WhatsupTealGreen = Color(0xFF128C7E)
val WhatsupEmeraldAccent = Color(0xFF1DAB61)
val BluetoothBlue = Color(0xFF1D9BF0)
val BluetoothBlueContainer = Color(0xFFE3F2FD)
val BluetoothBlueDarkContainer = Color(0xFF0D2D45)
val TickBlue = Color(0xFF53BDEB)

// Light Mode Surface & Bubble Tokens
val LightBackground = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F2F5)
val LightSentBubble = Color(0xFFD9FDD3)
val LightReceivedBubble = Color(0xFFFFFFFF)
val LightChatCanvas = Color(0xFFEFEAE2)
val LightTextPrimary = Color(0xFF111B21)
val LightTextSecondary = Color(0xFF667781)
val LightDivider = Color(0xFFE9EDEF)

// Dark Mode Surface & Bubble Tokens
val DarkBackground = Color(0xFF0B141A)
val DarkSurface = Color(0xFF111B21)
val DarkSurfaceVariant = Color(0xFF1F2C34)
val DarkTopBar = Color(0xFF1F2C34)
val DarkSentBubble = Color(0xFF005C4B)
val DarkReceivedBubble = Color(0xFF202C33)
val DarkChatCanvas = Color(0xFF0B141A)
val DarkTextPrimary = Color(0xFFE9EDEF)
val DarkTextSecondary = Color(0xFF8696A0)
val DarkDivider = Color(0xFF222E35)

// Status & Semantic Colors
val OnlineIndicator = Color(0xFF25D366)
val MissedCallRed = Color(0xFFEF5350)
val GoldStar = Color(0xFFFFB300)
val EncryptionAmber = Color(0xFFFEEFB3)
val EncryptionAmberText = Color(0xFF544200)
