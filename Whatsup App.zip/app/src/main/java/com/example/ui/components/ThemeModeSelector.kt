package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.WhatsupGreen

/**
 * Global segmented selector to toggle between System, Light, and Dark modes.
 * Set [onDarkHeader] = true when placed over a dark emerald gradient (e.g. AuthScreen).
 */
@Composable
fun ThemeModeSelector(
    selectedMode: AppThemeMode,
    onSelectMode: (AppThemeMode) -> Unit,
    modifier: Modifier = Modifier,
    onDarkHeader: Boolean = false,
    testTagPrefix: String = "theme_mode"
) {
    val containerColor = if (onDarkHeader) {
        Color.Black.copy(alpha = 0.28f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)
    }
    val borderColor = if (onDarkHeader) {
        Color.White.copy(alpha = 0.22f)
    } else {
        MaterialTheme.colorScheme.outlineVariant
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(containerColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppThemeMode.entries.forEach { mode ->
            val selected = mode == selectedMode
            val icon = when (mode) {
                AppThemeMode.SYSTEM -> Icons.Filled.BrightnessAuto
                AppThemeMode.LIGHT -> Icons.Filled.LightMode
                AppThemeMode.DARK -> Icons.Filled.DarkMode
            }
            val itemBg = when {
                selected -> WhatsupGreen
                else -> Color.Transparent
            }
            val itemFg = when {
                selected -> Color.White
                onDarkHeader -> Color.White.copy(alpha = 0.90f)
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }

            Surface(
                color = itemBg,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f, fill = false)
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(role = Role.RadioButton) { onSelectMode(mode) }
                    .testTag("${testTagPrefix}_${mode.storageKey}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "${mode.label} theme",
                        tint = itemFg,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = mode.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = itemFg,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun ThemeModeSettingsRow(
    selectedMode: AppThemeMode,
    onSelectMode: (AppThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ThemeModeSelector(
            selectedMode = selectedMode,
            onSelectMode = onSelectMode,
            onDarkHeader = false,
            testTagPrefix = "settings_theme",
            modifier = Modifier.fillMaxWidth()
        )
    }
}
