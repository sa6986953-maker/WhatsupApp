package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val LocalIsDarkTheme = compositionLocalOf { false }

private val WhatsupLightColorScheme = lightColorScheme(
    primary = WhatsupEmeraldAccent,
    onPrimary = Color.White,
    primaryContainer = LightSentBubble,
    onPrimaryContainer = WhatsupDarkGreen,
    secondary = WhatsupTealGreen,
    onSecondary = Color.White,
    secondaryContainer = BluetoothBlueContainer,
    onSecondaryContainer = BluetoothBlue,
    tertiary = BluetoothBlue,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightBackground,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outlineVariant = LightDivider
)

private val WhatsupDarkColorScheme = darkColorScheme(
    primary = WhatsupGreen,
    onPrimary = Color(0xFF003919),
    primaryContainer = DarkSentBubble,
    onPrimaryContainer = DarkTextPrimary,
    secondary = WhatsupTealGreen,
    onSecondary = Color.White,
    secondaryContainer = BluetoothBlueDarkContainer,
    onSecondaryContainer = BluetoothBlue,
    tertiary = BluetoothBlue,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outlineVariant = DarkDivider
)

@Composable
fun WhatsupTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val resolvedDark = ThemeManager.resolveDarkTheme(
        mode = themeMode,
        isSystemDark = isSystemInDarkTheme()
    )
    WhatsupTheme(darkTheme = resolvedDark, content = content)
}

@Composable
fun WhatsupTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) WhatsupDarkColorScheme else WhatsupLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity
            val window = activity?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
    CompositionLocalProvider(LocalIsDarkTheme provides darkTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = WhatsupTypography,
            content = content
        )
    }
}
