package com.example.ui.screens.calls

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.SignalCellularAlt1Bar
import androidx.compose.material.icons.filled.SignalCellularAlt2Bar
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.core.CallSignalQuality
import com.example.core.LatencyReading
import com.example.core.NetworkLatencyMonitor
import com.example.core.VoiceAudioManager
import com.example.core.WebRtcCallManager
import com.example.core.WebRtcStatsState
import com.example.data.model.CallRecord
import com.example.data.model.UiState
import com.example.data.model.VerifiedContact
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.MissedCallRed
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import org.webrtc.SurfaceViewRenderer

@Composable
fun CallsScreen(
    callsState: UiState<List<CallRecord>>,
    verifiedContacts: List<VerifiedContact>,
    onCreateCallLink: (callType: String) -> Unit,
    onStartCallWithContact: (contact: VerifiedContact, isVideo: Boolean) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var showNewCallPicker by remember { mutableStateOf(false) }

    when (callsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = WhatsupGreen)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(callsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "call_link_card") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onCreateCallLink("VIDEO") }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(WhatsupGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Link, contentDescription = "Create call link", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Create call link", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "Generate a Whatsup WebRTC call session link",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item(key = "new_call_card") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Start Encrypted WebRTC Call", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (verifiedContacts.isEmpty()) {
                                    "Add a registered contact from Chats to make 1-to-1 Voice or Video calls."
                                } else {
                                    "Place real peer-to-peer audio or video calls with verified contacts."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = { showNewCallPicker = true },
                                enabled = verifiedContacts.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("start_webrtc_call_button")
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Select Contact to Call")
                            }
                        }
                    }
                }

                item(key = "recent_calls_title") {
                    Text(
                        text = "Recent Calls",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (callsState.data.isEmpty()) {
                    item(key = "no_calls_empty") {
                        Text(
                            text = "No call history yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(callsState.data, key = { it.id }) { call ->
                        val matchingContact = verifiedContacts.firstOrNull { it.contactUid == call.peerUid }
                            ?: if (call.peerUid.isNotBlank()) VerifiedContact(contactUid = call.peerUid, savedName = call.peerName) else null
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    if (!call.callLinkCode.isNullOrBlank()) {
                                        clipboard.setText(AnnotatedString(call.callLinkCode))
                                    } else if (matchingContact != null) {
                                        onStartCallWithContact(matchingContact, call.callType.contains("VIDEO"))
                                    }
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(WhatsupDarkGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = call.peerName.ifBlank { "W" }.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = call.callLinkCode ?: call.peerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (call.direction == "MISSED") MissedCallRed else MaterialTheme.colorScheme.onSurface
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (call.direction == "OUTGOING") Icons.AutoMirrored.Filled.CallMade else Icons.AutoMirrored.Filled.CallReceived,
                                        contentDescription = null,
                                        tint = if (call.direction == "MISSED") MissedCallRed else WhatsupGreen,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${call.status} • ${call.timeLabel} • ${call.durationLabel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            if (matchingContact != null) {
                                IconButton(onClick = {
                                    onStartCallWithContact(matchingContact, call.callType.contains("VIDEO"))
                                }) {
                                    Icon(
                                        imageVector = if (call.callType.contains("VIDEO")) Icons.Filled.Videocam else Icons.Filled.Call,
                                        contentDescription = "Call",
                                        tint = WhatsupGreen
                                    )
                                }
                            }
                        }
                    }
                }

                item(key = "calls_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (showNewCallPicker) {
        AlertDialog(
            onDismissRequest = { showNewCallPicker = false },
            title = { Text("Select Verified Contact") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 340.dp)) {
                    items(verifiedContacts, key = { it.contactUid }) { contact ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(contact.savedName, fontWeight = FontWeight.SemiBold)
                                Text(contact.phoneE164, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = {
                                showNewCallPicker = false
                                onStartCallWithContact(contact, false)
                            }) {
                                Icon(Icons.Filled.Call, contentDescription = "Voice Call", tint = WhatsupGreen)
                            }
                            IconButton(onClick = {
                                showNewCallPicker = false
                                onStartCallWithContact(contact, true)
                            }) {
                                Icon(Icons.Filled.Videocam, contentDescription = "Video Call", tint = BluetoothBlue)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNewCallPicker = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ActiveCallOverlay(
    call: CallRecord,
    currentUserId: String,
    webrtcManager: WebRtcCallManager,
    webrtcState: WebRtcStatsState,
    durationSeconds: Long,
    onEndCall: () -> Unit
) {
    BackHandler { onEndCall() }

    val isVideo = call.callType.contains("VIDEO")
    val peerDisplay = if (call.callerUid == currentUserId) call.calleeName else call.callerName

    val avPermissions = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(isVideo) {
        val perms = if (isVideo) {
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }
        avPermissions.launch(perms)
    }

    val context = LocalContext.current
    val latencyReading by produceState(
        initialValue = LatencyReading(latencyMs = null, quality = CallSignalQuality.FAIR, transportLabel = "Probing"),
        key1 = context
    ) {
        NetworkLatencyMonitor.observeLatency(context).collect { reading ->
            value = reading
        }
    }

    val targetSignalColor = when (latencyReading.quality) {
        CallSignalQuality.GOOD -> WhatsupGreen
        CallSignalQuality.FAIR -> Color(0xFFFFC107)
        CallSignalQuality.POOR -> Color(0xFFE53935)
    }
    val signalColor by animateColorAsState(
        targetValue = targetSignalColor,
        animationSpec = tween(durationMillis = 350),
        label = "call_signal_color"
    )
    val signalIcon = when (latencyReading.quality) {
        CallSignalQuality.GOOD -> Icons.Filled.SignalCellularAlt
        CallSignalQuality.FAIR -> Icons.Filled.SignalCellularAlt2Bar
        CallSignalQuality.POOR -> Icons.Filled.SignalCellularAlt1Bar
    }

    var localRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    var remoteRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }

    DisposableEffect(webrtcState.initialized, isVideo) {
        if (webrtcState.initialized && isVideo && localRenderer != null && remoteRenderer != null) {
            webrtcManager.attachRenderers(localRenderer, remoteRenderer)
        }
        onDispose { }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B141A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = peerDisplay.ifBlank { "Whatsup Call" },
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = buildString {
                            append(if (isVideo) "WebRTC Video Call" else "WebRTC Voice Call")
                            append(" • ")
                            append(
                                if (call.status == "RINGING") "Ringing..." else VoiceAudioManager.formatDuration(durationSeconds.toInt())
                            )
                            append(" • ICE: ${webrtcState.iceState}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = WhatsupGreen
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                val latencyLabel = latencyReading.latencyMs?.let { "${it}ms" } ?: latencyReading.transportLabel
                Surface(
                    color = signalColor.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, signalColor.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("call_signal_strength_indicator")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = signalIcon,
                            contentDescription = "Signal strength ${latencyReading.quality.label}: $latencyLabel",
                            tint = signalColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = latencyReading.quality.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = signalColor
                            )
                            Text(
                                text = latencyLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF1A2730)),
                contentAlignment = Alignment.Center
            ) {
                if (isVideo && webrtcState.initialized) {
                    AndroidView(
                        factory = { ctx -> SurfaceViewRenderer(ctx).also { remoteRenderer = it } },
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .size(width = 110.dp, height = 150.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black)
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                SurfaceViewRenderer(ctx).also {
                                    it.setZOrderMediaOverlay(true)
                                    localRenderer = it
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(WhatsupDarkGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = peerDisplay.ifBlank { "W" }.take(1).uppercase(),
                                style = MaterialTheme.typography.headlineLarge,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = if (call.status == "RINGING") "Waiting for answer..." else "End-to-End Encrypted Audio",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (webrtcState.error != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(webrtcState.error, color = MissedCallRed, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { webrtcManager.toggleMute() },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (webrtcState.muted) Color.White else Color(0xFF2A3942))
                ) {
                    Icon(
                        imageVector = if (webrtcState.muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        contentDescription = "Mute",
                        tint = if (webrtcState.muted) Color.Black else Color.White
                    )
                }

                IconButton(
                    onClick = { webrtcManager.toggleSpeakerphone() },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (webrtcState.speakerOn) BluetoothBlue else Color(0xFF2A3942))
                ) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = "Speakerphone", tint = Color.White)
                }

                if (isVideo) {
                    IconButton(
                        onClick = { webrtcManager.switchCamera() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2A3942))
                    ) {
                        Icon(Icons.Filled.Cameraswitch, contentDescription = "Switch Camera", tint = Color.White)
                    }
                }

                IconButton(
                    onClick = onEndCall,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MissedCallRed)
                        .testTag("end_call_button")
                ) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
        }
    }
}
