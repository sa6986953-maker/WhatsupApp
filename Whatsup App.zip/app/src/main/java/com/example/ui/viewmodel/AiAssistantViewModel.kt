package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.repository.WhatsupAiRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val TAG = "AiAssistantViewModel"

sealed interface AiPanelState {
    data object Idle : AiPanelState
    data object Loading : AiPanelState
    data class Streaming(val text: String, val taskTitle: String) : AiPanelState
    data class Success(val text: String, val taskTitle: String) : AiPanelState
    data class Error(val message: String) : AiPanelState
}

sealed interface InlineSummaryState {
    data object Idle : InlineSummaryState
    data object Loading : InlineSummaryState
    data class Streaming(val text: String) : InlineSummaryState
    data class Success(val text: String) : InlineSummaryState
    data class Error(val message: String) : InlineSummaryState
}

sealed interface SuggestedRepliesState {
    data object Idle : SuggestedRepliesState
    data object Loading : SuggestedRepliesState
    data class Success(val replies: List<String>) : SuggestedRepliesState
    data class Error(val message: String) : SuggestedRepliesState
}

class AiAssistantViewModel(
    private val aiRepository: WhatsupAiRepository = WhatsupAiRepository()
) : ViewModel() {

    private val _state = MutableStateFlow<AiPanelState>(AiPanelState.Idle)
    val state: StateFlow<AiPanelState> = _state.asStateFlow()

    private val _inlineSummaryState = MutableStateFlow<InlineSummaryState>(InlineSummaryState.Idle)
    val inlineSummaryState: StateFlow<InlineSummaryState> = _inlineSummaryState.asStateFlow()

    private val _suggestedRepliesState =
        MutableStateFlow<SuggestedRepliesState>(SuggestedRepliesState.Idle)
    val suggestedRepliesState: StateFlow<SuggestedRepliesState> = _suggestedRepliesState.asStateFlow()

    private var activeJob: Job? = null
    private var inlineSummaryJob: Job? = null
    private var suggestedRepliesJob: Job? = null
    private var currentChatId: String? = null

    fun onChatThreadChanged(chatId: String?) {
        if (chatId != currentChatId) {
            currentChatId = chatId
            dismissInlineSummary()
            dismissSuggestedReplies()
        }
    }

    fun summarizeThreadInline(chatTitle: String, messages: List<ChatMessage>) {
        inlineSummaryJob?.cancel()
        inlineSummaryJob = viewModelScope.launch {
            _inlineSummaryState.value = InlineSummaryState.Loading
            var lastText = ""
            try {
                aiRepository.summarizeChatStream(chatTitle, messages).collect { partial ->
                    lastText = partial
                    _inlineSummaryState.value = InlineSummaryState.Streaming(partial)
                }
                if (lastText.isNotBlank()) {
                    _inlineSummaryState.value = InlineSummaryState.Success(lastText)
                } else {
                    _inlineSummaryState.value =
                        InlineSummaryState.Error("Whatsup AI returned an empty summary.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Inline chat summary failed", e)
                _inlineSummaryState.value = InlineSummaryState.Error(
                    e.localizedMessage ?: "Unable to summarize chat right now."
                )
            }
        }
    }

    fun dismissInlineSummary() {
        inlineSummaryJob?.cancel()
        _inlineSummaryState.value = InlineSummaryState.Idle
    }

    fun generateThreadSuggestions(chatTitle: String, messages: List<ChatMessage>) {
        suggestedRepliesJob?.cancel()
        suggestedRepliesJob = viewModelScope.launch {
            _suggestedRepliesState.value = SuggestedRepliesState.Loading
            try {
                val replies = aiRepository.generateSuggestedReplies(chatTitle, messages)
                _suggestedRepliesState.value = SuggestedRepliesState.Success(replies)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Suggested replies generation failed", e)
                _suggestedRepliesState.value = SuggestedRepliesState.Error(
                    e.localizedMessage ?: "Unable to generate suggested replies."
                )
            }
        }
    }

    fun dismissSuggestedReplies() {
        suggestedRepliesJob?.cancel()
        _suggestedRepliesState.value = SuggestedRepliesState.Idle
    }

    fun summarizeChat(chatTitle: String, messages: List<ChatMessage>) {
        launchAiTask("Chat Summary ($chatTitle)") {
            aiRepository.summarizeChatStream(chatTitle, messages)
        }
    }

    fun translateMessage(messageText: String, targetLanguage: String) {
        launchAiTask("Translated to $targetLanguage") {
            aiRepository.translateMessageStream(messageText, targetLanguage)
        }
    }

    fun draftReply(chatTitle: String, messages: List<ChatMessage>, tone: String) {
        launchAiTask("Suggested Reply ($tone)") {
            aiRepository.draftReplyStream(chatTitle, messages, tone)
        }
    }

    fun askAssistant(question: String, chatTitle: String, messages: List<ChatMessage>) {
        if (question.isBlank()) return
        launchAiTask("Whatsup AI Answer") {
            aiRepository.askAssistantStream(question, chatTitle, messages)
        }
    }

    fun reset() {
        activeJob?.cancel()
        _state.value = AiPanelState.Idle
    }

    private fun launchAiTask(title: String, flowProvider: () -> kotlinx.coroutines.flow.Flow<String>) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _state.value = AiPanelState.Loading
            var lastText = ""
            try {
                flowProvider().collect { partial ->
                    lastText = partial
                    _state.value = AiPanelState.Streaming(partial, title)
                }
                if (lastText.isNotBlank()) {
                    _state.value = AiPanelState.Success(lastText, title)
                } else {
                    _state.value = AiPanelState.Error("Whatsup AI returned an empty response.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI task failed", e)
                _state.value = AiPanelState.Error(e.localizedMessage ?: "Whatsup AI request failed.")
            }
        }
    }
}
