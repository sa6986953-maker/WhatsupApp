package com.example.ui.screens.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.VoicePlaybackState
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.MessageReactionHelper
import com.example.ui.components.MessageTickBadge
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkReceivedBubble
import com.example.ui.theme.DarkSentBubble
import com.example.ui.theme.GoldStar
import com.example.ui.theme.LightReceivedBubble
import com.example.ui.theme.LightSentBubble
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    isGroup: Boolean,
    darkMode: Boolean,
    hideBlueTicks: Boolean,
    voicePlaybackState: VoicePlaybackState,
    highlightQuery: String = "",
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onForward: () -> Unit,
    onTranslateWithAi: () -> Unit,
    onStar: () -> Unit,
    onReact: (String) -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit,
    onOpenViewOnce: () -> Unit,
    onPlayVoice: () -> Unit,
    onOpenAttachment: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val bubbleColor = when {
        message.fromMe && darkMode -> DarkSentBubble
        message.fromMe -> LightSentBubble
        darkMode -> DarkReceivedBubble
        else -> LightReceivedBubble
    }

    val sortedReactions = remember(message.reactions) {
        message.reactions.entries
            .filter { it.value > 0L }
            .sortedByDescending { it.value }
    }

    val isThisVoicePlaying = voicePlaybackState.playingMessageId == message.id && voicePlaybackState.isPlaying

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromMe) Arrangement.End else Arrangement.Start
    ) {
        Column(horizontalAlignment = if (message.fromMe) Alignment.End else Alignment.Start) {
            Box {
                Surface(
                    color = bubbleColor,
                    shape = RoundedCornerShape(
                        topStart = if (message.fromMe) 12.dp else 4.dp,
                        topEnd = if (message.fromMe) 4.dp else 12.dp,
                        bottomStart = 12.dp,
                        bottomEnd = 12.dp
                    ),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .widthIn(min = 90.dp, max = 300.dp)
                        .testTag("chat_bubble_${message.id}")
                        .combinedClickable(
                            onClick = {
                                when {
                                    message.messageType == "VIEW_ONCE" -> onOpenViewOnce()
                                    message.messageType == "VOICE" -> onPlayVoice()
                                    !message.mediaStoragePath.isNullOrBlank() -> onOpenAttachment()
                                }
                            },
                            onLongClick = { showMenu = true }
                        )
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                        if (isGroup && !message.fromMe) {
                            Text(
                                text = message.senderName,
                                style = MaterialTheme.typography.labelMedium,
                                color = WhatsupGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!message.replyToText.isNullOrBlank()) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.07f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(
                                        text = message.replyToSender ?: "Reply",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WhatsupGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = message.replyToText,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        if (message.viaBluetooth) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(bottom = 2.dp)
                            ) {
                                Icon(
                                    Icons.Filled.BluetoothConnected,
                                    contentDescription = "Sent via Bluetooth",
                                    tint = BluetoothBlue,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Sent via Bluetooth",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BluetoothBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        when {
                            message.messageType == "VIEW_ONCE" -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Filled.Lock,
                                        contentDescription = "View Once",
                                        tint = if (message.viewOnceOpened) MaterialTheme.colorScheme.onSurfaceVariant else WhatsupGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (message.viewOnceOpened) "Opened (View Once)" else "① Tap to open View Once",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (message.viewOnceOpened) MaterialTheme.colorScheme.onSurfaceVariant else WhatsupDarkGreen
                                    )
                                }
                            }
                            message.messageType == "VOICE" -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    IconButton(
                                        onClick = onPlayVoice,
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isThisVoicePlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                            contentDescription = if (isThisVoicePlaying) "Pause voice" else "Play voice",
                                            tint = WhatsupGreen
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = message.text,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium
                                        )
                                        if (voicePlaybackState.playingMessageId == message.id && voicePlaybackState.durationMs > 0) {
                                            Text(
                                                text = "${voicePlaybackState.positionMs / 1000}s / ${voicePlaybackState.durationMs / 1000}s",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = WhatsupGreen
                                            )
                                        }
                                    }
                                }
                            }
                            highlightQuery.isNotBlank() -> {
                                val highlighted = buildAnnotatedString {
                                    val text = message.text
                                    var startIndex = 0
                                    while (startIndex < text.length) {
                                        val matchIndex = text.indexOf(highlightQuery, startIndex, ignoreCase = true)
                                        if (matchIndex < 0) {
                                            append(text.substring(startIndex))
                                            break
                                        }
                                        if (matchIndex > startIndex) {
                                            append(text.substring(startIndex, matchIndex))
                                        }
                                        withStyle(
                                            SpanStyle(
                                                background = WhatsupGreen.copy(alpha = 0.36f),
                                                fontWeight = FontWeight.Bold
                                            )
                                        ) {
                                            append(text.substring(matchIndex, matchIndex + highlightQuery.length))
                                        }
                                        startIndex = matchIndex + highlightQuery.length
                                    }
                                }
                                Text(text = highlighted, style = MaterialTheme.typography.bodyLarge)
                            }
                            else -> {
                                Text(text = message.text, style = MaterialTheme.typography.bodyLarge)
                            }
                        }

                        if (!message.mediaMeta.isNullOrBlank() && message.messageType != "VIEW_ONCE") {
                            Spacer(modifier = Modifier.height(3.dp))
                            Surface(
                                color = Color.Black.copy(alpha = 0.06f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (!message.mediaStoragePath.isNullOrBlank() && message.messageType != "VOICE") {
                                        Icon(
                                            imageVector = if (message.messageType == "DOCUMENT") Icons.Filled.AttachFile else Icons.Filled.Download,
                                            contentDescription = "Open encrypted attachment",
                                            tint = WhatsupDarkGreen,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                    Text(
                                        text = message.mediaMeta,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.align(Alignment.End),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (message.edited && !message.deletedForEveryone) {
                                Text(
                                    text = "edited • ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (message.starred) {
                                Icon(
                                    Icons.Filled.Star,
                                    contentDescription = "Starred",
                                    tint = GoldStar,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = message.timeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (message.fromMe) {
                                Spacer(modifier = Modifier.width(4.dp))
                                MessageTickBadge(
                                    tickStatus = message.tickStatus,
                                    viaBluetooth = message.viaBluetooth,
                                    hideBlueTicks = hideBlueTicks
                                )
                            }
                        }
                    }
                }

                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("reaction_picker_row_${message.id}"),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MessageReactionHelper.quickEmojis.forEachIndexed { idx, emoji ->
                            val selected = message.myReaction == emoji
                            Surface(
                                shape = CircleShape,
                                color = if (selected) WhatsupGreen.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                border = if (selected) BorderStroke(1.dp, WhatsupGreen) else null,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        showMenu = false
                                        onReact(emoji)
                                    }
                                    .testTag("reaction_pick_${message.id}_$idx")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = emoji, fontSize = 18.sp)
                                }
                            }
                        }
                    }
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Reply") }, onClick = { showMenu = false; onReply() })
                    DropdownMenuItem(text = { Text("Copy") }, onClick = { showMenu = false; onCopy() })
                    if (message.fromMe && !message.deletedForEveryone && message.messageType == "TEXT") {
                        DropdownMenuItem(text = { Text("Edit") }, onClick = { showMenu = false; onEdit() })
                    }
                    DropdownMenuItem(text = { Text("Forward") }, onClick = { showMenu = false; onForward() })
                    DropdownMenuItem(text = { Text("Translate with Whatsup AI") }, onClick = { showMenu = false; onTranslateWithAi() })
                    DropdownMenuItem(text = { Text(if (message.starred) "Unstar" else "Star message") }, onClick = { showMenu = false; onStar() })
                    DropdownMenuItem(text = { Text("Delete for me") }, onClick = { showMenu = false; onDeleteForMe() })
                    if (message.fromMe && !message.deletedForEveryone) {
                        DropdownMenuItem(text = { Text("Delete for everyone") }, onClick = { showMenu = false; onDeleteForEveryone() })
                    }
                }
            }

            if (sortedReactions.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .padding(top = 2.dp, start = 6.dp, end = 6.dp)
                        .testTag("message_reactions_${message.id}"),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    sortedReactions.forEach { (emoji, count) ->
                        val isMine = message.myReaction == emoji
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isMine) WhatsupGreen.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (isMine) WhatsupGreen else MaterialTheme.colorScheme.outlineVariant
                            ),
                            shadowElevation = 1.dp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onReact(emoji) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(text = emoji, fontSize = 13.sp)
                                Text(
                                    text = count.toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isMine) WhatsupDarkGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatDialogsHost(
    chat: ChatThread,
    allChats: List<ChatThread>,
    initialInputText: String,
    showScheduleDialog: Boolean,
    onDismissSchedule: () -> Unit,
    onScheduleSend: (text: String, delayMins: Int) -> Unit,
    showDisappearingDialog: Boolean,
    onDismissDisappearing: () -> Unit,
    onSetDisappearing: (String) -> Unit,
    showWallpaperDialog: Boolean,
    onDismissWallpaper: () -> Unit,
    onSetWallpaper: (String) -> Unit,
    viewOncePreviewMsg: ChatMessage?,
    onDismissViewOnce: () -> Unit,
    forwardTargetMsg: ChatMessage?,
    onDismissForward: () -> Unit,
    onForwardTo: (targetChatId: String, msg: ChatMessage) -> Unit,
    editTargetMsg: ChatMessage?,
    onDismissEdit: () -> Unit,
    onConfirmEdit: (ChatMessage, String) -> Unit,
    showSafetyNumberDialog: Boolean,
    onDismissSafetyNumber: () -> Unit,
    biometricNotice: String?,
    onDismissBiometricNotice: () -> Unit
) {
    if (showScheduleDialog) {
        var schedText by remember(initialInputText) { mutableStateOf(initialInputText) }
        var delayMins by remember { mutableStateOf("15") }
        AlertDialog(
            onDismissRequest = onDismissSchedule,
            icon = { Icon(Icons.Filled.Timer, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Message Scheduler") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Schedule a message to send after a delay", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = schedText, onValueChange = { schedText = it }, label = { Text("Message") })
                    OutlinedTextField(
                        value = delayMins,
                        onValueChange = { delayMins = it.filter { c -> c.isDigit() } },
                        label = { Text("Delay (minutes)") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (schedText.isNotBlank()) {
                        onScheduleSend(schedText.trim(), delayMins.toIntOrNull() ?: 15)
                        onDismissSchedule()
                    }
                }) { Text("Schedule") }
            },
            dismissButton = { TextButton(onClick = onDismissSchedule) { Text("Cancel") } }
        )
    }

    if (showDisappearingDialog) {
        AlertDialog(
            onDismissRequest = onDismissDisappearing,
            title = { Text("Disappearing Messages") },
            text = {
                Column {
                    listOf("OFF", "24H", "7D", "90D").forEach { mode ->
                        TextButton(
                            onClick = {
                                onSetDisappearing(mode)
                                onDismissDisappearing()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when (mode) {
                                    "24H" -> "24 Hours"
                                    "7D" -> "7 Days"
                                    "90D" -> "90 Days"
                                    else -> "Off"
                                } + if (chat.disappearingMode == mode) "  ✓" else ""
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismissDisappearing) { Text("Close") } }
        )
    }

    if (showWallpaperDialog) {
        AlertDialog(
            onDismissRequest = onDismissWallpaper,
            title = { Text("Chat Wallpaper") },
            text = {
                Column {
                    listOf("DEFAULT" to "WhatsApp Classic Doodle", "EMERALD_TINT" to "Emerald Green Calm", "MIDNIGHT" to "Midnight Dark").forEach { (key, label) ->
                        TextButton(
                            onClick = {
                                onSetWallpaper(key)
                                onDismissWallpaper()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(label + if (chat.wallpaperStyle == key) "  ✓" else "")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismissWallpaper) { Text("Close") } }
        )
    }

    if (viewOncePreviewMsg != null) {
        AlertDialog(
            onDismissRequest = onDismissViewOnce,
            icon = { Icon(Icons.Filled.VisibilityOff, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("View Once • Screenshot Protected") },
            text = {
                Column {
                    Text(viewOncePreviewMsg.text, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This message has now been marked as opened and cannot be viewed again.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = { TextButton(onClick = onDismissViewOnce) { Text("Close") } }
        )
    }

    if (forwardTargetMsg != null) {
        val targets = allChats.filter { it.id != chat.id }
        AlertDialog(
            onDismissRequest = onDismissForward,
            title = { Text("Forward message to...") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (targets.isEmpty()) {
                        Text("No other conversations available yet.")
                    } else {
                        targets.take(8).forEach { target ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onForwardTo(target.id, forwardTargetMsg)
                                        onDismissForward()
                                    }
                            ) {
                                Text(target.title, modifier = Modifier.padding(12.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismissForward) { Text("Cancel") } }
        )
    }

    if (editTargetMsg != null) {
        var editedText by remember(editTargetMsg.id) { mutableStateOf(editTargetMsg.text) }
        AlertDialog(
            onDismissRequest = onDismissEdit,
            title = { Text("Edit Message") },
            text = {
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    label = { Text("Message text") },
                    maxLines = 4
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (editedText.isNotBlank()) {
                        onConfirmEdit(editTargetMsg, editedText.trim())
                        onDismissEdit()
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onDismissEdit) { Text("Cancel") } }
        )
    }

    if (showSafetyNumberDialog) {
        AlertDialog(
            onDismissRequest = onDismissSafetyNumber,
            icon = { Icon(Icons.Filled.Security, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Verify Security Code") },
            text = {
                Text(
                    "To verify that messages and calls with ${chat.title} are end-to-end encrypted, compare these numbers on both devices:\n\n${chat.encryptionCode}"
                )
            },
            confirmButton = { TextButton(onClick = onDismissSafetyNumber) { Text("OK") } }
        )
    }

    if (biometricNotice != null) {
        AlertDialog(
            onDismissRequest = onDismissBiometricNotice,
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Chat Lock Authentication") },
            text = { Text(biometricNotice) },
            confirmButton = { TextButton(onClick = onDismissBiometricNotice) { Text("OK") } }
        )
    }
}
