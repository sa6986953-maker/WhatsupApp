package com.example.ui.screens.bluetooth

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.MeshStatus
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BluetoothMeshSheet(
    meshStatus: MeshStatus,
    onDismiss: () -> Unit,
    onToggleOfflineMode: (Boolean) -> Unit,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onTogglePeerConnect: (String) -> Unit,
    onCreateBluetoothGroup: (String) -> Unit
) {
    var btGroupName by remember { mutableStateOf("") }
    var permissionNotice by remember { mutableStateOf<String?>(null) }

    val requiredPermissions = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE,
                Manifest.permission.NEARBY_WIFI_DEVICES
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val allGranted = grants.values.all { it }
        if (allGranted) {
            permissionNotice = null
            onStartScan()
        } else {
            permissionNotice = "Bluetooth / Nearby permission denied. Grant permission in settings to scan hardware peers."
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(BluetoothBlue.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.BluetoothConnected,
                        contentDescription = "Offline Bluetooth Mesh",
                        tint = BluetoothBlue,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Whatsup Offline Bluetooth Mesh",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chat up to 100m via Bluetooth LE & Wi-Fi Direct without internet",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Mode & Radio Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (meshStatus.offlineModeActive) {
                        BluetoothBlue.copy(alpha = 0.12f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Offline Bluetooth Mode",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = meshStatus.statusBanner,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = meshStatus.offlineModeActive,
                            onCheckedChange = onToggleOfflineMode,
                            colors = SwitchDefaults.colors(checkedTrackColor = BluetoothBlue),
                            modifier = Modifier.testTag("offline_bluetooth_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Whatsup Service UUID: ${meshStatus.whatsupServiceUuid}",
                        style = MaterialTheme.typography.labelSmall,
                        color = BluetoothBlue,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.testTag("whatsup_ble_uuid_label")
                    )
                    if (meshStatus.autoTriggeredByBle) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Auto-triggered Offline Chat via nearby Whatsup BLE broadcast",
                            style = MaterialTheme.typography.labelSmall,
                            color = WhatsupGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatusChip(
                            icon = Icons.Filled.BluetoothSearching,
                            label = if (meshStatus.scanning) "UUID Scan ON" else if (meshStatus.bluetoothEnabled) "BLE Radio ON" else "BLE Standby",
                            tint = if (meshStatus.bluetoothEnabled) BluetoothBlue else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        StatusChip(
                            icon = Icons.Filled.WifiTethering,
                            label = if (meshStatus.wifiDirectReady) "Wi-Fi Direct Ready" else "Wi-Fi Direct N/A",
                            tint = if (meshStatus.wifiDirectReady) WhatsupGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        StatusChip(
                            icon = Icons.Filled.CloudSync,
                            label = "Queue: ${meshStatus.pendingSyncCount}",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { permissionLauncher.launch(requiredPermissions) },
                    colors = ButtonDefaults.buttonColors(containerColor = BluetoothBlue),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("scan_bluetooth_peers_button")
                ) {
                    Text(if (meshStatus.scanning) "Continuous Scan Active" else "Start Whatsup UUID Scan")
                }
                if (meshStatus.scanning) {
                    OutlinedButton(
                        onClick = onStopScan,
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text("Pause")
                    }
                }
            }

            if (permissionNotice != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = permissionNotice!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Nearby Whatsup Devices (${meshStatus.nearbyPeers.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            if (meshStatus.nearbyPeers.isEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (meshStatus.bluetoothEnabled) {
                            "Tap 'Scan Nearby Peers' to discover nearby Whatsup Bluetooth LE / Wi-Fi Direct devices within 100m."
                        } else {
                            "Enable Bluetooth on this device to discover nearby Whatsup peers, or create a Bluetooth Mesh Group below."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(meshStatus.nearbyPeers, key = { it.peerId }) { peer ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onTogglePeerConnect(peer.peerId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SignalCellularAlt,
                                    contentDescription = null,
                                    tint = BluetoothBlue
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(peer.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${peer.transport} • ~${peer.distanceMeters}m away",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = if (peer.connected) "Connected" else "Connect",
                                    color = if (peer.connected) WhatsupGreen else BluetoothBlue,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Create Offline Bluetooth Group (Classroom / Wedding / Village)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = btGroupName,
                    onValueChange = { btGroupName = it },
                    placeholder = { Text("e.g., Kahror Pakka Wedding Hall") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("bluetooth_group_name_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (btGroupName.isNotBlank()) {
                            onCreateBluetoothGroup(btGroupName.trim())
                            btGroupName = ""
                            onDismiss()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("create_bluetooth_group_button")
                ) {
                    Icon(Icons.Filled.Groups, contentDescription = "Create Group", tint = Color.White)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatusChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
