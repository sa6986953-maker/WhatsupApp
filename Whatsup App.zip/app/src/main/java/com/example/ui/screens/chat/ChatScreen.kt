package com.example.ui.screens.chat

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.R
import com.example.core.BiometricAuthHelper
import com.example.core.MeshStatus
import com.example.core.VoiceAudioManager
import com.example.core.VoicePlaybackState
import com.example.core.VoiceRecordingState
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.ui.components.ContactAvatar
import com.example.ui.components.EncryptionNoticeBanner
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkChatCanvas
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.LightChatCanvas
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.InlineSummaryState
import com.example.ui.viewmodel.SuggestedRepliesState
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chat: ChatThread,
    currentUserId: String,
    messagesState: UiState<List<ChatMessage>>,
    meshStatus: MeshStatus,
    recordingState: VoiceRecordingState,
    voicePlaybackState: VoicePlaybackState,
    darkMode: Boolean,
    hideBlueTicks: Boolean,
    hideOnline: Boolean,
    hideLastSeen: Boolean,
    isPeerBlocked: Boolean,
    allChats: List<ChatThread>,
    onBack: () -> Unit,
    onToggleBluetoothMode: (Boolean) -> Unit,
    onSyncBluetooth: () -> Unit,
    onTypingChanged: (Boolean) -> Unit,
    onSendMessage: (
        text: String,
        messageType: String,
        replyToText: String?,
        replyToSender: String?,
        mediaMeta: String?,
        scheduledMinutesDelay: Int?
    ) -> Unit,
    onSendUriAttachment: (uri: Uri, messageType: String, caption: String, viewOnce: Boolean) -> Unit,
    onStartVoiceRecording: () -> Boolean,
    onStopVoiceRecording: (discard: Boolean) -> Unit,
    onPlayVoiceMessage: (ChatMessage) -> Unit,
    onDownloadMedia: suspend (ChatMessage) -> Result<File>,
    onEditMessage: (ChatMessage, String) -> Unit,
    onForwardMessage: (targetChatId: String, msg: ChatMessage) -> Unit,
    onStarMessage: (ChatMessage) -> Unit,
    onToggleReaction: (ChatMessage, String) -> Unit,
    onDeleteForMe: (String) -> Unit,
    onDeleteForEveryone: (String) -> Unit,
    onOpenViewOnce: (String) -> Unit,
    onSetDisappearing: (String) -> Unit,
    onSetWallpaper: (String) -> Unit,
    onToggleChatLock: () -> Unit,
    onToggleBlockPeer: () -> Unit,
    onOpenAiAssistant: (ChatMessage?) -> Unit,
    inlineSummaryState: InlineSummaryState,
    suggestedRepliesState: SuggestedRepliesState,
    onSummarizeThread: () -> Unit,
    onDismissSummary: () -> Unit,
    onGenerateSuggestions: () -> Unit,
    onDismissSuggestions: () -> Unit,
    onOpenExportChat: () -> Unit,
    onStartVoiceCall: () -> Unit,
    onStartVideoCall: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var inputText by remember { mutableStateOf("") }
    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var editTargetMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    var showEmojiTray by remember { mutableStateOf(false) }
    var viewOnceEnabled by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showDisappearingDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }
    var showSafetyNumberDialog by remember { mutableStateOf(false) }
    var viewOncePreviewMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var forwardTargetMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var inChatSearchActive by remember(chat.id) { mutableStateOf(false) }
    var inChatSearchQuery by remember(chat.id) { mutableStateOf("") }
    var biometricNotice by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (inChatSearchActive) {
            inChatSearchActive = false
            inChatSearchQuery = ""
        } else {
            onBack()
        }
    }

    val listState = rememberLazyListState()
    val messages = (messagesState as? UiState.Success)?.data ?: emptyList()

    val visibleMessages = remember(messages, inChatSearchActive, inChatSearchQuery) {
        val nonDeleted = messages.filter { !it.deletedForMe }
        val q = inChatSearchQuery.trim()
        if (inChatSearchActive && q.isNotEmpty()) {
            nonDeleted.filter { msg ->
                msg.text.contains(q, ignoreCase = true) ||
                    msg.senderName.contains(q, ignoreCase = true) ||
                    (msg.mediaMeta?.contains(q, ignoreCase = true) == true)
            }
        } else {
            nonDeleted
        }
    }

    val lastReceivedMsgId = remember(messages) {
        messages.lastOrNull { !it.deletedForMe && !it.deletedForEveryone && !it.fromMe }?.id
    }
    var lastAutoSuggestedKey by remember(chat.id) { mutableStateOf<String?>(null) }
    val adminLocked = chat.onlyAdminCanSend && currentUserId !in chat.adminUids

    LaunchedEffect(chat.id, lastReceivedMsgId, meshStatus.networkOnline, adminLocked) {
        val targetId = lastReceivedMsgId
        if (targetId != null && !adminLocked && meshStatus.networkOnline) {
            val triggerKey = "${chat.id}:$targetId"
            if (lastAutoSuggestedKey != triggerKey) {
                lastAutoSuggestedKey = triggerKey
                onGenerateSuggestions()
            }
        }
    }

    LaunchedEffect(visibleMessages.size, inChatSearchQuery) {
        if (visibleMessages.isNotEmpty() && !inChatSearchActive) {
            listState.animateScrollToItem(visibleMessages.lastIndex)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (!onStartVoiceRecording()) {
                biometricNotice = "Unable to start microphone recorder on this device."
            }
        } else {
            biometricNotice = "Microphone permission is required to record voice notes."
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSendUriAttachment(uri, "IMAGE_HD", "Photo", viewOnceEnabled)
            viewOnceEnabled = false
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        cameraLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val topBarColor = if (darkMode) DarkTopBar else WhatsupDarkGreen
    val canvasBgColor = when {
        chat.wallpaperStyle == "MIDNIGHT" -> Color(0xFF0A1218)
        chat.wallpaperStyle == "EMERALD_TINT" -> Color(0xFFDCEEE2)
        darkMode -> DarkChatCanvas
        else -> LightChatCanvas
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(canvasBgColor)
            .navigationBarsPadding()
            .imePadding()
    ) {
        Surface(color = topBarColor, shadowElevation = 3.dp) {
            Column(modifier = Modifier.statusBarsPadding()) {
                if (inChatSearchActive) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                inChatSearchActive = false
                                inChatSearchQuery = ""
                            },
                            modifier = Modifier.testTag("chat_search_close_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search", tint = Color.White)
                        }
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = Color.White.copy(alpha = 0.14f),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                    if (inChatSearchQuery.isEmpty()) {
                                        Text(
                                            text = "Search messages...",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White.copy(alpha = 0.7f)
                                        )
                                    }
                                    BasicTextField(
                                        value = inChatSearchQuery,
                                        onValueChange = { inChatSearchQuery = it },
                                        singleLine = true,
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                                        cursorBrush = SolidColor(WhatsupGreen),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("chat_search_input")
                                    )
                                }
                                if (inChatSearchQuery.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = WhatsupGreen.copy(alpha = 0.28f),
                                        modifier = Modifier.padding(end = 4.dp)
                                    ) {
                                        Text(
                                            text = "${visibleMessages.size}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                .testTag("chat_search_match_count")
                                        )
                                    }
                                }
                            }
                        }
                        if (inChatSearchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { inChatSearchQuery = "" },
                                modifier = Modifier.testTag("chat_search_clear_button")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search query", tint = Color.White)
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("chat_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        ContactAvatar(
                            name = chat.title,
                            colorHex = chat.avatarColorHex,
                            chatType = chat.chatType,
                            online = chat.online && !hideOnline,
                            size = 38.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = chat.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                if (chat.locked) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = "Biometric Lock Active",
                                        tint = WhatsupGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            val subtitle = when {
                                recordingState.isRecording -> "recording audio..."
                                meshStatus.offlineModeActive -> "Offline Bluetooth Mesh (100m)"
                                chat.typing -> "typing..."
                                chat.online && !hideOnline -> "online"
                                hideLastSeen -> "End-to-End Encrypted"
                                else -> chat.lastSeenText
                            }
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (meshStatus.offlineModeActive) Color(0xFF8CD3FF) else Color.White.copy(alpha = 0.85f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        val tooltipState = rememberTooltipState(isPersistent = false)
                        val glowTransition = rememberInfiniteTransition(label = "offline_bt_glow")
                        val glowAlpha by glowTransition.animateFloat(
                            initialValue = 0.35f,
                            targetValue = 0.92f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "offline_bt_glow_alpha"
                        )
                        val glowRadiusFactor by glowTransition.animateFloat(
                            initialValue = 0.72f,
                            targetValue = 1.08f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "offline_bt_glow_radius"
                        )

                        AnimatedVisibility(
                            visible = meshStatus.offlineModeActive,
                            enter = fadeIn(tween(220)),
                            exit = fadeOut(tween(200))
                        ) {
                            TooltipBox(
                                positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
                                tooltip = {
                                    PlainTooltip(
                                        containerColor = Color(0xFF0E2942),
                                        contentColor = Color.White,
                                        modifier = Modifier.testTag("chat_p2p_tooltip")
                                    ) {
                                        Text(
                                            text = "Peer-to-peer • Offline Bluetooth Mode (100m)",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                },
                                state = tooltipState
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0xFF133A5E),
                                    border = BorderStroke(1.2.dp, Color(0xFF63D2FF).copy(alpha = glowAlpha)),
                                    modifier = Modifier
                                        .padding(end = 2.dp)
                                        .drawBehind {
                                            drawCircle(
                                                brush = Brush.radialGradient(
                                                    colors = listOf(
                                                        Color(0xFF53BDEB).copy(alpha = glowAlpha * 0.65f),
                                                        Color.Transparent
                                                    )
                                                ),
                                                radius = size.maxDimension * 0.78f * glowRadiusFactor
                                            )
                                        }
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable {
                                            scope.launch { tooltipState.show() }
                                        }
                                        .testTag("chat_offline_p2p_indicator")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF63D2FF).copy(alpha = glowAlpha))
                                        )
                                        Text(
                                            text = "P2P",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF9CE2FF),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        IconButton(
                            onClick = { onToggleBluetoothMode(!meshStatus.offlineModeActive) },
                            modifier = Modifier
                                .then(
                                    if (meshStatus.offlineModeActive) {
                                        Modifier.drawBehind {
                                            drawCircle(
                                                brush = Brush.radialGradient(
                                                    colors = listOf(
                                                        Color(0xFF53BDEB).copy(alpha = glowAlpha * 0.45f),
                                                        Color.Transparent
                                                    )
                                                ),
                                                radius = size.minDimension * 0.65f * glowRadiusFactor
                                            )
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                                .testTag("chat_bluetooth_toggle")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.BluetoothConnected,
                                contentDescription = "Toggle Bluetooth Offline Mode",
                                tint = if (meshStatus.offlineModeActive) Color(0xFF63D2FF) else Color.White.copy(alpha = 0.75f)
                            )
                        }
                        IconButton(
                            onClick = { inChatSearchActive = true },
                            modifier = Modifier.testTag("chat_search_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = "Search messages in chat", tint = Color.White)
                        }
                        IconButton(onClick = onStartVideoCall, modifier = Modifier.testTag("chat_video_call_button")) {
                            Icon(Icons.Filled.Videocam, contentDescription = "Video Call", tint = Color.White)
                        }
                        IconButton(onClick = onStartVoiceCall, modifier = Modifier.testTag("chat_voice_call_button")) {
                            Icon(Icons.Filled.Call, contentDescription = "Voice Call", tint = Color.White)
                        }

                        Box {
                            IconButton(onClick = { showMenu = true }, modifier = Modifier.testTag("chat_more_menu")) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = Color.White)
                            }
                            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Search messages") },
                                    onClick = { showMenu = false; inChatSearchActive = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Verify Security Code (E2EE)") },
                                    onClick = { showMenu = false; showSafetyNumberDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Whatsup AI Assistant") },
                                    onClick = { showMenu = false; onOpenAiAssistant(null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Whatsup AI Summary") },
                                    onClick = { showMenu = false; onSummarizeThread() }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (chat.locked) "Unlock chat (Biometric)" else "Lock chat (Biometric)") },
                                    onClick = {
                                        showMenu = false
                                        BiometricAuthHelper.authenticate(
                                            context = context,
                                            title = if (chat.locked) "Unlock ${chat.title}" else "Lock ${chat.title}",
                                            subtitle = "Verify with Fingerprint or Face Lock",
                                            onSuccess = onToggleChatLock,
                                            onError = { msg -> biometricNotice = msg },
                                            onUnavailableFallback = onToggleChatLock
                                        )
                                    },
                                    modifier = Modifier.testTag("chat_menu_lock_toggle")
                                )
                                if (chat.chatType == "DIRECT" && chat.peerUid.isNotBlank()) {
                                    DropdownMenuItem(
                                        text = { Text(if (isPeerBlocked) "Unblock ${chat.title}" else "Block ${chat.title}") },
                                        onClick = { showMenu = false; onToggleBlockPeer() }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("Sync Bluetooth Queue") },
                                    onClick = { showMenu = false; onSyncBluetooth() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Disappearing Messages (${chat.disappearingMode})") },
                                    onClick = { showMenu = false; showDisappearingDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Chat Wallpaper") },
                                    onClick = { showMenu = false; showWallpaperDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Schedule Message") },
                                    onClick = { showMenu = false; showScheduleDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Export Chat (JSON / TXT)") },
                                    onClick = { showMenu = false; onOpenExportChat() }
                                )
                            }
                        }
                    }
                }

                if (meshStatus.offlineModeActive || chat.disappearingMode != "OFF") {
                    Surface(
                        color = if (meshStatus.offlineModeActive) BluetoothBlue else Color.Black.copy(alpha = 0.25f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (meshStatus.offlineModeActive) {
                                    "📡 Offline Bluetooth Mesh Active (${meshStatus.pendingSyncCount} pending)"
                                } else {
                                    "⏱ Disappearing messages: ${chat.disappearingMode}"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                            if (meshStatus.offlineModeActive) {
                                Text(
                                    text = "Sync Now",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.clickable { onSyncBluetooth() }
                                )
                            }
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            if (!darkMode && chat.wallpaperStyle == "DEFAULT") {
                Image(
                    painter = painterResource(id = R.drawable.img_chat_wallpaper),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.55f,
                    modifier = Modifier.fillMaxSize()
                )
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!inChatSearchActive || inChatSearchQuery.isBlank()) {
                    item(key = "e2e_banner") {
                        Spacer(modifier = Modifier.height(6.dp))
                        EncryptionNoticeBanner(bluetoothMode = meshStatus.offlineModeActive)
                    }
                } else {
                    item(key = "search_results_header") {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                        ) {
                            Text(
                                text = if (visibleMessages.isEmpty()) {
                                    "No messages matching \"$inChatSearchQuery\""
                                } else {
                                    "${visibleMessages.size} matching message(s) for \"$inChatSearchQuery\""
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                items(
                    items = visibleMessages,
                    key = { it.id }
                ) { msg ->
                    ChatMessageBubble(
                        message = msg,
                        isGroup = chat.chatType != "DIRECT",
                        darkMode = darkMode,
                        hideBlueTicks = hideBlueTicks,
                        voicePlaybackState = voicePlaybackState,
                        highlightQuery = if (inChatSearchActive) inChatSearchQuery.trim() else "",
                        onReply = { replyTarget = msg },
                        onEdit = { editTargetMsg = msg },
                        onCopy = {
                            clipboard.setText(AnnotatedString(msg.text))
                            biometricNotice = null
                        },
                        onForward = { forwardTargetMsg = msg },
                        onTranslateWithAi = { onOpenAiAssistant(msg) },
                        onStar = { onStarMessage(msg) },
                        onReact = { emoji -> onToggleReaction(msg, emoji) },
                        onDeleteForMe = { onDeleteForMe(msg.id) },
                        onDeleteForEveryone = { onDeleteForEveryone(msg.id) },
                        onOpenViewOnce = {
                            if (!msg.viewOnceOpened) {
                                viewOncePreviewMsg = msg
                                onOpenViewOnce(msg.id)
                            }
                        },
                        onPlayVoice = { onPlayVoiceMessage(msg) },
                        onOpenAttachment = {
                            scope.launch {
                                onDownloadMedia(msg).onSuccess { file ->
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val ext = file.extension.lowercase()
                                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                                    val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, mime)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    runCatching { context.startActivity(viewIntent) }.onFailure {
                                        biometricNotice = "Saved decrypted file to cache: ${file.name}"
                                    }
                                }.onFailure { err ->
                                    biometricNotice = err.localizedMessage ?: "Failed to decrypt media."
                                }
                            }
                        }
                    )
                }
                item(key = "bottom_space") { Spacer(modifier = Modifier.height(8.dp)) }
            }
        }

        ChatAiAccessory(
            summaryState = inlineSummaryState,
            suggestionsState = suggestedRepliesState,
            onlyAdminCanSend = adminLocked,
            darkMode = darkMode,
            onSummarizeClick = onSummarizeThread,
            onDismissSummary = onDismissSummary,
            onSuggestRepliesClick = onGenerateSuggestions,
            onDismissSuggestions = onDismissSuggestions,
            onInsertSuggestedReply = { suggestion ->
                inputText = suggestion
                onTypingChanged(true)
            },
            onSendSuggestedReply = { suggestion ->
                val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "TEXT"
                onSendMessage(
                    suggestion,
                    msgType,
                    replyTarget?.text,
                    replyTarget?.senderName,
                    if (viewOnceEnabled) "View Once Text • Tap to reveal" else null,
                    null
                )
                replyTarget = null
                viewOnceEnabled = false
                onDismissSuggestions()
            },
            onOpenFullAiSheet = { onOpenAiAssistant(null) },
            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
        )

        if (replyTarget != null) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(34.dp)
                            .background(WhatsupGreen, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (replyTarget!!.fromMe) "Me" else replyTarget!!.senderName,
                            style = MaterialTheme.typography.labelMedium,
                            color = WhatsupGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = replyTarget!!.text,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { replyTarget = null }) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel reply")
                    }
                }
            }
        }

        if (recordingState.isRecording) {
            Surface(color = WhatsupDarkGreen, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = WhatsupGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recording Voice (${VoiceAudioManager.formatDuration(recordingState.elapsedSeconds)})...",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row {
                        TextButton(onClick = { onStopVoiceRecording(true) }) {
                            Text("Discard", color = Color.White.copy(alpha = 0.8f))
                        }
                        TextButton(onClick = { onStopVoiceRecording(false) }) {
                            Text("Send", color = WhatsupGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (showEmojiTray) {
            EmojiStickersGifTray(
                onPickEmoji = {
                    inputText += it
                    onTypingChanged(true)
                },
                onPickStickerOrGif = { text, type, meta ->
                    onSendMessage(text, type, replyTarget?.text, replyTarget?.senderName, meta, null)
                    replyTarget = null
                    showEmojiTray = false
                }
            )
        }

        when {
            isPeerBlocked -> {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("You blocked this contact.", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = onToggleBlockPeer) { Text("Unblock") }
                    }
                }
            }
            adminLocked -> {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Only Admins can send messages in this group",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            else -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Surface(
                        shape = RoundedCornerShape(26.dp),
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 2.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = { showEmojiTray = !showEmojiTray },
                                modifier = Modifier.testTag("chat_emoji_button")
                            ) {
                                Icon(
                                    Icons.Filled.EmojiEmotions,
                                    contentDescription = "Emoji, Stickers, GIFs",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (inputText.isEmpty()) {
                                    Text(
                                        text = if (meshStatus.offlineModeActive) "Message via Bluetooth..." else "Message",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                BasicTextField(
                                    value = inputText,
                                    onValueChange = {
                                        inputText = it
                                        onTypingChanged(it.isNotBlank())
                                    },
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                                        color = MaterialTheme.colorScheme.onSurface
                                    ),
                                    cursorBrush = SolidColor(WhatsupGreen),
                                    maxLines = 5,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("chat_message_input")
                                )
                            }

                            IconButton(
                                onClick = { showAttachSheet = true },
                                modifier = Modifier.testTag("chat_attach_button")
                            ) {
                                Icon(
                                    Icons.Filled.AttachFile,
                                    contentDescription = "Attach media or file",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (inputText.isBlank()) {
                                IconButton(
                                    onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                    modifier = Modifier.testTag("chat_camera_button")
                                ) {
                                    Icon(
                                        Icons.Filled.CameraAlt,
                                        contentDescription = "Camera",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Surface(
                        shape = CircleShape,
                        color = if (meshStatus.offlineModeActive) BluetoothBlue else WhatsupGreen,
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag(if (inputText.isNotBlank()) "chat_send_button" else "chat_mic_button")
                            .clickable {
                                if (inputText.isNotBlank()) {
                                    val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "TEXT"
                                    onSendMessage(
                                        inputText.trim(),
                                        msgType,
                                        replyTarget?.text,
                                        replyTarget?.senderName,
                                        if (viewOnceEnabled) "View Once Text • Tap to reveal" else null,
                                        null
                                    )
                                    inputText = ""
                                    replyTarget = null
                                    viewOnceEnabled = false
                                    onTypingChanged(false)
                                } else {
                                    if (recordingState.isRecording) {
                                        onStopVoiceRecording(false)
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                            }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (inputText.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                                contentDescription = if (inputText.isNotBlank()) "Send" else "Record Voice Note",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAttachSheet) {
        AttachMediaSheet(
            viewOnceEnabled = viewOnceEnabled,
            onToggleViewOnce = { viewOnceEnabled = !viewOnceEnabled },
            onSendUriAttachment = { uri, type, caption, viewOnce ->
                onSendUriAttachment(uri, type, caption, viewOnce)
                replyTarget = null
                viewOnceEnabled = false
            },
            onSendMediaMessage = { text, type, meta ->
                onSendMessage(text, type, replyTarget?.text, replyTarget?.senderName, meta, null)
                replyTarget = null
                viewOnceEnabled = false
            },
            onOpenScheduleDialog = { showScheduleDialog = true },
            onDismiss = { showAttachSheet = false }
        )
    }

    ChatDialogsHost(
        chat = chat,
        allChats = allChats,
        initialInputText = inputText,
        showScheduleDialog = showScheduleDialog,
        onDismissSchedule = { showScheduleDialog = false },
        onScheduleSend = { text, mins ->
            onSendMessage("⏰ [Scheduled +${mins}m] $text", "TEXT", null, null, "Scheduled message", mins)
            inputText = ""
        },
        showDisappearingDialog = showDisappearingDialog,
        onDismissDisappearing = { showDisappearingDialog = false },
        onSetDisappearing = onSetDisappearing,
        showWallpaperDialog = showWallpaperDialog,
        onDismissWallpaper = { showWallpaperDialog = false },
        onSetWallpaper = onSetWallpaper,
        viewOncePreviewMsg = viewOncePreviewMsg,
        onDismissViewOnce = { viewOncePreviewMsg = null },
        forwardTargetMsg = forwardTargetMsg,
        onDismissForward = { forwardTargetMsg = null },
        onForwardTo = { targetId, msg -> onForwardMessage(targetId, msg) },
        editTargetMsg = editTargetMsg,
        onDismissEdit = { editTargetMsg = null },
        onConfirmEdit = onEditMessage,
        showSafetyNumberDialog = showSafetyNumberDialog,
        onDismissSafetyNumber = { showSafetyNumberDialog = false },
        biometricNotice = biometricNotice,
        onDismissBiometricNotice = { biometricNotice = null }
    )
}
