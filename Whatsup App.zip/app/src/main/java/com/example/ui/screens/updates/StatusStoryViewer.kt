package com.example.ui.screens.updates

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.StatusUpdate
import com.example.data.model.StatusViewer
import com.example.ui.theme.WhatsupGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@Composable
fun StatusStoryViewer(
    stories: List<StatusUpdate>,
    initialIndex: Int,
    currentUserId: String,
    onMarkViewed: (StatusUpdate) -> Unit,
    onObserveViewers: (String) -> Flow<List<StatusViewer>>,
    onDeleteStatus: (String) -> Unit,
    onReplyToStatus: (StatusUpdate, String) -> Unit,
    onDismiss: () -> Unit
) {
    if (stories.isEmpty()) return

    var currentIndex by remember(stories) {
        mutableIntStateOf(initialIndex.coerceIn(0, stories.lastIndex))
    }
    var visible by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var showViewersList by remember { mutableStateOf(false) }
    var replyText by remember { mutableStateOf("") }
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val activeStory = stories[currentIndex]
    val isMine = activeStory.userId == currentUserId
    val viewers by remember(activeStory.id, isMine) {
        onObserveViewers(activeStory.id)
    }.collectAsStateWithLifecycle(initialValue = emptyList())

    fun closeWithFadeOut() {
        scope.launch {
            visible = false
            delay(220)
            onDismiss()
        }
    }

    fun goNext() {
        if (currentIndex < stories.lastIndex) {
            currentIndex += 1
        } else {
            closeWithFadeOut()
        }
    }

    fun goPrevious() {
        if (currentIndex > 0) {
            currentIndex -= 1
        } else {
            scope.launch { progress.snapTo(0f) }
        }
    }

    LaunchedEffect(Unit) { visible = true }

    LaunchedEffect(currentIndex) {
        onMarkViewed(stories[currentIndex])
        progress.snapTo(0f)
    }

    LaunchedEffect(currentIndex, isPaused, visible, showViewersList, replyText.isNotEmpty()) {
        if (!visible || isPaused || showViewersList || replyText.isNotEmpty()) return@LaunchedEffect
        val remainingFraction = (1f - progress.value).coerceIn(0f, 1f)
        val durationMs = (5000f * remainingFraction).toInt().coerceAtLeast(100)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = durationMs, easing = LinearEasing)
        )
        if (!isPaused && visible && progress.value >= 0.99f) {
            goNext()
        }
    }

    Dialog(
        onDismissRequest = { closeWithFadeOut() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BackHandler { closeWithFadeOut() }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(240)) + scaleIn(initialScale = 0.95f, animationSpec = tween(260, easing = FastOutSlowInEasing)),
            exit = fadeOut(tween(220))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .imePadding()
                    .pointerInput(currentIndex, stories.size) {
                        var dragDelta = 0f
                        detectHorizontalDragGestures(
                            onDragStart = {
                                dragDelta = 0f
                                isPaused = true
                            },
                            onDragEnd = {
                                isPaused = false
                                if (dragDelta < -90f) goNext() else if (dragDelta > 90f) goPrevious()
                            },
                            onDragCancel = { isPaused = false },
                            onHorizontalDrag = { _, amount -> dragDelta += amount }
                        )
                    }
                    .pointerInput(currentIndex, stories.size) {
                        detectTapGestures(
                            onPress = {
                                isPaused = true
                                tryAwaitRelease()
                                isPaused = false
                            },
                            onTap = { offset ->
                                if (offset.x < size.width * 0.35f) goPrevious() else goNext()
                            }
                        )
                    }
            ) {
                AnimatedContent(
                    targetState = currentIndex,
                    transitionSpec = {
                        val movingForward = targetState >= initialState
                        val enterAnim = slideInHorizontally(
                            animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
                            initialOffsetX = { fullWidth -> if (movingForward) fullWidth else -fullWidth }
                        ) + fadeIn(animationSpec = tween(durationMillis = 280))

                        val exitAnim = slideOutHorizontally(
                            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                            targetOffsetX = { fullWidth -> if (movingForward) -fullWidth / 3 else fullWidth / 3 }
                        ) + fadeOut(animationSpec = tween(durationMillis = 250))

                        enterAnim togetherWith exitAnim
                    },
                    label = "status_story_transition",
                    modifier = Modifier.fillMaxSize()
                ) { index ->
                    val story = stories[index]
                    val baseColor = Color(story.bgColorHex)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(baseColor.copy(alpha = 0.95f), baseColor, Color(0xFF0A1419))
                                )
                            )
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Spacer(modifier = Modifier.height(78.dp))

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    if (story.mediaUrl.isNotBlank() && story.statusType == "PHOTO") {
                                        AsyncImage(
                                            model = story.mediaUrl,
                                            contentDescription = story.caption,
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(max = 360.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                        Spacer(modifier = Modifier.height(14.dp))
                                    }
                                    Text(
                                        text = story.caption,
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.testTag("story_caption_text")
                                    )
                                }
                            }

                            if (isMine) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showViewersList = true }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Visibility, contentDescription = "Views", tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Viewed by ${viewers.size} • Tap to view list",
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = replyText,
                                        onValueChange = { replyText = it },
                                        placeholder = { Text("Reply to ${story.authorName}...", color = Color.White.copy(alpha = 0.7f)) },
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White,
                                            focusedBorderColor = WhatsupGreen,
                                            unfocusedBorderColor = Color.White.copy(alpha = 0.5f)
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = {
                                            if (replyText.isNotBlank()) {
                                                onReplyToStatus(story, replyText)
                                                replyText = ""
                                            }
                                        },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .background(WhatsupGreen)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Reply", tint = Color.White)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        stories.forEachIndexed { idx, _ ->
                            val fill = when {
                                idx < currentIndex -> 1f
                                idx == currentIndex -> progress.value
                                else -> 0f
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color.White.copy(alpha = 0.32f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fill)
                                        .background(Color.White)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color.White, CircleShape)
                                .background(Color.Black.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = activeStory.authorName.ifBlank { "W" }.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeStory.authorName,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("story_author_name")
                            )
                            Text(
                                text = "${activeStory.timeLabel} • ${currentIndex + 1} of ${stories.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        if (isMine) {
                            IconButton(onClick = { onDeleteStatus(activeStory.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete Status", tint = Color.White)
                            }
                        }
                        IconButton(
                            onClick = { goPrevious() },
                            enabled = currentIndex > 0,
                            modifier = Modifier.testTag("story_prev_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "Previous Status",
                                tint = if (currentIndex > 0) Color.White else Color.White.copy(alpha = 0.35f)
                            )
                        }
                        IconButton(
                            onClick = { goNext() },
                            modifier = Modifier.testTag("story_next_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Next Status",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = { closeWithFadeOut() },
                            modifier = Modifier.testTag("story_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close Status",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }

    if (showViewersList) {
        AlertDialog(
            onDismissRequest = { showViewersList = false },
            title = { Text("Viewed by (${viewers.size})") },
            text = {
                if (viewers.isEmpty()) {
                    Text("No one has viewed this status yet.")
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                        items(viewers, key = { it.viewerUid }) { v ->
                            Text(v.viewerName, modifier = Modifier.padding(vertical = 6.dp), fontWeight = FontWeight.Medium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showViewersList = false }) { Text("Close") }
            }
        )
    }
}
