package com.example.ui.screens.settings

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.ChatHistoryExporter
import com.example.core.ExportFormat
import com.example.core.ExportedChatFile
import com.example.core.LocalAppPreferences
import com.example.core.NotificationSoundCategory
import com.example.core.PhoneNumberUtils
import com.example.core.crypto.WhatsupCryptoManager
import com.example.data.model.BlockedUser
import com.example.data.model.ChatThread
import com.example.data.model.PrivacyAudience
import com.example.data.model.UserProfile
import com.example.ui.components.ThemeModeSettingsRow
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.MissedCallRed
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.ExportUiState
import java.io.File

@Composable
fun SettingsScreen(
    currentUserId: String,
    profile: UserProfile?,
    localPrefs: LocalAppPreferences,
    allChats: List<ChatThread>,
    blockedUsers: List<BlockedUser>,
    mediaCacheBytes: Long,
    exportState: ExportUiState,
    exportedFiles: List<ExportedChatFile>,
    isGoogleLinked: Boolean = false,
    linkedEmail: String? = null,
    isAuthLoading: Boolean = false,
    authErrorMessage: String? = null,
    onBack: () -> Unit,
    onSelectThemeMode: (AppThemeMode) -> Unit,
    onUpdatePrivacySettings: (Map<String, Any>) -> Unit,
    onUploadAvatar: (Uri) -> Unit,
    onSetAppLock: (enabled: Boolean, pin: String) -> Unit,
    onSetTwoStepPin: (pin: String, currentPin: String?, recoveryHint: String) -> Unit,
    onDisableTwoStepPin: (currentPin: String) -> Unit,
    onUpdateOptionalPhone: (newPhoneE164: String) -> Unit,
    onUnblockUser: (String) -> Unit,
    onClearMediaCache: () -> Unit,
    onSaveTurnConfig: (url: String, username: String, credential: String) -> Unit,
    onOpenBluetoothMesh: () -> Unit,
    onSelectNotificationSound: (category: NotificationSoundCategory, uri: String, displayName: String) -> Unit,
    onRefreshExports: () -> Unit,
    onExportChatHistory: (chatId: String?, format: ExportFormat) -> Unit,
    onDeleteExportFile: (ExportedChatFile) -> Unit,
    onResetExportState: () -> Unit,
    onConnectGoogleAccount: () -> Unit = {},
    onSignOut: () -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showOptionalPhoneDialog by remember { mutableStateOf(false) }
    var showVerificationStatusDialog by remember { mutableStateOf(false) }
    var showSignOutConfirmDialog by remember { mutableStateOf(false) }
    var showTwoStepDialog by remember { mutableStateOf(false) }
    var showBlockedUsersDialog by remember { mutableStateOf(false) }
    var showSecurityCodeDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showTurnDialog by remember { mutableStateOf(false) }
    var pendingSoundCategory by remember { mutableStateOf<NotificationSoundCategory?>(null) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onUploadAvatar(uri)
    }

    val audioDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        val category = pendingSoundCategory
        pendingSoundCategory = null
        if (uri != null && category != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            val title = resolveAudioTitle(context, uri)
            onSelectNotificationSound(category, uri.toString(), title)
        }
    }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val category = pendingSoundCategory
        pendingSoundCategory = null
        if (result.resultCode == Activity.RESULT_OK && category != null) {
            val data = result.data
            val pickedUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (pickedUri != null) {
                val title = resolveAudioTitle(context, pickedUri)
                onSelectNotificationSound(category, pickedUri.toString(), title)
            } else {
                onSelectNotificationSound(category, "", "Silent")
            }
        }
    }

    fun launchNotificationSoundPicker(category: NotificationSoundCategory, existingUri: String) {
        pendingSoundCategory = category
        val ringtoneIntent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select ${category.title} Sound")
            if (existingUri.isNotBlank()) {
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existingUri))
            } else {
                putExtra(
                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                )
            }
        }
        if (ringtoneIntent.resolveActivity(context.packageManager) != null) {
            ringtonePickerLauncher.launch(ringtoneIntent)
        } else {
            audioDocumentLauncher.launch(arrayOf("audio/*"))
        }
    }

    val activeEmail = profile?.email?.takeIf { it.isNotBlank() }
        ?: linkedEmail?.takeIf { it.isNotBlank() }
        ?: localPrefs.verifiedEmail
    val activePhone = profile?.phoneE164?.takeIf { it.isNotBlank() }
        ?: localPrefs.verifiedPhoneNumber

    val isDarkTheme = LocalIsDarkTheme.current
    val localPhotoFile = remember(localPrefs.localProfilePhotoPath) {
        localPrefs.localProfilePhotoPath.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        Surface(
            color = if (isDarkTheme) DarkTopBar else WhatsupDarkGreen,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(60.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Settings", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Verified Account Profile Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(WhatsupGreen)
                                .clickable {
                                    avatarPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("settings_avatar_picker"),
                            contentAlignment = Alignment.Center
                        ) {
                            val avatarModel: Any? = localPhotoFile ?: profile?.photoUrl?.takeIf { it.isNotBlank() }
                            if (avatarModel != null) {
                                AsyncImage(
                                    model = avatarModel,
                                    contentDescription = "Profile photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = (profile?.displayName ?: "W").take(1).uppercase(),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(WhatsupDarkGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.CameraAlt, contentDescription = "Change Photo", tint = Color.White, modifier = Modifier.size(13.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile?.displayName?.ifBlank { "Whatsup User" } ?: "Whatsup User",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.VerifiedUser,
                                    contentDescription = "Verified Gmail",
                                    tint = WhatsupGreen,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = activeEmail.ifBlank { "Verified Gmail Account" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WhatsupGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (activePhone.isNotBlank()) {
                                Text(
                                    text = PhoneNumberUtils.formatDisplay(activePhone),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = profile?.about ?: "Hey there! I am using Whatsup.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = { showEditProfileDialog = true },
                            modifier = Modifier.testTag("settings_edit_profile_button")
                        ) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit Profile", tint = WhatsupGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { showOptionalPhoneDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("settings_optional_phone_button")
                    ) {
                        Icon(Icons.Filled.PhoneAndroid, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (activePhone.isBlank()) "Add Optional Phone Number" else "Update Optional Phone Number"
                        )
                    }
                }
            }

            SectionHeader("Account Security & Verification")
            SettingActionRow(
                icon = Icons.Filled.VerifiedUser,
                title = "Account Verification Status",
                subtitle = if (activeEmail.isNotBlank()) {
                    "Verified Gmail • $activeEmail"
                } else {
                    "Verified session • Tap to inspect status"
                },
                tint = WhatsupGreen,
                testTag = "settings_verification_status_row",
                onClick = { showVerificationStatusDialog = true }
            )
            SettingActionRow(
                icon = Icons.Filled.Key,
                title = "Two-Step Verification (Server PIN)",
                subtitle = if (profile?.twoStepEnabled == true) {
                    "Enabled • Salted scrypt PIN enforced on new logins"
                } else {
                    "Disabled • Add a 6-digit backup PIN"
                },
                tint = WhatsupGreen,
                testTag = "settings_two_step_row",
                onClick = { showTwoStepDialog = true }
            )
            SettingSwitchRow(
                icon = Icons.Filled.Fingerprint,
                title = "App Lock (Fingerprint / PIN)",
                subtitle = if (localPrefs.appLockEnabled) {
                    "Enabled • Biometrics + PIN required at launch"
                } else {
                    "Require Fingerprint / PIN to open Whatsup"
                },
                checked = localPrefs.appLockEnabled,
                onCheckedChange = { enabled ->
                    if (enabled) showPinDialog = true else onSetAppLock(false, localPrefs.appLockPin)
                }
            )
            SettingActionRow(
                icon = Icons.Filled.Security,
                title = "End-to-End Encryption Identity",
                subtitle = "View your local EC P-256 public identity & safety digest",
                onClick = { showSecurityCodeDialog = true }
            )

            HorizontalDivider()
            SectionHeader("Privacy Controls")
            PrivacyAudienceRow(
                title = "Last Seen",
                currentValue = profile?.lastSeenPrivacy,
                onSelect = { onUpdatePrivacySettings(mapOf("lastSeenPrivacy" to it.value)) }
            )
            PrivacyAudienceRow(
                title = "Online Status",
                currentValue = profile?.onlinePrivacy,
                onSelect = { onUpdatePrivacySettings(mapOf("onlinePrivacy" to it.value)) }
            )
            PrivacyAudienceRow(
                title = "Profile Photo",
                currentValue = profile?.photoPrivacy,
                onSelect = { onUpdatePrivacySettings(mapOf("photoPrivacy" to it.value)) }
            )
            PrivacyAudienceRow(
                title = "About",
                currentValue = profile?.aboutPrivacy,
                onSelect = { onUpdatePrivacySettings(mapOf("aboutPrivacy" to it.value)) }
            )
            SettingSwitchRow(
                icon = Icons.Filled.VisibilityOff,
                title = "Read Receipts",
                subtitle = "If turned off, you won't send or see blue double ticks",
                checked = !(profile?.hideBlueTicks ?: false),
                testTag = "privacy_read_receipts_switch",
                onCheckedChange = { enabled ->
                    onUpdatePrivacySettings(mapOf("hideBlueTicks" to !enabled))
                }
            )
            SettingActionRow(
                icon = Icons.Filled.Block,
                title = "Blocked Contacts",
                subtitle = "${blockedUsers.size} blocked contact(s)",
                tint = MissedCallRed,
                testTag = "settings_blocked_users_row",
                onClick = { showBlockedUsersDialog = true }
            )

            HorizontalDivider()
            SectionHeader("Storage, Network & Calls")
            SettingActionRow(
                icon = Icons.Filled.BluetoothConnected,
                title = "Offline Bluetooth & Wi-Fi Direct Mesh",
                subtitle = "Manage 100m offline peer discovery & outbox auto-sync",
                tint = BluetoothBlue,
                onClick = onOpenBluetoothMesh
            )
            SettingSwitchRow(
                icon = Icons.Filled.DataSaverOn,
                title = "Low Data Mode",
                subtitle = "Reduce call bitrate & media bandwidth on slow networks",
                checked = profile?.dataSaver ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("dataSaver" to it)) }
            )
            SettingActionRow(
                icon = Icons.Filled.CleaningServices,
                title = "Clear Decrypted Media Cache",
                subtitle = "Currently using ${mediaCacheBytes / 1024L} KB in local cache",
                testTag = "settings_clear_cache_row",
                onClick = onClearMediaCache
            )
            SettingActionRow(
                icon = Icons.Filled.Router,
                title = "WebRTC TURN Server (NAT Traversal)",
                subtitle = if (localPrefs.turnServerUrl.isBlank()) {
                    "Using public STUN only • Tap to configure custom TURN relay"
                } else {
                    "Configured: ${localPrefs.turnServerUrl}"
                },
                testTag = "settings_turn_config_row",
                onClick = { showTurnDialog = true }
            )

            HorizontalDivider()
            SectionHeader("Chats & Appearance")
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.DarkMode,
                        contentDescription = null,
                        tint = WhatsupGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "App Theme",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = when (localPrefs.themeMode) {
                                AppThemeMode.SYSTEM -> "Follows your device system setting"
                                AppThemeMode.LIGHT -> "Always use Whatsup Light theme"
                                AppThemeMode.DARK -> "Always use Whatsup Dark theme"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                ThemeModeSettingsRow(
                    selectedMode = localPrefs.themeMode,
                    onSelectMode = onSelectThemeMode
                )
            }
            SettingActionRow(
                icon = Icons.Filled.Download,
                title = "Export Chat History (JSON / TXT)",
                subtitle = "Save conversations to local Documents folder",
                tint = WhatsupGreen,
                testTag = "settings_export_chat_history",
                onClick = {
                    onResetExportState()
                    showExportDialog = true
                }
            )

            HorizontalDivider()
            SectionHeader("Notification Sounds")
            SettingActionRow(
                icon = Icons.Filled.Notifications,
                title = "Standard Messages Sound",
                subtitle = localPrefs.standardSoundName,
                tint = WhatsupGreen,
                testTag = "setting_sound_standard",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.STANDARD,
                        existingUri = localPrefs.standardSoundUri
                    )
                }
            )
            SettingActionRow(
                icon = Icons.Filled.NotificationsActive,
                title = "Urgent Messages Sound",
                subtitle = localPrefs.urgentSoundName,
                tint = MissedCallRed,
                testTag = "setting_sound_urgent",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.URGENT,
                        existingUri = localPrefs.urgentSoundUri
                    )
                }
            )
            SettingActionRow(
                icon = Icons.Filled.AlternateEmail,
                title = "Group Mentions Sound",
                subtitle = localPrefs.mentionSoundName,
                tint = BluetoothBlue,
                testTag = "setting_sound_mention",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.GROUP_MENTION,
                        existingUri = localPrefs.mentionSoundUri
                    )
                }
            )

            HorizontalDivider()
            SectionHeader("Backup & Account")
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Backup, contentDescription = null, tint = WhatsupGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isGoogleLinked) "Google Account Linked" else "Link Google Account (Optional)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (isGoogleLinked) {
                            "Linked email: ${linkedEmail ?: activeEmail}"
                        } else {
                            "Your Whatsup account is verified via Gmail OTP ($activeEmail). Optionally link Google One-Tap for quick backup recovery."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!authErrorMessage.isNullOrBlank()) {
                        Text(
                            text = authErrorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (!isGoogleLinked) {
                        OutlinedButton(
                            onClick = onConnectGoogleAccount,
                            enabled = !isAuthLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("settings_google_link_button")
                        ) {
                            Text(if (isAuthLoading) "Linking Google..." else "Link Google Account (Optional)")
                        }
                    }

                    Button(
                        onClick = { showSignOutConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MissedCallRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("settings_sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Log Out", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showEditProfileDialog) {
        var nameInput by remember { mutableStateOf(profile?.displayName ?: "") }
        var aboutInput by remember { mutableStateOf(profile?.about ?: "Hey there! I am using Whatsup.") }
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it.take(60) },
                        label = { Text("Display Name") },
                        singleLine = true,
                        modifier = Modifier.testTag("edit_profile_name_input")
                    )
                    OutlinedTextField(
                        value = aboutInput,
                        onValueChange = { aboutInput = it.take(160) },
                        label = { Text("About") },
                        maxLines = 3,
                        modifier = Modifier.testTag("edit_profile_about_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (nameInput.isNotBlank()) {
                            onUpdatePrivacySettings(
                                mapOf(
                                    "displayName" to nameInput.trim(),
                                    "about" to aboutInput.trim().ifBlank { "Hey there! I am using Whatsup." }
                                )
                            )
                            showEditProfileDialog = false
                        }
                    },
                    modifier = Modifier.testTag("edit_profile_save_button")
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showVerificationStatusDialog) {
        AlertDialog(
            onDismissRequest = { showVerificationStatusDialog = false },
            icon = { Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Account Verification Status") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Gmail OTP Verification: ${if (profile?.emailVerified != false) "Verified ✓" else "Pending"}",
                        fontWeight = FontWeight.Bold,
                        color = WhatsupGreen
                    )
                    Text("Verified Gmail: ${activeEmail.ifBlank { "Unavailable" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Account UID: $currentUserId", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "Two-Step PIN: ${if (profile?.twoStepEnabled == true) "Enabled (Server-Hashed scrypt)" else "Not enabled"}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "End-to-End Encryption: Active (EC P-256 + AES-256-GCM)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showVerificationStatusDialog = false }) { Text("Close") }
            }
        )
    }

    if (showSignOutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showSignOutConfirmDialog = false },
            icon = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = MissedCallRed) },
            title = { Text("Log Out of Whatsup?") },
            text = {
                Text(
                    "You will need to verify a fresh 6-digit OTP sent to ${activeEmail.ifBlank { "your Gmail" }} to sign back in."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSignOutConfirmDialog = false
                        onSignOut()
                    },
                    modifier = Modifier.testTag("settings_confirm_sign_out_button")
                ) { Text("Log Out", color = MissedCallRed, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showSignOutConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showOptionalPhoneDialog) {
        var selectedCountry by remember { mutableStateOf(PhoneNumberUtils.defaultCountry) }
        var showCountryDropdown by remember { mutableStateOf(false) }
        var newPhoneInput by remember { mutableStateOf(activePhone) }
        var dialogError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showOptionalPhoneDialog = false },
            title = { Text("Optional Phone Number") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Your account signs in with Gmail OTP. Optionally add a mobile number so friends can also discover you by phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Box {
                        OutlinedButton(
                            onClick = { showCountryDropdown = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${selectedCountry.flagEmoji} ${selectedCountry.name} (${selectedCountry.dialCode})")
                        }
                        DropdownMenu(
                            expanded = showCountryDropdown,
                            onDismissRequest = { showCountryDropdown = false }
                        ) {
                            PhoneNumberUtils.supportedCountries.forEach { country ->
                                DropdownMenuItem(
                                    text = { Text("${country.flagEmoji} ${country.name} (${country.dialCode})") },
                                    onClick = {
                                        selectedCountry = country
                                        showCountryDropdown = false
                                    }
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = newPhoneInput,
                        onValueChange = {
                            newPhoneInput = it.filter { c -> c.isDigit() || c == ' ' || c == '+' }.take(18)
                            dialogError = null
                        },
                        label = { Text("Mobile Number (${selectedCountry.dialCode}) or leave blank") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    if (dialogError != null) {
                        Text(dialogError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPhoneInput.isBlank()) {
                            onUpdateOptionalPhone("")
                            showOptionalPhoneDialog = false
                            return@TextButton
                        }
                        val normalized = PhoneNumberUtils.normalizeToE164(
                            rawInput = newPhoneInput,
                            defaultRegionIso = selectedCountry.isoCode,
                            dialCodePrefix = selectedCountry.dialCode
                        )
                        if (normalized == null) {
                            dialogError = "Enter a valid mobile number for ${selectedCountry.name}, or leave blank to remove."
                            return@TextButton
                        }
                        onUpdateOptionalPhone(normalized)
                        showOptionalPhoneDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOptionalPhoneDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showTwoStepDialog) {
        val enabled = profile?.twoStepEnabled == true
        var currentPin by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }
        var hint by remember { mutableStateOf("") }
        var disabling by remember { mutableStateOf(false) }
        var pinErr by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showTwoStepDialog = false },
            title = { Text("Two-Step Verification") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (enabled) {
                            "Change or disable your server-hashed 6-digit PIN."
                        } else {
                            "Create a 6-digit PIN required when registering this number on another device."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (enabled) {
                        OutlinedTextField(
                            value = currentPin,
                            onValueChange = { currentPin = it.filter { c -> c.isDigit() }.take(6); pinErr = null },
                            label = { Text("Current 6-digit PIN") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { disabling = !disabling }) {
                                Text(if (disabling) "Switch to Change PIN" else "Disable Two-Step")
                            }
                        }
                    }
                    if (!disabling) {
                        OutlinedTextField(
                            value = newPin,
                            onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(6); pinErr = null },
                            label = { Text(if (enabled) "New 6-digit PIN" else "6-digit PIN") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = confirmPin,
                            onValueChange = { confirmPin = it.filter { c -> c.isDigit() }.take(6); pinErr = null },
                            label = { Text("Confirm 6-digit PIN") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = hint,
                            onValueChange = { hint = it.take(100) },
                            label = { Text("Recovery Hint / Word (Optional)") },
                            singleLine = true
                        )
                    }
                    if (pinErr != null) {
                        Text(pinErr!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (enabled && currentPin.length != 6) {
                        pinErr = "Enter your current 6-digit PIN."
                        return@TextButton
                    }
                    if (disabling) {
                        onDisableTwoStepPin(currentPin)
                        showTwoStepDialog = false
                    } else {
                        if (newPin.length != 6 || newPin != confirmPin) {
                            pinErr = "New 6-digit PINs must match."
                            return@TextButton
                        }
                        onSetTwoStepPin(newPin, currentPin.takeIf { enabled }, hint)
                        showTwoStepDialog = false
                    }
                }) { Text(if (disabling) "Disable" else "Save PIN") }
            },
            dismissButton = {
                TextButton(onClick = { showTwoStepDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showBlockedUsersDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedUsersDialog = false },
            title = { Text("Blocked Contacts") },
            text = {
                if (blockedUsers.isEmpty()) {
                    Text("You haven't blocked any contacts.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        blockedUsers.forEach { blocked ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(blocked.displayName.ifBlank { "Whatsup User" }, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        blocked.phoneE164,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(onClick = { onUnblockUser(blocked.blockedUid) }) {
                                    Text("Unblock", color = WhatsupGreen)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedUsersDialog = false }) { Text("Close") }
            }
        )
    }

    if (showSecurityCodeDialog) {
        val localPubDigest = remember(currentUserId) {
            val crypto = WhatsupCryptoManager(context.applicationContext)
            val pub = crypto.getPublicKeyBase64(currentUserId)
            WhatsupCryptoManager.computeSafetyNumber(pub, pub)
        }
        AlertDialog(
            onDismissRequest = { showSecurityCodeDialog = false },
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("End-to-End Encryption Identity") },
            text = {
                Text(
                    "Device EC P-256 Identity Digest:\n\n$localPubDigest\n\nEvery 1-to-1 chat derives a dedicated ECDH + HKDF-SHA256 + AES-256-GCM key, and every group wraps a per-group AES-256 key. Tap 'Verify Security Code' inside any chat to compare pairwise safety numbers."
                )
            },
            confirmButton = {
                TextButton(onClick = { showSecurityCodeDialog = false }) { Text("OK") }
            }
        )
    }

    if (showPinDialog) {
        var pin by remember { mutableStateOf(localPrefs.appLockPin) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Set App Lock PIN") },
            text = {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6) },
                    label = { Text("4-6 digit PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pin.length >= 4) {
                        onSetAppLock(true, pin)
                        showPinDialog = false
                    }
                }) { Text("Enable Lock") }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showTurnDialog) {
        var url by remember { mutableStateOf(localPrefs.turnServerUrl) }
        var user by remember { mutableStateOf(localPrefs.turnUsername) }
        var cred by remember { mutableStateOf(localPrefs.turnCredential) }
        AlertDialog(
            onDismissRequest = { showTurnDialog = false },
            title = { Text("WebRTC TURN Server") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Add your coturn / metered.ca / Twilio TURN relay URI so P2P calls succeed behind strict symmetric NATs.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("turn:host:3478") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        label = { Text("TURN Username") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = cred,
                        onValueChange = { cred = it },
                        label = { Text("TURN Credential") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onSaveTurnConfig(url, user, cred)
                    showTurnDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showTurnDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showExportDialog) {
        val docsPath = remember(context) {
            ChatHistoryExporter.getLocalDocumentsDir(context).absolutePath
        }
        ExportChatHistoryDialog(
            chats = allChats,
            initialChatId = null,
            exportState = exportState,
            exportedFiles = exportedFiles,
            localDocumentsPath = docsPath,
            onRefreshExports = onRefreshExports,
            onExport = onExportChatHistory,
            onDeleteExport = onDeleteExportFile,
            onDismiss = {
                onResetExportState()
                showExportDialog = false
            }
        )
    }
}

@Composable
private fun PrivacyAudienceRow(
    title: String,
    currentValue: String?,
    onSelect: (PrivacyAudience) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = PrivacyAudience.from(currentValue)
    Box {
        SettingActionRow(
            icon = Icons.Filled.Visibility,
            title = title,
            subtitle = selected.label,
            onClick = { expanded = true }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            PrivacyAudience.entries.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.label) },
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = WhatsupGreen,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String? = null,
    onRowClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onRowClick?.invoke() ?: onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = WhatsupGreen),
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    testTag: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .let { if (testTag != null) it.testTag(testTag) else it }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun resolveAudioTitle(context: Context, uri: Uri): String {
    val ringtoneTitle = try {
        RingtoneManager.getRingtone(context, uri)?.getTitle(context)
    } catch (_: Exception) {
        null
    }
    if (!ringtoneTitle.isNullOrBlank() && !ringtoneTitle.equals("Unknown ringtone", ignoreCase = true)) {
        return ringtoneTitle
    }
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment ?: "Custom Audio"
}
