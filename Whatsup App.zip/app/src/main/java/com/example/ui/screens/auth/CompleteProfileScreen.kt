package com.example.ui.screens.auth

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AuthUiState
import java.io.File

private val QUICK_STATUS_PRESETS = listOf(
    "Hey there! I am using Whatsup.",
    "Available",
    "Busy",
    "At work",
    "In a meeting",
    "At school"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CompleteProfileScreenContent(
    uiState: AuthUiState,
    onNameChange: (String) -> Unit,
    onStatusChange: (String) -> Unit,
    onPickPhotoUri: (android.net.Uri) -> Unit,
    onRemovePhoto: () -> Unit,
    onToggleTwoStep: (Boolean) -> Unit,
    onTwoStepPinChange: (String) -> Unit,
    onTwoStepConfirmChange: (String) -> Unit,
    onTwoStepHintChange: (String) -> Unit,
    onFinish: () -> Unit
) {
    val isDark = LocalIsDarkTheme.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickPhotoUri(uri)
        }
    }

    val localPhotoFile = remember(uiState.profilePhotoLocalPath) {
        uiState.profilePhotoLocalPath
            .takeIf { it.isNotBlank() }
            ?.let { File(it) }
            ?.takeIf { it.exists() && it.length() > 0L }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("complete_profile_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = null,
                tint = WhatsupGreen,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Complete Profile",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (uiState.normalizedGmail.isNotBlank()) {
                    Text(
                        text = uiState.normalizedGmail,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isDark) WhatsupGreen else WhatsupDarkGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Interactive Local Storage Profile Photo Picker
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clickable(role = Role.Button, enabled = !uiState.isLoading) {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .testTag("complete_profile_photo_picker"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(2.5.dp, WhatsupGreen, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (localPhotoFile != null) {
                        AsyncImage(
                            model = localPhotoFile,
                            contentDescription = "Selected profile photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        val initial = uiState.profileNameInput.trim().take(1).uppercase()
                        if (initial.isNotBlank()) {
                            Text(
                                text = initial,
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Bold,
                                color = WhatsupGreen
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Default profile avatar",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }
                }
                Surface(
                    color = WhatsupGreen,
                    shape = CircleShape,
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.AddAPhoto,
                            contentDescription = "Choose profile photo",
                            tint = Color.White,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    enabled = !uiState.isLoading,
                    modifier = Modifier.testTag("complete_profile_choose_photo_button")
                ) {
                    Text(
                        text = if (localPhotoFile != null) "Change Photo" else "Add Profile Photo",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                if (localPhotoFile != null) {
                    TextButton(
                        onClick = onRemovePhoto,
                        enabled = !uiState.isLoading,
                        modifier = Modifier.testTag("complete_profile_remove_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Remove profile photo",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Remove", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Text(
                text = if (localPhotoFile != null) {
                    "Saved to local device storage"
                } else {
                    "Optional • Saved privately on your device"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Display Name
        OutlinedTextField(
            value = uiState.profileNameInput,
            onValueChange = onNameChange,
            label = { Text("Display Name") },
            placeholder = { Text("Enter your name") },
            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
            singleLine = true,
            enabled = !uiState.isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_profile_name_input")
        )

        // Status / About
        OutlinedTextField(
            value = uiState.profileAboutInput,
            onValueChange = onStatusChange,
            label = { Text("Status / About") },
            placeholder = { Text("Hey there! I am using Whatsup.") },
            leadingIcon = { Icon(Icons.Filled.EditNote, contentDescription = null) },
            singleLine = true,
            enabled = !uiState.isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_profile_about_input")
        )

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Quick Status",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                QUICK_STATUS_PRESETS.forEach { preset ->
                    val selected = uiState.profileAboutInput == preset
                    FilterChip(
                        selected = selected,
                        onClick = { onStatusChange(preset) },
                        label = {
                            Text(
                                text = preset,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        },
                        leadingIcon = if (selected) {
                            {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WhatsupGreen.copy(alpha = 0.16f),
                            selectedLabelColor = if (isDark) WhatsupGreen else WhatsupDarkGreen,
                            selectedLeadingIconColor = if (isDark) WhatsupGreen else WhatsupDarkGreen
                        )
                    )
                }
            }
        }

        // Optional Two-Step Verification PIN setup
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Checkbox(
                checked = uiState.showPinSetupInOnboarding,
                onCheckedChange = onToggleTwoStep
            )
            Text(
                text = "Enable Two-Step Verification PIN (recommended)",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f)
            )
        }

        if (uiState.showPinSetupInOnboarding) {
            OutlinedTextField(
                value = uiState.twoStepPinInput,
                onValueChange = onTwoStepPinChange,
                label = { Text("Create 6-digit PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = uiState.twoStepConfirmInput,
                onValueChange = onTwoStepConfirmChange,
                label = { Text("Confirm 6-digit PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = uiState.twoStepHintInput,
                onValueChange = onTwoStepHintChange,
                label = { Text("Recovery Hint / Word (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            onClick = onFinish,
            enabled = !uiState.isLoading && uiState.profileNameInput.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("auth_finish_profile_button")
        ) {
            Text(
                text = "Save & Enter Whatsup",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
