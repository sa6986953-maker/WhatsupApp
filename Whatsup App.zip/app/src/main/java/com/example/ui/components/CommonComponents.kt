package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.EncryptionAmber
import com.example.ui.theme.EncryptionAmberText
import com.example.ui.theme.OnlineIndicator
import com.example.ui.theme.TickBlue

@Composable
fun ContactAvatar(
    name: String,
    colorHex: Long,
    chatType: String,
    online: Boolean = false,
    size: Dp = 50.dp
) {
    val initials = name
        .replace(Regex("[^A-Za-z0-9 ]"), "")
        .trim()
        .split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifBlank { "W" }

    Box(modifier = Modifier.size(size)) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(colorHex)),
            contentAlignment = Alignment.Center
        ) {
            when (chatType) {
                "BLUETOOTH_GROUP" -> Icon(
                    imageVector = Icons.Filled.BluetoothConnected,
                    contentDescription = name,
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.52f)
                )
                "GROUP" -> Icon(
                    imageVector = Icons.Filled.Group,
                    contentDescription = name,
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.54f)
                )
                "COMMUNITY" -> Icon(
                    imageVector = Icons.Filled.Groups,
                    contentDescription = name,
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.54f)
                )
                else -> Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.36f).sp
                )
            }
        }
        if (online) {
            Box(
                modifier = Modifier
                    .size(13.dp)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(OnlineIndicator)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun MessageTickBadge(
    tickStatus: String,
    viaBluetooth: Boolean,
    hideBlueTicks: Boolean = false
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (viaBluetooth) {
            Icon(
                imageVector = Icons.Filled.Bluetooth,
                contentDescription = "Sent via Bluetooth",
                tint = BluetoothBlue,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
        }
        when (tickStatus) {
            "PENDING_SYNC" -> Icon(
                imageVector = Icons.Filled.Schedule,
                contentDescription = "Pending cloud sync",
                tint = BluetoothBlue,
                modifier = Modifier.size(14.dp)
            )
            "SENT" -> Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "Sent",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(15.dp)
            )
            "DELIVERED" -> Icon(
                imageVector = Icons.Filled.DoneAll,
                contentDescription = "Delivered",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(15.dp)
            )
            "READ", "BLUETOOTH" -> Icon(
                imageVector = Icons.Filled.DoneAll,
                contentDescription = if (hideBlueTicks) "Delivered" else "Seen",
                tint = if (hideBlueTicks) MaterialTheme.colorScheme.onSurfaceVariant else TickBlue,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

@Composable
fun EncryptionNoticeBanner(
    bluetoothMode: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        color = if (bluetoothMode) BluetoothBlue.copy(alpha = 0.14f) else EncryptionAmber.copy(alpha = 0.92f),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (bluetoothMode) Icons.Filled.BluetoothConnected else Icons.Filled.Lock,
                contentDescription = null,
                tint = if (bluetoothMode) BluetoothBlue else EncryptionAmberText,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (bluetoothMode) {
                    "Offline Bluetooth Mesh Active (100m range). E2E Signal-encrypted packets auto-sync to cloud when internet returns."
                } else {
                    "Messages and calls are end-to-end encrypted. No one outside of this chat, not even Whatsup, can read or listen to them."
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (bluetoothMode) MaterialTheme.colorScheme.onSurface else EncryptionAmberText
            )
        }
    }
}
