package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.EmailUtils
import com.example.core.PreferencesManager
import com.example.core.StorageMediaManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.GmailAuthMode
import com.example.ui.theme.AppThemeMode
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AuthStage {
    GMAIL_ENTRY,
    OTP_ENTRY,
    TWO_STEP_CHALLENGE,
    PROFILE_SETUP,
    READY
}

object AuthRateLimitPolicy {
    const val RESEND_COOLDOWN_SECONDS = 60
    const val OTP_EXPIRY_SECONDS = 300 // 5 minutes
    const val MAX_RESENDS_PER_SESSION = 5
    const val MAX_VERIFY_ATTEMPTS = 5
}

data class AuthUiState(
    val authMode: GmailAuthMode = GmailAuthMode.REGISTER,
    val gmailInput: String = "",
    val normalizedGmail: String = "",
    val otpCodeInput: String = "",
    val stage: AuthStage = AuthStage.GMAIL_ENTRY,
    val resendCooldownSeconds: Int = 0,
    val otpExpiresInSeconds: Int = 0,
    val resendsUsed: Int = 0,
    val verifyAttemptsUsed: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoBanner: String? = null,
    val profileNameInput: String = "",
    val profileAboutInput: String = "Hey there! I am using Whatsup.",
    val profilePhotoLocalPath: String = "",
    val twoStepPinInput: String = "",
    val twoStepConfirmInput: String = "",
    val twoStepHintInput: String = "",
    val showPinSetupInOnboarding: Boolean = false
)

class AuthViewModel(
    private val authRepository: AuthRepository,
    private val preferencesManager: PreferencesManager,
    private val db: FirebaseFirestore,
    private val storageMediaManager: StorageMediaManager? = null
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = authRepository.observeAuthUser()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = authRepository.currentUser()
        )

    val themeMode: StateFlow<AppThemeMode> = preferencesManager.preferencesFlow
        .map { it.themeMode }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = AppThemeMode.SYSTEM
        )

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var resendCountdownJob: Job? = null
    private var expiryCountdownJob: Job? = null
    private var pendingPostOtpProfileCompletion: Boolean = false

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            preferencesManager.setThemeMode(mode)
        }
    }

    fun selectAuthMode(mode: GmailAuthMode) {
        _uiState.value = _uiState.value.copy(
            authMode = mode,
            errorMessage = null,
            infoBanner = null
        )
    }

    fun updateGmailInput(input: String) {
        val cleaned = input.filter { !it.isWhitespace() }.take(254)
        _uiState.value = _uiState.value.copy(
            gmailInput = cleaned,
            errorMessage = null
        )
    }

    fun updateOtpCode(input: String) {
        val digits = input.filter { it.isDigit() }.take(6)
        _uiState.value = _uiState.value.copy(
            otpCodeInput = digits,
            errorMessage = null
        )
    }

    fun requestOtp(isResend: Boolean = false) {
        val current = _uiState.value
        if (current.isLoading) return

        if (isResend) {
            if (current.resendCooldownSeconds > 0) {
                _uiState.value = current.copy(
                    errorMessage = "Please wait ${current.resendCooldownSeconds}s before resending OTP."
                )
                return
            }
            if (current.resendsUsed >= AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION) {
                _uiState.value = current.copy(
                    errorMessage = "Maximum OTP resend limit (${AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION}) reached. Try again later."
                )
                return
            }
        }

        val normalized = EmailUtils.normalizeGmail(current.gmailInput)
        if (normalized == null) {
            _uiState.value = current.copy(
                errorMessage = "Enter a valid Gmail address (e.g. yourname@gmail.com)."
            )
            return
        }

        if (current.authMode == GmailAuthMode.REGISTER && current.profileNameInput.trim().isEmpty()) {
            _uiState.value = current.copy(
                errorMessage = "Enter your full name to register with Gmail."
            )
            return
        }

        _uiState.value = current.copy(
            isLoading = true,
            normalizedGmail = normalized,
            errorMessage = null,
            infoBanner = "Sending 6-digit verification code to $normalized..."
        )

        viewModelScope.launch {
            authRepository.requestEmailOtp(
                email = normalized,
                mode = current.authMode,
                displayName = current.profileNameInput.trim()
            ).fold(
                onSuccess = { res ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        normalizedGmail = res.email,
                        stage = AuthStage.OTP_ENTRY,
                        otpCodeInput = "",
                        resendsUsed = if (isResend) current.resendsUsed + 1 else 0,
                        verifyAttemptsUsed = 0,
                        errorMessage = null,
                        infoBanner = "6-digit OTP sent to ${res.email}. Valid for 5 minutes."
                    )
                    startResendCountdown(res.resendCooldownSeconds)
                    startExpiryCountdown(res.expiresInSeconds)
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Failed to send verification code.",
                        infoBanner = null
                    )
                }
            )
        }
    }

    private fun startResendCountdown(seconds: Int = AuthRateLimitPolicy.RESEND_COOLDOWN_SECONDS) {
        resendCountdownJob?.cancel()
        resendCountdownJob = viewModelScope.launch {
            for (sec in seconds downTo 0) {
                _uiState.value = _uiState.value.copy(resendCooldownSeconds = sec)
                if (sec > 0) delay(1000L)
            }
        }
    }

    private fun startExpiryCountdown(seconds: Int = AuthRateLimitPolicy.OTP_EXPIRY_SECONDS) {
        expiryCountdownJob?.cancel()
        expiryCountdownJob = viewModelScope.launch {
            for (sec in seconds downTo 0) {
                _uiState.value = _uiState.value.copy(otpExpiresInSeconds = sec)
                if (sec > 0) delay(1000L)
            }
        }
    }

    fun verifyEnteredOtp() {
        val current = _uiState.value
        if (current.isLoading) return

        val targetEmail = current.normalizedGmail.ifBlank {
            EmailUtils.normalizeGmail(current.gmailInput).orEmpty()
        }
        if (targetEmail.isBlank()) {
            _uiState.value = current.copy(errorMessage = "Enter your Gmail address first.")
            return
        }
        if (current.otpExpiresInSeconds <= 0) {
            _uiState.value = current.copy(errorMessage = "This OTP has expired (5-minute limit). Tap Resend OTP to get a new code.")
            return
        }
        if (current.verifyAttemptsUsed >= AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS) {
            _uiState.value = current.copy(
                errorMessage = "Too many failed OTP attempts (${AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS}). Request a new OTP."
            )
            return
        }
        if (!EmailUtils.isValidOtpCode(current.otpCodeInput)) {
            _uiState.value = current.copy(errorMessage = "Enter the 6-digit verification code sent to your Gmail.")
            return
        }

        // Flag before signInWithCustomToken triggers currentUser observer
        pendingPostOtpProfileCompletion = true
        _uiState.value = current.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.verifyEmailOtp(
                email = targetEmail,
                otpCode = current.otpCodeInput,
                mode = current.authMode,
                displayName = current.profileNameInput.trim()
            ).fold(
                onSuccess = { verifyRes ->
                    resendCountdownJob?.cancel()
                    expiryCountdownJob?.cancel()
                    handlePostFirebaseAuth(verifyRes.user, verifyRes.email)
                },
                onFailure = { error ->
                    pendingPostOtpProfileCompletion = false
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        verifyAttemptsUsed = current.verifyAttemptsUsed + 1,
                        errorMessage = error.localizedMessage ?: "OTP verification failed."
                    )
                }
            )
        }
    }

    suspend fun evaluateAuthenticatedSession(user: FirebaseUser, verifiedTwoStepUid: String) {
        val verifiedEmail = user.email?.takeIf { it.isNotBlank() }
            ?: _uiState.value.normalizedGmail
        if (verifiedEmail.isNotBlank()) {
            preferencesManager.setVerifiedEmail(verifiedEmail)
        }
        val meta = authRepository.fetchProfileMeta(db, user.uid)
        val localPhoto = storageMediaManager?.findExistingLocalProfilePhoto(user.uid).orEmpty()
        if (localPhoto.isNotBlank()) {
            preferencesManager.setLocalProfilePhotoPath(localPhoto)
        }

        val nextStage = when {
            meta.twoStepEnabled && verifiedTwoStepUid != user.uid -> AuthStage.TWO_STEP_CHALLENGE
            pendingPostOtpProfileCompletion -> AuthStage.PROFILE_SETUP
            !meta.hasProfile -> AuthStage.PROFILE_SETUP
            else -> AuthStage.READY
        }
        val current = _uiState.value
        _uiState.value = current.copy(
            isLoading = false,
            normalizedGmail = verifiedEmail,
            stage = nextStage,
            profileNameInput = current.profileNameInput.ifBlank {
                meta.displayName.ifBlank { user.displayName.orEmpty() }
            },
            profileAboutInput = meta.about.ifBlank { current.profileAboutInput },
            profilePhotoLocalPath = current.profilePhotoLocalPath.ifBlank { localPhoto },
            errorMessage = null
        )
    }

    private suspend fun handlePostFirebaseAuth(user: FirebaseUser, verifiedEmailFromServer: String) {
        val verifiedEmail = verifiedEmailFromServer.ifBlank { user.email.orEmpty() }
            .ifBlank { _uiState.value.normalizedGmail }
        if (verifiedEmail.isNotBlank()) {
            preferencesManager.setVerifiedEmail(verifiedEmail)
        }
        val meta = authRepository.fetchProfileMeta(db, user.uid)
        val localPhoto = storageMediaManager?.findExistingLocalProfilePhoto(user.uid).orEmpty()
        if (localPhoto.isNotBlank()) {
            preferencesManager.setLocalProfilePhotoPath(localPhoto)
        }

        val current = _uiState.value
        val resolvedName = current.profileNameInput.ifBlank {
            meta.displayName.ifBlank { user.displayName.orEmpty() }
        }
        val resolvedAbout = meta.about.ifBlank { current.profileAboutInput }
        val resolvedPhoto = current.profilePhotoLocalPath.ifBlank { localPhoto }

        if (meta.twoStepEnabled) {
            _uiState.value = current.copy(
                isLoading = false,
                normalizedGmail = verifiedEmail,
                stage = AuthStage.TWO_STEP_CHALLENGE,
                twoStepPinInput = "",
                profileNameInput = resolvedName,
                profileAboutInput = resolvedAbout,
                profilePhotoLocalPath = resolvedPhoto,
                infoBanner = "Gmail verified! Enter your Two-Step Verification PIN to continue."
            )
        } else {
            // Always show Complete Profile screen immediately after successful OTP verification
            _uiState.value = current.copy(
                isLoading = false,
                normalizedGmail = verifiedEmail,
                stage = AuthStage.PROFILE_SETUP,
                profileNameInput = resolvedName,
                profileAboutInput = resolvedAbout,
                profilePhotoLocalPath = resolvedPhoto,
                infoBanner = "Gmail verified ($verifiedEmail)! Set up your Whatsup profile below."
            )
        }
    }

    fun pickLocalProfilePhoto(uri: Uri) {
        val uid = authRepository.currentUser()?.uid ?: "current"
        val mediaMgr = storageMediaManager ?: return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            mediaMgr.saveProfilePhotoLocally(uid, uri).fold(
                onSuccess = { path ->
                    preferencesManager.setLocalProfilePhotoPath(path)
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        profilePhotoLocalPath = path,
                        infoBanner = "Profile photo saved to local storage."
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Failed to save selected photo."
                    )
                }
            )
        }
    }

    fun removeLocalProfilePhoto() {
        val existingPath = _uiState.value.profilePhotoLocalPath
        storageMediaManager?.deleteLocalProfilePhoto(existingPath)
        viewModelScope.launch {
            preferencesManager.setLocalProfilePhotoPath("")
            _uiState.value = _uiState.value.copy(
                profilePhotoLocalPath = "",
                infoBanner = "Profile photo removed."
            )
        }
    }

    fun updateTwoStepPinInput(pin: String) {
        _uiState.value = _uiState.value.copy(
            twoStepPinInput = pin.filter { it.isDigit() }.take(6),
            errorMessage = null
        )
    }

    fun updateTwoStepConfirmInput(pin: String) {
        _uiState.value = _uiState.value.copy(
            twoStepConfirmInput = pin.filter { it.isDigit() }.take(6),
            errorMessage = null
        )
    }

    fun updateTwoStepHintInput(hint: String) {
        _uiState.value = _uiState.value.copy(
            twoStepHintInput = hint.take(120),
            errorMessage = null
        )
    }

    fun verifyTwoStepChallenge() {
        val pin = _uiState.value.twoStepPinInput
        if (pin.length != 6) {
            _uiState.value = _uiState.value.copy(errorMessage = "Enter your 6-digit Two-Step PIN.")
            return
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.verifyTwoStepPinServerSide(pin).fold(
                onSuccess = { ok ->
                    if (ok) {
                        preferencesManager.setTwoStepVerifiedUid(uid)
                        val nextStage = if (pendingPostOtpProfileCompletion) {
                            AuthStage.PROFILE_SETUP
                        } else {
                            AuthStage.READY
                        }
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            stage = nextStage,
                            infoBanner = if (nextStage == AuthStage.PROFILE_SETUP) {
                                "Two-Step PIN verified! Review or complete your profile."
                            } else {
                                null
                            }
                        )
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = "Incorrect Two-Step PIN."
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "PIN verification failed."
                    )
                }
            )
        }
    }

    fun recoverTwoStepPin(recoveryAnswer: String, newPin: String, confirmPin: String) {
        if (newPin.length != 6 || newPin != confirmPin) {
            _uiState.value = _uiState.value.copy(errorMessage = "New 6-digit PINs must match.")
            return
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.recoverTwoStepPinServerSide(recoveryAnswer, newPin).fold(
                onSuccess = {
                    preferencesManager.setTwoStepVerifiedUid(uid)
                    val nextStage = if (pendingPostOtpProfileCompletion) {
                        AuthStage.PROFILE_SETUP
                    } else {
                        AuthStage.READY
                    }
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        stage = nextStage,
                        infoBanner = "Two-Step PIN recovered and updated."
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Recovery failed."
                    )
                }
            )
        }
    }

    fun updateProfileNameInput(name: String) {
        _uiState.value = _uiState.value.copy(
            profileNameInput = name.take(60),
            errorMessage = null
        )
    }

    fun updateProfileAboutInput(about: String) {
        _uiState.value = _uiState.value.copy(
            profileAboutInput = about.take(160),
            errorMessage = null
        )
    }

    fun toggleOnboardingTwoStep(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(showPinSetupInOnboarding = enabled, errorMessage = null)
    }

    fun completeOnboardingProfile(
        onRegisterProfile: suspend (displayName: String, about: String, localPhotoPath: String) -> Result<Unit>
    ) {
        val state = _uiState.value
        val cleanName = state.profileNameInput.trim()
        if (cleanName.isEmpty()) {
            _uiState.value = state.copy(errorMessage = "Please enter your display name.")
            return
        }
        if (state.showPinSetupInOnboarding) {
            if (state.twoStepPinInput.length != 6 || state.twoStepPinInput != state.twoStepConfirmInput) {
                _uiState.value = state.copy(errorMessage = "Two-Step PIN must be 6 matching digits.")
                return
            }
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = state.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val cleanStatus = state.profileAboutInput.trim().ifBlank { "Hey there! I am using Whatsup." }
            preferencesManager.setLocalProfilePhotoPath(state.profilePhotoLocalPath)

            onRegisterProfile(cleanName, cleanStatus, state.profilePhotoLocalPath)
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Failed to save profile."
                    )
                    return@launch
                }

            var banner: String? = null
            if (state.showPinSetupInOnboarding) {
                authRepository.setTwoStepPinServerSide(
                    pin = state.twoStepPinInput,
                    recoveryHint = state.twoStepHintInput
                ).onFailure { err ->
                    banner = "Profile saved, but Two-Step PIN setup requires Cloud Functions: ${err.localizedMessage}"
                }
            }
            pendingPostOtpProfileCompletion = false
            preferencesManager.setTwoStepVerifiedUid(uid)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                stage = AuthStage.READY,
                infoBanner = banner
            )
        }
    }

    fun editGmailAgain() {
        resendCountdownJob?.cancel()
        expiryCountdownJob?.cancel()
        pendingPostOtpProfileCompletion = false
        _uiState.value = _uiState.value.copy(
            stage = AuthStage.GMAIL_ENTRY,
            otpCodeInput = "",
            resendCooldownSeconds = 0,
            otpExpiresInSeconds = 0,
            errorMessage = null,
            infoBanner = null
        )
    }

    fun linkGoogleAccountOptional(activity: Activity) {
        if (_uiState.value.isLoading) return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.linkOrSignInWithGoogleOptional(activity).fold(
                onSuccess = {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        infoBanner = "Google account linked for optional backup."
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Google linking cancelled or unavailable."
                    )
                }
            )
        }
    }

    fun signOut(context: Context) {
        resendCountdownJob?.cancel()
        expiryCountdownJob?.cancel()
        pendingPostOtpProfileCompletion = false
        viewModelScope.launch {
            preferencesManager.clearSessionPrefs()
            authRepository.signOut(context)
            _uiState.value = AuthUiState()
        }
    }

    override fun onCleared() {
        super.onCleared()
        resendCountdownJob?.cancel()
        expiryCountdownJob?.cancel()
    }
}
