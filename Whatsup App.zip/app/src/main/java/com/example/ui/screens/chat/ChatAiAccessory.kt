package com.example.ui.screens.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.InlineSummaryState
import com.example.ui.viewmodel.SuggestedRepliesState

@Composable
fun ChatAiAccessory(
    summaryState: InlineSummaryState,
    suggestionsState: SuggestedRepliesState,
    onlyAdminCanSend: Boolean,
    darkMode: Boolean,
    onSummarizeClick: () -> Unit,
    onDismissSummary: () -> Unit,
    onSuggestRepliesClick: () -> Unit,
    onDismissSuggestions: () -> Unit,
    onInsertSuggestedReply: (String) -> Unit,
    onSendSuggestedReply: (String) -> Unit,
    onOpenFullAiSheet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboardManager = LocalClipboardManager.current
    var copiedFeedback by remember(summaryState) { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // 1. Expandable Inline Gemini Summary Card
        AnimatedVisibility(
            visible = summaryState !is InlineSummaryState.Idle,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            InlineSummaryCard(
                summaryState = summaryState,
                darkMode = darkMode,
                copiedFeedback = copiedFeedback,
                onCopy = { text ->
                    clipboardManager.setText(AnnotatedString(text))
                    copiedFeedback = true
                },
                onRetry = onSummarizeClick,
                onDismiss = onDismissSummary
            )
        }

        // 2. Suggested Replies Strip (hidden when group is admin-locked)
        if (!onlyAdminCanSend) {
            AnimatedVisibility(
                visible = suggestionsState !is SuggestedRepliesState.Idle,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                SuggestedRepliesStrip(
                    suggestionsState = suggestionsState,
                    darkMode = darkMode,
                    onRetry = onSuggestRepliesClick,
                    onDismiss = onDismissSuggestions,
                    onInsertReply = onInsertSuggestedReply,
                    onSendReply = onSendSuggestedReply
                )
            }
        }

        // 3. Compact Input Accessory Action Strip directly above the composer
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val summaryActive = summaryState !is InlineSummaryState.Idle
            val suggestionsActive = suggestionsState !is SuggestedRepliesState.Idle

            AccessoryActionPill(
                label = if (summaryState is InlineSummaryState.Loading || summaryState is InlineSummaryState.Streaming) {
                    "Summarizing..."
                } else {
                    "Summarize Chat"
                },
                icon = Icons.Filled.Summarize,
                active = summaryActive,
                loading = summaryState is InlineSummaryState.Loading || summaryState is InlineSummaryState.Streaming,
                darkMode = darkMode,
                testTag = "accessory_summarize_button",
                onClick = {
                    if (summaryState is InlineSummaryState.Success) {
                        onDismissSummary()
                    } else {
                        onSummarizeClick()
                    }
                }
            )

            if (!onlyAdminCanSend) {
                AccessoryActionPill(
                    label = if (suggestionsState is SuggestedRepliesState.Loading) {
                        "Drafting Replies..."
                    } else {
                        "Smart Replies"
                    },
                    icon = Icons.AutoMirrored.Filled.Reply,
                    active = suggestionsActive,
                    loading = suggestionsState is SuggestedRepliesState.Loading,
                    darkMode = darkMode,
                    testTag = "accessory_suggest_replies_button",
                    onClick = {
                        if (suggestionsState is SuggestedRepliesState.Success) {
                            onDismissSuggestions()
                        } else {
                            onSuggestRepliesClick()
                        }
                    }
                )
            }

            AccessoryActionPill(
                label = "Ask Whatsup AI",
                icon = Icons.Filled.AutoAwesome,
                active = false,
                loading = false,
                darkMode = darkMode,
                testTag = "accessory_open_ai_sheet_button",
                onClick = onOpenFullAiSheet
            )
        }
    }
}

@Composable
private fun AccessoryActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    loading: Boolean,
    darkMode: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val containerColor = when {
        active -> WhatsupDarkGreen
        darkMode -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f)
        else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
    }
    val contentColor = when {
        active -> Color.White
        darkMode -> Color.White
        else -> WhatsupDarkGreen
    }
    val borderColor = if (active) WhatsupGreen else WhatsupGreen.copy(alpha = 0.35f)

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        shadowElevation = 1.dp,
        modifier = Modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(15.dp),
                    strokeWidth = 2.dp,
                    color = contentColor
                )
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (active) WhatsupGreen else WhatsupDarkGreen,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun InlineSummaryCard(
    summaryState: InlineSummaryState,
    darkMode: Boolean,
    copiedFeedback: Boolean,
    onCopy: (String) -> Unit,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    val surfaceColor = if (darkMode) {
        MaterialTheme.colorScheme.surfaceVariant
    } else {
        MaterialTheme.colorScheme.surface
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = surfaceColor,
        border = BorderStroke(1.dp, WhatsupGreen.copy(alpha = 0.4f)),
        shadowElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("inline_summary_card")
    ) {
        Column(modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = WhatsupGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Whatsup AI Thread Summary",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (darkMode) WhatsupGreen else WhatsupDarkGreen,
                    modifier = Modifier.weight(1f)
                )
                if (summaryState is InlineSummaryState.Streaming) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = WhatsupGreen
                    )
                }
                if (summaryState is InlineSummaryState.Success) {
                    IconButton(
                        onClick = { onCopy(summaryState.text) },
                        modifier = Modifier.testTag("inline_summary_copy_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Copy Summary",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onRetry,
                        modifier = Modifier.testTag("inline_summary_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Regenerate Summary",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("inline_summary_dismiss_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Dismiss Summary",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            when (summaryState) {
                is InlineSummaryState.Loading -> {
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = WhatsupGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Summarizing recent messages with Gemini...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is InlineSummaryState.Streaming -> {
                    Text(
                        text = summaryState.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .heightIn(max = 140.dp)
                            .verticalScroll(rememberScrollState())
                    )
                }
                is InlineSummaryState.Success -> {
                    Text(
                        text = summaryState.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .heightIn(max = 150.dp)
                            .verticalScroll(rememberScrollState())
                    )
                    if (copiedFeedback) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Summary copied to clipboard",
                            style = MaterialTheme.typography.labelSmall,
                            color = WhatsupGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                is InlineSummaryState.Error -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = summaryState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = onRetry,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("inline_summary_retry_button")
                        ) {
                            Text("Retry")
                        }
                    }
                }
                InlineSummaryState.Idle -> Unit
            }
        }
    }
}

@Composable
private fun SuggestedRepliesStrip(
    suggestionsState: SuggestedRepliesState,
    darkMode: Boolean,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
    onInsertReply: (String) -> Unit,
    onSendReply: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (darkMode) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, BluetoothBlue.copy(alpha = 0.35f)),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("inline_suggested_replies_strip")
    ) {
        Column(modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Reply,
                    contentDescription = null,
                    tint = BluetoothBlue,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Suggested Replies • Tap to draft or send",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = BluetoothBlue,
                    modifier = Modifier.weight(1f)
                )
                if (suggestionsState is SuggestedRepliesState.Success) {
                    IconButton(
                        onClick = onRetry,
                        modifier = Modifier.testTag("suggested_replies_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Refresh Suggested Replies",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("suggested_replies_dismiss_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Dismiss Suggested Replies",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            when (suggestionsState) {
                is SuggestedRepliesState.Loading -> {
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = BluetoothBlue
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Generating replies with Gemini...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is SuggestedRepliesState.Success -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        suggestionsState.replies.forEachIndexed { index, reply ->
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = WhatsupGreen.copy(alpha = if (darkMode) 0.18f else 0.12f),
                                border = BorderStroke(1.dp, WhatsupGreen.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .widthIn(max = 260.dp)
                                    .testTag("suggested_reply_chip_$index")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f, fill = false)
                                            .heightIn(min = 40.dp)
                                            .clickable { onInsertReply(reply) },
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Text(
                                            text = reply,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { onSendReply(reply) },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .testTag("suggested_reply_send_$index")
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(WhatsupGreen),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Send,
                                                contentDescription = "Send suggested reply",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                is SuggestedRepliesState.Error -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = suggestionsState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = onRetry,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("suggested_replies_retry_button")
                        ) {
                            Text("Retry")
                        }
                    }
                }
                SuggestedRepliesState.Idle -> Unit
            }
        }
    }
}
