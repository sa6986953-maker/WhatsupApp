package com.example.ui.screens.groups

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedContact
import com.example.ui.components.ContactAvatar
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen

@Composable
fun GroupsAndCommunityScreen(
    chatsState: UiState<List<ChatThread>>,
    currentUserId: String,
    verifiedContacts: List<VerifiedContact>,
    onOpenChat: (ChatThread) -> Unit,
    onToggleAdminOnlySend: (ChatThread) -> Unit,
    onCreateGroup: (
        title: String,
        description: String,
        chatType: String,
        members: List<VerifiedContact>,
        onlyAdminCanSend: Boolean,
        bluetoothChat: Boolean,
        communityName: String?
    ) -> Unit,
    onJoinGroupByCode: (String) -> Unit,
    onUpdateGroupDetails: (groupId: String, title: String, description: String) -> Unit,
    onToggleGroupAdmin: (ChatThread, String) -> Unit,
    onAddMemberToGroup: (ChatThread, VerifiedContact) -> Unit,
    onRemoveMemberFromGroup: (ChatThread, String) -> Unit,
    onFetchGroupParticipants: suspend (List<String>) -> Map<String, UserProfile>
) {
    val clipboard = LocalClipboardManager.current
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var showJoinInviteDialog by remember { mutableStateOf(false) }
    var manageGroupId by remember { mutableStateOf<String?>(null) }

    when (chatsState) {
        is UiState.Loading -> BoxLoading()
        is UiState.Error -> Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(chatsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val groupChats = chatsState.data.filter { it.chatType != "DIRECT" }
            val managedGroup = groupChats.firstOrNull { it.id == manageGroupId }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "community_banner") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhatsupDarkGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Groups, contentDescription = null, tint = WhatsupGreen, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Groups & Communities",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Encrypted group chats, admin permissions, invite links & offline mesh groups",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showCreateGroupDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("create_community_group_button")
                                ) {
                                    Icon(Icons.Filled.GroupAdd, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("New Group", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { showJoinInviteDialog = true },
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Icon(Icons.Filled.Link, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Join Link", color = Color.White)
                                }
                            }
                        }
                    }
                }

                if (groupChats.isEmpty()) {
                    item(key = "no_groups_empty") {
                        Text(
                            text = "No groups yet. Create a group with verified contacts or join via invite code.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(groupChats, key = { it.id }) { group ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenChat(group) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ContactAvatar(
                                        name = group.title,
                                        colorHex = group.avatarColorHex,
                                        chatType = group.chatType,
                                        online = group.online,
                                        size = 48.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${group.participantUids.size} members" +
                                                (group.communityName?.let { " • $it" } ?: ""),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (group.bluetoothChat) BluetoothBlue else WhatsupGreen
                                        )
                                    }
                                    IconButton(onClick = { manageGroupId = group.id }) {
                                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = "Group Info & Admin Controls", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = group.lastMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (group.bluetoothChat) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Surface(
                                        color = BluetoothBlue.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Filled.BluetoothConnected, contentDescription = null, tint = BluetoothBlue, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Offline Bluetooth Group", style = MaterialTheme.typography.labelSmall, color = BluetoothBlue)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item(key = "groups_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }

            if (managedGroup != null) {
                GroupManagementDialog(
                    group = managedGroup,
                    currentUserId = currentUserId,
                    verifiedContacts = verifiedContacts,
                    onFetchParticipants = onFetchGroupParticipants,
                    onCopyInviteCode = { code -> clipboard.setText(AnnotatedString(code)) },
                    onToggleAdminOnlySend = { onToggleAdminOnlySend(managedGroup) },
                    onUpdateDetails = { t, d -> onUpdateGroupDetails(managedGroup.id, t, d) },
                    onToggleAdmin = { uid -> onToggleGroupAdmin(managedGroup, uid) },
                    onAddMember = { c -> onAddMemberToGroup(managedGroup, c) },
                    onRemoveMember = { uid -> onRemoveMemberFromGroup(managedGroup, uid) },
                    onDismiss = { manageGroupId = null }
                )
            }
        }
    }

    if (showCreateGroupDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var community by remember { mutableStateOf("") }
        var isBtGroup by remember { mutableStateOf(false) }
        var onlyAdminCanSend by remember { mutableStateOf(false) }
        val selectedContactUids = remember { mutableStateListOf<String>() }

        AlertDialog(
            onDismissRequest = { showCreateGroupDialog = false },
            title = { Text("Create Encrypted Group") },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Group Name") }, singleLine = true)
                    }
                    item {
                        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description (optional)") }, maxLines = 2)
                    }
                    item {
                        OutlinedTextField(value = community, onValueChange = { community = it }, label = { Text("Community Name (optional)") }, singleLine = true)
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Offline Bluetooth Group", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = isBtGroup, onCheckedChange = { isBtGroup = it }, colors = SwitchDefaults.colors(checkedTrackColor = BluetoothBlue))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Only Admins Can Send", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = onlyAdminCanSend, onCheckedChange = { onlyAdminCanSend = it }, colors = SwitchDefaults.colors(checkedTrackColor = WhatsupGreen))
                        }
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Add Verified Contacts (${selectedContactUids.size} selected)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (verifiedContacts.isEmpty()) {
                        item {
                            Text(
                                text = "No verified contacts added yet. You can still create the group and share the invite link.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(verifiedContacts, key = { it.contactUid }) { contact ->
                            val checked = contact.contactUid in selectedContactUids
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (checked) selectedContactUids.remove(contact.contactUid) else selectedContactUids.add(contact.contactUid)
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        if (checked) selectedContactUids.remove(contact.contactUid) else selectedContactUids.add(contact.contactUid)
                                    }
                                )
                                Column {
                                    Text(contact.savedName, style = MaterialTheme.typography.bodyMedium)
                                    Text(contact.phoneE164, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            val chosen = verifiedContacts.filter { it.contactUid in selectedContactUids }
                            onCreateGroup(
                                title.trim(),
                                description.trim(),
                                if (isBtGroup) "BLUETOOTH_GROUP" else "GROUP",
                                chosen,
                                onlyAdminCanSend,
                                isBtGroup,
                                community.trim().ifBlank { null }
                            )
                            showCreateGroupDialog = false
                        }
                    },
                    enabled = title.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen)
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateGroupDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showJoinInviteDialog) {
        var inviteCode by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showJoinInviteDialog = false },
            title = { Text("Join Group via Invite Link") },
            text = {
                OutlinedTextField(
                    value = inviteCode,
                    onValueChange = { inviteCode = it },
                    label = { Text("Paste Invite Code or Link") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (inviteCode.isNotBlank()) {
                        onJoinGroupByCode(inviteCode)
                        showJoinInviteDialog = false
                    }
                }) { Text("Join") }
            },
            dismissButton = {
                TextButton(onClick = { showJoinInviteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun GroupManagementDialog(
    group: ChatThread,
    currentUserId: String,
    verifiedContacts: List<VerifiedContact>,
    onFetchParticipants: suspend (List<String>) -> Map<String, UserProfile>,
    onCopyInviteCode: (String) -> Unit,
    onToggleAdminOnlySend: () -> Unit,
    onUpdateDetails: (title: String, description: String) -> Unit,
    onToggleAdmin: (uid: String) -> Unit,
    onAddMember: (VerifiedContact) -> Unit,
    onRemoveMember: (uid: String) -> Unit,
    onDismiss: () -> Unit
) {
    val amAdmin = currentUserId in group.adminUids
    var titleInput by remember(group.title) { mutableStateOf(group.title) }
    var descInput by remember(group.groupDescription) { mutableStateOf(group.groupDescription) }
    var memberProfiles by remember(group.participantUids) { mutableStateOf<Map<String, UserProfile>>(emptyMap()) }
    var copiedInvite by remember { mutableStateOf(false) }

    LaunchedEffect(group.participantUids) {
        memberProfiles = onFetchParticipants(group.participantUids)
    }

    val contactsNotInGroup = remember(verifiedContacts, group.participantUids) {
        verifiedContacts.filter { it.contactUid !in group.participantUids }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Group Settings • ${group.title}") },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (amAdmin) {
                    item {
                        OutlinedTextField(value = titleInput, onValueChange = { titleInput = it }, label = { Text("Group Title") }, singleLine = true)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = descInput, onValueChange = { descInput = it }, label = { Text("Description") }, maxLines = 2)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(onClick = { onUpdateDetails(titleInput, descInput) }) {
                            Text("Save Group Info")
                        }
                    }
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Only Admins Can Send", fontWeight = FontWeight.SemiBold)
                            Switch(checked = group.onlyAdminCanSend, onCheckedChange = { onToggleAdminOnlySend() })
                        }
                    }
                } else if (group.groupDescription.isNotBlank()) {
                    item {
                        Text(group.groupDescription, style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (!group.inviteCode.isNullOrBlank()) {
                    item {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Invite Code", style = MaterialTheme.typography.labelSmall)
                                    Text(group.inviteCode, fontWeight = FontWeight.Bold)
                                }
                                IconButton(onClick = {
                                    onCopyInviteCode(group.inviteCode)
                                    copiedInvite = true
                                }) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy invite code")
                                }
                            }
                        }
                        if (copiedInvite) {
                            Text("Invite code copied!", style = MaterialTheme.typography.labelSmall, color = WhatsupGreen)
                        }
                    }
                }

                item {
                    Text("Members (${group.participantUids.size})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }

                items(group.participantUids, key = { it }) { uid ->
                    val user = memberProfiles[uid]
                    val displayName = when {
                        uid == currentUserId -> "You"
                        user != null -> user.displayName.ifBlank { user.phoneE164 }
                        else -> "User ${uid.take(6)}"
                    }
                    val isAdmin = uid in group.adminUids
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(displayName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            if (isAdmin) {
                                Text("Admin", style = MaterialTheme.typography.labelSmall, color = WhatsupGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (amAdmin && uid != currentUserId) {
                            TextButton(onClick = { onToggleAdmin(uid) }) {
                                Text(if (isAdmin) "Demote" else "Make Admin")
                            }
                            IconButton(onClick = { onRemoveMember(uid) }) {
                                Icon(Icons.Filled.PersonRemove, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                if (amAdmin && contactsNotInGroup.isNotEmpty()) {
                    item {
                        HorizontalDivider()
                        Text("Add Verified Contacts", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                    items(contactsNotInGroup, key = { it.contactUid }) { candidate ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(candidate.savedName, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { onAddMember(candidate) }) {
                                Icon(Icons.Filled.PersonAdd, contentDescription = "Add ${candidate.savedName}", tint = WhatsupGreen)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun BoxLoading() {
    Row(
        modifier = Modifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = WhatsupGreen)
    }
}
