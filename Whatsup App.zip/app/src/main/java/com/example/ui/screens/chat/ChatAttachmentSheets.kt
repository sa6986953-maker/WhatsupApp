package com.example.ui.screens.chat

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.ScheduleSend
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupGreen
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AttachMediaSheet(
    viewOnceEnabled: Boolean,
    onToggleViewOnce: () -> Unit,
    onSendUriAttachment: (uri: Uri, messageType: String, caption: String, viewOnce: Boolean) -> Unit,
    onSendMediaMessage: (text: String, messageType: String, mediaMeta: String) -> Unit,
    onOpenScheduleDialog: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showPollDialog by remember { mutableStateOf(false) }
    var showEventDialog by remember { mutableStateOf(false) }
    var attachmentNotice by remember { mutableStateOf<String?>(null) }

    // Zero-permission Photo Picker (Google Play Compliant)
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSendUriAttachment(uri, "IMAGE_HD", "HD Photo", viewOnceEnabled)
            onDismiss()
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSendUriAttachment(uri, "VIDEO", "Video", viewOnceEnabled)
            onDismiss()
        }
    }

    // Storage Access Framework for PDF, Word, APK, ZIP, any file
    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onSendUriAttachment(uri, "DOCUMENT", "Document", false)
            onDismiss()
        }
    }

    // Native Android Contacts Picker (zero broad READ_CONTACTS manifest permission)
    val contactPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickContact()
    ) { contactUri ->
        if (contactUri != null) {
            val resolved = readContactSummary(context, contactUri)
            if (resolved != null) {
                val (name, phone) = resolved
                val label = if (phone.isNotBlank()) "$name ($phone)" else name
                onSendMediaMessage("👤 Contact: $label", "CONTACT", "Shared Device Contact")
                onDismiss()
            } else {
                attachmentNotice = "Could not read details for the selected contact."
            }
        }
    }

    val coarseLocationPermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            attachmentNotice = "Location permission is required to share GPS coordinates."
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            val coords = fetchApproximateCoordinates(context)
            if (coords != null) {
                val (lat, lng) = coords
                val latStr = String.format(Locale.US, "%.5f", lat)
                val lngStr = String.format(Locale.US, "%.5f", lng)
                onSendMediaMessage(
                    "📍 Location ($latStr, $lngStr)\nhttps://maps.google.com/?q=$latStr,$lngStr",
                    "LOCATION",
                    "GPS Coordinates • $latStr, $lngStr"
                )
                onDismiss()
            } else {
                attachmentNotice = "Unable to obtain device location right now. Enable GPS/Location services and try again."
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Share Media & Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onToggleViewOnce,
                    modifier = Modifier.testTag("view_once_toggle_button")
                ) {
                    Text(
                        text = if (viewOnceEnabled) "① View Once: ON" else "① View Once: OFF",
                        color = if (viewOnceEnabled) WhatsupGreen else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (attachmentNotice != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = attachmentNotice!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 4,
                horizontalArrangement = Arrangement.SpaceAround,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                AttachOption(Icons.Filled.PhotoLibrary, "HD Photo", Color(0xFF8E24AA)) {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                AttachOption(Icons.Filled.Videocam, "Video", Color(0xFFD81B60)) {
                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }
                AttachOption(Icons.Filled.Description, "Document", Color(0xFF5E35B1)) {
                    documentPicker.launch(arrayOf("*/*"))
                }
                AttachOption(Icons.Filled.LocationOn, "Location", WhatsupGreen) {
                    coarseLocationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }
                AttachOption(Icons.Filled.Contacts, "Contact", BluetoothBlue) {
                    contactPickerLauncher.launch(null)
                }
                AttachOption(Icons.Filled.Poll, "Poll", Color(0xFF00897B)) {
                    showPollDialog = true
                }
                AttachOption(Icons.Filled.Event, "Event", Color(0xFFEF6C00)) {
                    showEventDialog = true
                }
                AttachOption(Icons.Filled.ScheduleSend, "Schedule", Color(0xFF3949AB)) {
                    onDismiss()
                    onOpenScheduleDialog()
                }
            }

            Spacer(modifier = Modifier.height(22.dp))
        }
    }

    if (showPollDialog) {
        var question by remember { mutableStateOf("") }
        var optionA by remember { mutableStateOf("Yes") }
        var optionB by remember { mutableStateOf("No") }
        AlertDialog(
            onDismissRequest = { showPollDialog = false },
            title = { Text("Create Chat Poll") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text("Question") })
                    OutlinedTextField(value = optionA, onValueChange = { optionA = it }, label = { Text("Option 1") })
                    OutlinedTextField(value = optionB, onValueChange = { optionB = it }, label = { Text("Option 2") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (question.isNotBlank()) {
                        onSendMediaMessage(
                            "📊 Poll: ${question.trim()}",
                            "POLL",
                            "${optionA.trim()} • ${optionB.trim()}"
                        )
                        showPollDialog = false
                        onDismiss()
                    }
                }) { Text("Send Poll") }
            },
            dismissButton = {
                TextButton(onClick = { showPollDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showEventDialog) {
        var eventTitle by remember { mutableStateOf("") }
        var eventTime by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showEventDialog = false },
            title = { Text("Create Group Event") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = eventTitle, onValueChange = { eventTitle = it }, label = { Text("Event Title") })
                    OutlinedTextField(value = eventTime, onValueChange = { eventTime = it }, label = { Text("Date & Time (e.g. Friday 8:00 PM)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (eventTitle.isNotBlank()) {
                        onSendMediaMessage(
                            "📅 Event: ${eventTitle.trim()}",
                            "EVENT",
                            eventTime.trim().ifBlank { "Scheduled Event" }
                        )
                        showEventDialog = false
                        onDismiss()
                    }
                }) { Text("Create Event") }
            },
            dismissButton = {
                TextButton(onClick = { showEventDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@SuppressLint("MissingPermission")
private suspend fun fetchApproximateCoordinates(context: Context): Pair<Double, Double>? {
    return try {
        val client = LocationServices.getFusedLocationProviderClient(context)
        val current = runCatching {
            client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null).await()
        }.getOrNull() ?: runCatching {
            client.lastLocation.await()
        }.getOrNull()
        current?.let { it.latitude to it.longitude }
    } catch (_: Exception) {
        null
    }
}

private fun readContactSummary(context: Context, contactUri: Uri): Pair<String, String>? {
    return try {
        var displayName = ""
        var contactId = ""
        context.contentResolver.query(
            contactUri,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIdx = cursor.getColumnIndex(ContactsContract.Contacts._ID)
                val nameIdx = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                if (idIdx >= 0) contactId = cursor.getString(idIdx).orEmpty()
                if (nameIdx >= 0) displayName = cursor.getString(nameIdx).orEmpty()
            }
        }
        var phone = ""
        if (contactId.isNotBlank()) {
            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                    arrayOf(contactId),
                    null
                )?.use { pCursor ->
                    if (pCursor.moveToFirst()) {
                        val pIdx = pCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        if (pIdx >= 0) phone = pCursor.getString(pIdx).orEmpty()
                    }
                }
            }
        }
        if (displayName.isBlank() && phone.isBlank()) null else displayName.ifBlank { phone } to phone
    } catch (_: Exception) {
        null
    }
}

@Composable
private fun AttachOption(
    icon: ImageVector,
    label: String,
    bgColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(74.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun EmojiStickersGifTray(
    onPickEmoji: (String) -> Unit,
    onPickStickerOrGif: (text: String, type: String, meta: String) -> Unit
) {
    var activeTab by remember { mutableStateOf("EMOJI") }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("EMOJI", "STICKERS", "GIFS").forEach { tab ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (activeTab == tab) WhatsupGreen else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.clickable { activeTab = tab }
                ) {
                    Text(
                        text = tab,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (activeTab == tab) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        when (activeTab) {
            "EMOJI" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf("❤️", "😂", "🤲", "🇵🇰", "👍", "🔥", "🌙", "☕").forEach { emoji ->
                        Text(
                            text = emoji,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier
                                .clickable { onPickEmoji(emoji) }
                                .padding(6.dp)
                        )
                    }
                }
            }
            "STICKERS" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Assalam-o-Alaikum 🌙", "JazakAllah ✨", "Chai Time ☕", "Mashallah 💚").forEach { sticker ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.clickable {
                                onPickStickerOrGif(sticker, "STICKER", "Whatsup Sticker Pack")
                            }
                        ) {
                            Text(
                                text = sticker,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
            "GIFS" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("[GIF] Cheers 👏", "[GIF] Celebrating 🎉", "[GIF] Thumbs Up 👍").forEach { gif ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BluetoothBlue.copy(alpha = 0.14f),
                            modifier = Modifier.clickable {
                                onPickStickerOrGif(gif, "GIF", "Animated GIF")
                            }
                        ) {
                            Text(
                                text = gif,
                                style = MaterialTheme.typography.labelSmall,
                                color = BluetoothBlue,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
