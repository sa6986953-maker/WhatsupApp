package com.example

import com.example.core.EmailUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

class EmailUtilsTest {

    @Test
    fun normalizeGmailAcceptsValidGmailAndGooglemail() {
        assertEquals("alice.smith+work@gmail.com", EmailUtils.normalizeGmail("  Alice.Smith+Work@GMAIL.COM  "))
        assertEquals("bob_99@googlemail.com", EmailUtils.normalizeGmail("Bob_99@GoogleMail.com"))
        assertTrue(EmailUtils.isValidGmail("user@gmail.com"))
    }

    @Test
    fun normalizeGmailRejectsInvalidOrNonGmailDomains() {
        assertNull(EmailUtils.normalizeGmail(""))
        assertNull(EmailUtils.normalizeGmail("   "))
        assertNull(EmailUtils.normalizeGmail("alice@yahoo.com"))
        assertNull(EmailUtils.normalizeGmail("alice@outlook.com"))
        assertNull(EmailUtils.normalizeGmail("alice@gmail.co"))
        assertNull(EmailUtils.normalizeGmail(".alice@gmail.com"))
        assertNull(EmailUtils.normalizeGmail("alice.@gmail.com"))
        assertNull(EmailUtils.normalizeGmail("al..ice@gmail.com"))
        assertNull(EmailUtils.normalizeGmail("alice smith@gmail.com"))
        assertFalse(EmailUtils.isValidGmail("not-an-email"))
    }

    @Test
    fun hashEmailProducesCanonicalLowercaseSha256Hex() {
        val hashA = EmailUtils.hashEmail("Alice.User@Gmail.com")
        val hashB = EmailUtils.hashEmail("  alice.user@gmail.com ")
        val expected = MessageDigest.getInstance("SHA-256")
            .digest("alice.user@gmail.com".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

        assertEquals(64, hashA.length)
        assertEquals(expected, hashA)
        assertEquals(hashA, hashB)
    }

    @Test
    fun otpValidationRequiresExactlySixDigits() {
        assertTrue(EmailUtils.isValidOtpCode("123456"))
        assertTrue(EmailUtils.isValidOtpCode(" 000999 "))
        assertFalse(EmailUtils.isValidOtpCode("12345"))
        assertFalse(EmailUtils.isValidOtpCode("1234567"))
        assertFalse(EmailUtils.isValidOtpCode("12a456"))
        assertFalse(EmailUtils.isValidOtpCode(""))
    }

    @Test
    fun maskEmailAndFormatCountdownFormatCorrectly() {
        assertEquals("al***@gmail.com", EmailUtils.maskEmail("alice@gmail.com"))
        assertEquals("5:00", EmailUtils.formatCountdown(300))
        assertEquals("1:05", EmailUtils.formatCountdown(65))
        assertEquals("0:09", EmailUtils.formatCountdown(9))
        assertEquals("0:00", EmailUtils.formatCountdown(-3))
    }
}
