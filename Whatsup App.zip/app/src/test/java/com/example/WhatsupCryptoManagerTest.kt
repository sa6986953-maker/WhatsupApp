package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.crypto.WhatsupCryptoManager
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WhatsupCryptoManagerTest {

    @Test
    fun ecdhDirectConversationKeyEncryptionRoundTripAndSafetyNumberMatch() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val crypto = WhatsupCryptoManager(context)

        val alicePub = crypto.getPublicKeyBase64("alice_uid")
        val bobPub = crypto.getPublicKeyBase64("bob_uid")
        val convId = "direct_alice_uid_bob_uid"

        val aliceKey = crypto.deriveDirectConversationKey("alice_uid", bobPub, convId)
        val bobKey = crypto.deriveDirectConversationKey("bob_uid", alicePub, convId)

        assertArrayEquals(aliceKey, bobKey)

        val aad = "$convId|msg_1"
        val encrypted = crypto.encryptMessageText("Assalam-o-Alaikum, E2EE test!", aliceKey, aad)
        val decrypted = crypto.decryptMessageText(encrypted.ciphertextBase64, encrypted.ivBase64, bobKey, aad)
        assertEquals("Assalam-o-Alaikum, E2EE test!", decrypted)

        // Mismatched AAD fails GCM authentication
        assertNull(crypto.decryptMessageText(encrypted.ciphertextBase64, encrypted.ivBase64, bobKey, "$convId|wrong_msg"))

        // Safety number is symmetric regardless of order
        val safetyAlice = WhatsupCryptoManager.computeSafetyNumber(alicePub, bobPub)
        val safetyBob = WhatsupCryptoManager.computeSafetyNumber(bobPub, alicePub)
        assertEquals(safetyAlice, safetyBob)
    }

    @Test
    fun groupKeyWrapUnwrapAndRawMediaBlobEncryptionRoundTrip() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val crypto = WhatsupCryptoManager(context)

        val creatorPub = crypto.getPublicKeyBase64("creator_uid")
        val memberPub = crypto.getPublicKeyBase64("member_uid")
        val groupKey = WhatsupCryptoManager.generateRandomAesKeyBytes()

        val wrapped = crypto.wrapGroupKeyForMember("creator_uid", memberPub, groupKey, "grp_123")
        val unwrapped = crypto.unwrapGroupKey("member_uid", creatorPub, wrapped, "grp_123")
        assertNotNull(unwrapped)
        assertArrayEquals(groupKey, unwrapped)

        val sampleFileBytes = "Encrypted photo payload bytes".toByteArray()
        val (cipherBlob, keyB64) = WhatsupCryptoManager.encryptRawBytesWithNewKey(sampleFileBytes)
        val plainBlob = WhatsupCryptoManager.decryptRawBytesWithKey(cipherBlob, keyB64)
        assertArrayEquals(sampleFileBytes, plainBlob)

        // Verify Tink AEAD initialization succeeds cleanly
        val aead = crypto.createTinkAeadSmokeTest()
        assertNotNull(aead)
    }
}
