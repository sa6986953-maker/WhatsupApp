package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.core.PreferencesManager
import com.example.core.StorageMediaManager
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.ThemeManager
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ThemeAndProfileStorageTest {

    @Test
    fun themeManagerResolvesSystemLightAndDarkModes() {
        assertFalse(ThemeManager.resolveDarkTheme(AppThemeMode.SYSTEM, isSystemDark = false))
        assertTrue(ThemeManager.resolveDarkTheme(AppThemeMode.SYSTEM, isSystemDark = true))
        assertFalse(ThemeManager.resolveDarkTheme(AppThemeMode.LIGHT, isSystemDark = true))
        assertTrue(ThemeManager.resolveDarkTheme(AppThemeMode.DARK, isSystemDark = false))

        assertEquals(AppThemeMode.SYSTEM, AppThemeMode.fromStorageKey(null))
        assertEquals(AppThemeMode.LIGHT, AppThemeMode.fromStorageKey("LIGHT"))
        assertEquals(AppThemeMode.DARK, AppThemeMode.fromStorageKey("dark"))
        assertEquals(AppThemeMode.SYSTEM, AppThemeMode.fromStorageKey("unknown"))
    }

    @Test
    fun storageMediaManagerSavesAndDeletesLocalProfilePhoto() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId("1:123456:android:abcdef")
                    .setApiKey("test-api-key")
                    .setProjectId("test-project")
                    .setStorageBucket("test-project.appspot.com")
                    .build()
            )
        }
        val mediaManager = StorageMediaManager(context)

        val tempSource = File(context.cacheDir, "sample_avatar_pick.jpg").apply {
            writeBytes(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(), 1, 2, 3, 4))
        }
        val uri = Uri.fromFile(tempSource)

        val savedPath = mediaManager.saveProfilePhotoLocally("uid_profile_1", uri).getOrThrow()
        assertTrue(File(savedPath).exists())
        assertEquals(savedPath, mediaManager.findExistingLocalProfilePhoto("uid_profile_1"))

        mediaManager.deleteLocalProfilePhoto(savedPath)
        assertNull(mediaManager.findExistingLocalProfilePhoto("uid_profile_1"))
    }

    @Test
    fun preferencesManagerPersistsThemeModeAcrossSessionSignOut() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefsManager = PreferencesManager(context)

        prefsManager.setThemeMode(AppThemeMode.DARK)
        prefsManager.setLocalProfilePhotoPath("/data/user/0/com.example/files/profile_photos/avatar_u1.jpg")
        prefsManager.setVerifiedEmail("alice@gmail.com")

        val beforeSignOut = prefsManager.preferencesFlow.first()
        assertEquals(AppThemeMode.DARK, beforeSignOut.themeMode)
        assertEquals("/data/user/0/com.example/files/profile_photos/avatar_u1.jpg", beforeSignOut.localProfilePhotoPath)

        prefsManager.clearSessionPrefs()
        val afterSignOut = prefsManager.preferencesFlow.first()
        // Global theme stays preserved across auth flow & logout; session identity/photo clears
        assertEquals(AppThemeMode.DARK, afterSignOut.themeMode)
        assertEquals("", afterSignOut.localProfilePhotoPath)
        assertEquals("", afterSignOut.verifiedEmail)

        prefsManager.setThemeMode(AppThemeMode.SYSTEM)
        assertEquals(AppThemeMode.SYSTEM, prefsManager.preferencesFlow.first().themeMode)
    }
}
