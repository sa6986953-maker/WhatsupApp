package com.example

import com.example.data.model.MessageReactionHelper
import com.example.ui.viewmodel.AuthRateLimitPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthRateLimitTest {

    @Test
    fun rateLimitPolicyConstantsAreStrict() {
        assertEquals(60, AuthRateLimitPolicy.RESEND_COOLDOWN_SECONDS)
        assertEquals(300, AuthRateLimitPolicy.OTP_EXPIRY_SECONDS)
        assertTrue(AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION in 3..10)
        assertTrue(AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS in 3..10)
    }

    @Test
    fun perUidReactionsIsolateMultipleUsersProperly() {
        var uidMap = emptyMap<String, String>()
        uidMap = MessageReactionHelper.toggleUidReaction(uidMap, "uid_1", "❤️")
        uidMap = MessageReactionHelper.toggleUidReaction(uidMap, "uid_2", "👍")
        uidMap = MessageReactionHelper.toggleUidReaction(uidMap, "uid_3", "❤️")

        val (countsForUid1, myEmoji1) = MessageReactionHelper.summarizeByEmoji(uidMap, "uid_1")
        assertEquals(mapOf("❤️" to 2L, "👍" to 1L), countsForUid1)
        assertEquals("❤️", myEmoji1)

        // uid_1 removes own reaction; uid_3 remains
        uidMap = MessageReactionHelper.toggleUidReaction(uidMap, "uid_1", "❤️")
        val (countsAfter, myEmojiAfter) = MessageReactionHelper.summarizeByEmoji(uidMap, "uid_1")
        assertEquals(mapOf("❤️" to 1L, "👍" to 1L), countsAfter)
        assertEquals("", myEmojiAfter)
    }
}
